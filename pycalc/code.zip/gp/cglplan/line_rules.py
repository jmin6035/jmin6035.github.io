"""품목별 필수·우선 라인(사용자 제공 '세부판매계획(품목별적용라인)', 2026-10-13) — data/line_rules.json

규칙 행: 부서 · 용도 · 지역 · 소재 · 기타(고객) · 품목구분1(품명) · 필수라인 · 우선라인1~3
  · 필수라인이 있으면 그 라인만, 없으면 우선라인 순서
  · 같은 부서·품명에 행이 여럿이면(예: PCS5 삼성 3CCL / 엘지 2CCL) 지역·고객·MAC 여부가 맞는 행을 고름
도금: 품목구분1 = MAC·AZ·AL·AL-STS·신도금, 컬러: 품명(PGS, POR-STS, PDF-AL …)
실적 검증(2026-07-01~10-12 컬러 92,919t): 규칙이 있는 87,562t 중 95.6% 가 규칙 라인에서 생산. 나머지 3,874t 는 tools/line_rules_check.py
"""
import json
import os
import re

PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'line_rules.json')
DEPT_OF_GROUP = {'계획재': '컬러건재판매그룹', '주문재': '컬러건재판매그룹', '건재수출': '컬러수출그룹', '가전수출': '컬러수출그룹',
                 '가전내수': '컬러수출그룹', '수요개발': '수요개발그룹'}
_CACHE = {}


def load(path=PATH):
    if path not in _CACHE:
        if not os.path.exists(path):
            _CACHE[path] = []
        else:
            with open(path, encoding='utf-8') as f:
                _CACHE[path] = json.load(f)['rules']
    return _CACHE[path]


def product_key(r):
    """규칙 행 → 엔진 품명 키(color_full.base_name 과 같은 형태): AL 소재 'PGS'→'PGS-AL', STS 소재 'ETC'→'ETC-STS'"""
    p = r['item'].strip()
    if r['mat'] == 'Al' and not p.endswith('-AL'):
        p += '-AL'
    if r['mat'] == 'STS' and 'STS' not in p:
        p += '-STS'
    return p


def _norm(s):
    return re.sub(r'[\s()_.\-]', '', str(s or '')).upper()


def _score(r, mac, region, cust):
    s = 0
    if mac is not None:
        s += 1 if (r['mat'] == 'MAC' or '(MAC' in r['label'].upper()) == bool(mac) else -1
    for want in (region, cust):
        w = _norm(want)
        if not w:
            continue
        for have in (r['region'], r['etc'], r['label']):
            h = _norm(have)
            if h and h not in ('일반', '내수', '수출') and (h in w or w in h):
                s += 2
                break
    return s


def lookup(product, group=None, mac=None, region='', cust='', dept=None, rules=None):
    """→ {'must': 라인 또는 '', 'prefer': [라인…], 'rows': [규칙 행 번호…]} 또는 None(규칙 없음)"""
    rules = load() if rules is None else rules
    dept = dept or DEPT_OF_GROUP.get(group or '')
    cand = [r for r in rules if product_key(r) == product and (not dept or r['dept'] == dept)]
    if not cand:
        cand = [r for r in rules if product_key(r) == product]
    if not cand:
        return None
    best = max(_score(r, mac, region, cust) for r in cand)
    top = [r for r in cand if _score(r, mac, region, cust) == best]
    musts = sorted({r['must'] for r in top if r['must']})
    prefer = []
    for r in top:
        for l in ([r['must']] if r['must'] else []) + r['prefer']:
            if l and l not in prefer:
                prefer.append(l)
    return {'must': musts[0] if len(musts) == 1 and all(r['must'] for r in top) else '', 'prefer': prefer, 'rows': [r['row'] for r in top]}


def lines(product, group=None, mac=None, region='', cust='', dept=None, rules=None):
    """가능 라인(앞 순서 우선). 규칙 없으면 None → 호출 쪽 기존 규칙 사용"""
    x = lookup(product, group, mac, region, cust, dept, rules)
    if not x:
        return None
    return [x['must']] if x['must'] else x['prefer']


# ---------------------------------------------------------------- 엑셀에서 다시 읽기(웹 '컬러 계획 계산' 업로드 · 산출기준서 L-22)
LINES_OK = ('1CGL', '2CGL', '1CCL', '2CCL', '3CCL', '4CCL')


def _t(v):
    return str(v).strip() if v not in (None, '') else ''


def _line(s):
    s = _t(s).upper().replace('#', '').replace(' ', '')
    return s if s in LINES_OK else ('1CCL' if s == '1' else s)


def from_xlsx(path):
    """「세부판매계획(품목별적용라인)」 엑셀 → (규칙 행, 경고). 첫 시트.
    열: '필수라인' 머리칸을 찾아 그 왼쪽 6칸 = 부서·용도·지역·소재·기타·품목구분1, 오른쪽 3칸 = 우선라인1~3.
    머리칸이 없으면 처음 받은 양식의 열 위치(DS~EB, 6행부터)를 씀. 행 이름 = B~I 열 중 마지막 값"""
    import openpyxl
    from openpyxl.utils import column_index_from_string as CI
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = wb[wb.sheetnames[0]]
    R = list(ws.iter_rows(values_only=True))
    hdr, cm = None, CI('DY') - 1
    for i, r in enumerate(R[:15]):
        j = next((j for j, v in enumerate(r) if '필수' in _t(v) and '라인' in _t(v)), None)
        if j is not None:
            hdr, cm = i, j
            break
    g = lambda r, k: r[k] if 0 <= k < len(r) else None
    rules, warns = [], []
    for i, r in enumerate(R):
        if i <= (hdr if hdr is not None else 4):
            continue
        dept, item = _t(g(r, cm - 6)), _t(g(r, cm - 1))
        if not dept or not item or dept in ('구분', '부서'):
            continue
        lab = [_t(v) for v in r[1:9] if _t(v)]
        must_raw = _t(g(r, cm))
        pref = [_line(g(r, cm + k)) for k in (1, 2, 3) if _t(g(r, cm + k))]
        must = _line(must_raw) if must_raw else ''
        if must and must not in LINES_OK:
            warns.append(f"{i + 1}행 '{lab[-1] if lab else item}': 필수라인 '{must_raw}' 해석 불가 → 빼고 우선라인만 씀")
            must = ''
        elif must_raw == '1':
            warns.append(f"{i + 1}행 '{lab[-1] if lab else item}'({item}): 필수라인 '1' → 1CCL 로 봄(확인 필요)")
        bad = [p for p in pref if p not in LINES_OK]
        if bad:
            warns.append(f"{i + 1}행 '{item}': 우선라인 {bad} 해석 불가 → 뺌")
            pref = [p for p in pref if p in LINES_OK]
        if must or pref:
            rules.append({'row': i + 1, 'label': lab[-1] if lab else item, 'dept': dept, 'use': _t(g(r, cm - 5)), 'region': _t(g(r, cm - 4)),
                          'mat': _t(g(r, cm - 3)), 'etc': _t(g(r, cm - 2)), 'item': item, 'must': must, 'prefer': pref})
    title = next((_t(v) for r in R[:3] for v in r if _t(v)), '')
    return rules, warns, title


def save(rules, src, title='', path=PATH):
    import datetime as _dt
    with open(path, 'w', encoding='utf-8') as f:
        json.dump({'source': src, 'title': title, 'extracted': _dt.date.today().isoformat(),
                   'note': '필수라인 = 그 라인에서만, 우선라인 = 앞 순서부터. etc 열에 고객사명이 있으므로 공개 사이트에 싣지 말 것', 'rules': rules},
                  f, ensure_ascii=False, indent=0)
    _CACHE.pop(path, None)
