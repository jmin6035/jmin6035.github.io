"""웹 '컬러 계획 계산'용 MES 자료 묶음 — 계산에 쓰는 표·열만, 개인정보 없이.

계산(tools/color_calc.py)이 읽는 표: color_prod · color_brk · ship · snap_salesrpt · snap_stock, 도금 코일(coilCols·coils), color_supply(컬러 구매 소재 코드별 입고 톤 — 미리 계산).
빼는 것: 담당자·작성자 이름, 최종고객사. 고객사는 첫 글자만 남김(수출 'J…' 판정에만 씀) — 빼도 계산 결과가 같음을 확인(2026-10-12).
사내 PC 자동 실행(pages.publish)이 매일 color_calc_mes.enc.json 으로 암호화 게시한다.
"""
TABLES = ('color_prod', 'color_brk', 'ship', 'snap_salesrpt', 'snap_stock')
DROP = {'snap_stock': ('최종고객사', '담당자'), 'color_prod': ('CHR_MAN',), 'color_brk': ('CRT_USER_ID', 'UPD_USER_ID')}
MASK_FIRST = {'snap_stock': ('고객사',)}


def mes_payload(T, coil_cols, coils, saved_at=None):
    """T: 추가 자료 표 {이름: {'columns', 'rows'}}, coil_cols·coils: 도금 코일(mesdata 형식) → 계산용 묶음"""
    out = {}
    for k in TABLES:
        t = T.get(k)
        if not t:
            continue
        cols = t['columns']
        keep = [i for i, c in enumerate(cols) if c not in DROP.get(k, ())]
        nc = [cols[i] for i in keep]
        mask = [nc.index(c) for c in MASK_FIRST.get(k, ()) if c in nc]
        rows = []
        for r in t['rows']:
            x = [r[i] for i in keep]
            for i in mask:
                x[i] = str(x[i])[:1] if x[i] else x[i]
            rows.append(x)
        out[k] = {'columns': nc, 'rows': rows}
    try:                                                     # 컬러 몰기의 구매 소재 입고 제약용(코드·날짜·톤만) — 소재재고List 원표는 단가가 있어 싣지 않음
        from . import pages as PG, salesrpt
        sr = salesrpt.summary(T['snap_salesrpt']) if T.get('snap_salesrpt') else {}
        today = (sr.get('asOf') or str(saved_at or ''))[:10]
        if today:
            sup = PG.color_supply(T, today)
            out['color_supply'] = {'columns': ['code', 'date', 't'], 'rows': [[c, d, round(t, 1)] for c, ser in sorted(sup.items()) for d, t in sorted(ser.items())]}
    except Exception:
        pass
    return {'app': 'cgl-colorcalc-mes', 'version': 1, 'savedAt': saved_at,
            'ex': {'app': 'cgl-extradata', 'version': 1, 'savedAt': saved_at, 'tables': out},
            'md': {'coilCols': list(coil_cols), 'coils': coils}}
