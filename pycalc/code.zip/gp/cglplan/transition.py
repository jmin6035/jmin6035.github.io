"""컬러 일·라인 안 작업 순서 — 전환 휴지(색·주문·품명·섹션·목적지 바뀜) 최소 (2026-10-20 사용자, color-schedule 방 전달)
자료(학습 방 color-schedule 이 매일 갱신, data/ml_color/ 에 스냅샷):
  key_matrix.json  라인별 단위(섹션·내수/수출:항구·품명) A→B 전환 분(use = 실적 5번 이상이면 실적, 아니면 조건표 예측)
  stop_groups.json 라인별 하루 전환·정비·품질 정지 분(실적)
단위 키는 학습 방 keyed() 와 같은 모양: '건재1섹션·내수·PGS', '수출1섹션·수출:LIVERPOOL·PGS'
  계획 그룹 → 섹션: 건재수출 = 수출1섹션, 가전수출 = 수출2섹션, 가전내수 = 엘지(창원) 창원출장소 / 그 밖 수출2섹션(내수),
  주문재·계획재 = 그 라인·품명에서 실적 톤이 많은 건재1·2섹션, 수요개발 = 수요개발
key_matrix 에 없는 쌍(라인마다 실적 많은 15개 단위만 있음)은 같은 라인의 비슷한 쌍 중앙값:
  같은 단위 / 같은 품명·다른 섹션·목적지 / 다른 품명·같은 섹션 / 둘 다 다름
순서 = 그날 첫 단위는 전날 마지막 단위에서 이어서, 단위 7개 이하는 전부 따져 보고 그보다 많으면 가까운 것부터 + 2-opt.
같은 단위 행은 한 덩어리(집약 묶음도 같은 품명이라 연속 유지).
  평가: python tools/color_seq.py · 배정: cglplan.color_full.schedule(CGL_SEQ=1 이면 같은 단위가 도는 날에 먼저 붙임)
"""
import itertools, json, os, statistics as ST
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DATA = os.path.join(ROOT, 'data', 'ml_color')
SEC = {'건재수출': '수출1섹션', '가전수출': '수출2섹션', '수요개발': '수요개발'}


def _load(name):
    p = os.path.join(DATA, name + '.json')
    return json.load(open(p, encoding='utf-8')) if os.path.exists(p) else []


class Trans:
    def __init__(self):
        self.m = defaultdict(dict)                      # line → {(a, b): 분}
        self.tons = defaultdict(Counter)                # line → {단위: 1년 톤}
        for x in _load('key_matrix'):
            if x.get('use') is not None:
                self.m[x['line']][(x['a'], x['b'])] = float(x['use'])
            self.tons[x['line']][x['a']] = x.get('ta') or 0
        self.fb = {}
        for l, mm in self.m.items():
            cat = defaultdict(list)
            for (a, b), v in mm.items():
                cat[self.cat(a, b)].append(v)
            self.fb[l] = {k: ST.median(v) for k, v in cat.items() if v}
        self.stop = {(x['line'], x['grp']): x for x in _load('stop_groups')}

    @staticmethod
    def parts(k):
        s, d, p = (k.split('·') + ['', '', ''])[:3]
        return s, d, p

    def cat(self, a, b):
        if a == b:
            return 'same'
        sa, da, pa = self.parts(a)
        sb, db, pb = self.parts(b)
        if pa == pb:
            return 'prod'                               # 같은 품명, 섹션·목적지만 다름
        return 'sec' if sa == sb else 'both'

    def cost(self, line, a, b):
        if a is None or b is None:
            return 0.0
        v = self.m.get(line, {}).get((a, b))
        if v is not None:
            return v
        fb = self.fb.get(line) or {}
        return fb.get(self.cat(a, b), fb.get('both', 60.0))

    def key(self, line, group, product, dest='', cust=''):
        base = str(product or '').split('(')[0]
        if group in ('주문재', '계획재'):
            t = self.tons.get(line, {})
            s1, s2 = t.get(f'건재1섹션·내수·{base}', 0), t.get(f'건재2섹션·내수·{base}', 0)
            return f"{'건재2섹션' if s2 > s1 else '건재1섹션'}·내수·{base}"
        if group == '가전내수':
            return f"{'창원출장소' if '창원' in str(cust) else '수출2섹션'}·내수·{base}"
        if group in ('건재수출', '가전수출'):
            d = dest if dest and dest != '미정' else '목적지 미상'
            return f"{SEC[group]}·수출:{d}·{base}"
        return f"{SEC.get(group, group)}·내수·{base}"


def path_cost(T, line, prev, seq):
    c, p = 0.0, prev
    for k in seq:
        c += T.cost(line, p, k)
        p = k
    return c


def best_order(T, line, prev, units, fixed_first=None):
    """units: 단위 목록(중복 없음). 반환 순서(전환 합 최소)"""
    us = [u for u in units if u != fixed_first]
    head = [fixed_first] if fixed_first else []
    if len(us) <= 7:
        best = min(itertools.permutations(us), key=lambda s: path_cost(T, line, prev, head + list(s)), default=())
        return head + list(best)
    cur, left, out = (head[-1] if head else prev), list(us), list(head)
    while left:
        n = min(left, key=lambda k: T.cost(line, cur, k))
        out.append(n); left.remove(n); cur = n
    improved = True
    while improved:
        improved = False
        for i in range(len(head), len(out) - 1):
            for j in range(i + 1, len(out)):
                cand = out[:i] + out[i:j + 1][::-1] + out[j + 1:]
                if path_cost(T, line, prev, cand) < path_cost(T, line, prev, out) - 1e-6:
                    out, improved = cand, True
    return out


