"""계획 규칙의 수치(포털 '계획 규칙' 화면에서 고침, 2026-10-22 사용자: 규칙 목록 + 수치 수정 → 적용 누르면 다시 계산).
원본 = cglplan/tf_rules.json(설치 묶음에 같이 들어감).
  days     : 그룹별 TF 목표 일수(월말 재고 = 목표 일수 × 다음 달 하루 판매) — tools/master_plan
  stockMax : 공장 월말 최대 재고('27 판생그룹 목표) — master_plan 상한, 화면 목표
  plating  : 도금 계획 손실·주문재 시작(분 단위, 라인별) — 계획 엔진 P 를 덮어씀(apply_plating)
  replan   : 재계산 기준(지연 1톤·일 대 M/C 1회 무게, 지시 나간 앞 며칠 강종 동결)
화면에서 저장한 값은 Supabase 표 cgl_tf_rules 에 암호화돼 쌓이고(추가만), '적용'을 누른 줄은 apply = true.
tools/rules_apply.py 가 1시간마다 새 적용 요청을 찾아 이 파일로 가져오고 다시 계산·게시."""
import json
import os

PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tf_rules.json')
TABLE = 'cgl_tf_rules'
DAY_KEYS = ('G수출', 'G국내', 'G자가재', 'AL-STS', '임가공', '기타', '건재수출', '가전수출', '가전내수', '주문재', '수요개발')
MAX_KEYS = ('도금 소재(F/H)', '도금 제품(판매재)', '컬러 소재', '컬러 제품')
LINES = ('1CGL', '2CGL')
PLAT_LINE = {'switchDummy': (60, 2000), 'nonfamDummy': (0, 300), 'equipDown': (0, 300), 'restartFamchg': (0, 3000), 'restartSame': (0, 3000)}   # 분 — 범위 밖은 거부
PLAT_ONE = {'releaseDays': (1, 90)}
REPLAN = {'tradeoff': (1, 100000), 'freezeDays': (0, 7)}
REPLAN_DEF = {'tradeoff': 100, 'freezeDays': 2}         # 사내 PC 매일 재계획(cglplan/auto.py)과 같은 값 — 10/22 ③안


def _num(v, lo, hi, what):
    v = float(v)
    if not lo <= v <= hi:
        raise ValueError(f'{what} {v} — {lo}~{hi}')
    return int(v) if v == int(v) else round(v, 3)


def validate(o):
    """화면에서 온 값 검사 — 모르는 항목·범위 밖 값이 있으면 ValueError. 정리된 dict 반환(plating·replan 은 있을 때만)"""
    if not isinstance(o, dict):
        raise ValueError('형식 오류')
    d, m = o.get('days') or {}, o.get('stockMax') or {}
    if set(d) != set(DAY_KEYS) or set(m) != set(MAX_KEYS):
        raise ValueError('항목이 맞지 않음')
    out = {'days': {k: _num(d[k], 0, 120, f'{k} 목표 일수') for k in DAY_KEYS},
           'stockMax': {k: int(_num(m[k], 1, 100000, f'{k} 월말 최대')) for k in MAX_KEYS}}
    p = o.get('plating')
    if p:
        if not set(p) <= set(PLAT_LINE) | set(PLAT_ONE):
            raise ValueError('도금 항목이 맞지 않음')
        out['plating'] = {}
        for k, v in p.items():
            if k in PLAT_LINE:
                if not isinstance(v, dict) or set(v) != set(LINES):
                    raise ValueError(f'{k} 라인이 맞지 않음')
                out['plating'][k] = {ln: _num(v[ln], *PLAT_LINE[k], f'{k} {ln}') for ln in LINES}
            else:
                out['plating'][k] = _num(v, *PLAT_ONE[k], k)
    r = o.get('replan')
    if r:
        if not set(r) <= set(REPLAN):
            raise ValueError('재계산 항목이 맞지 않음')
        out['replan'] = {k: _num(v, *REPLAN[k], k) for k, v in r.items()}
    return out


def load():
    o = json.load(open(PATH, encoding='utf-8'))
    return dict(validate(o), src=o.get('src') or {})


def apply_plating(P):
    """계획 엔진 P(dict)에 도금 수치를 덮어쓴 사본 — 안 적힌 항목은 그대로"""
    P = dict(P)
    for k, v in (R.get('plating') or {}).items():
        P[k] = dict(v) if isinstance(v, dict) else v
    return P


def replan_opts():
    return dict(REPLAN_DEF, **(R.get('replan') or {}))


R = load()
DAYS, STOCK_MAX, SRC = R['days'], R['stockMax'], R['src']
