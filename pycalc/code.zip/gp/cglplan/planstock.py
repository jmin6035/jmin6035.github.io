"""계획재(R15 TF 운영안 187 사양) 분석·예측 — 화면 planstock.html 자료(planstock.enc.json)

기준: pages_base/planstock_base.json (tools/r15_base.py, R15 '운영안'·'일자별상세내역')
매일: MES 컬러 생산(color_prod)·출하(ship)·월말 재고(snap_stock)

사양 연결(R15 '제품재고' 정의 재현): 컬러건재판매그룹, '두께 폭 상도색상' — 재고는 표기값 일치, 생산은 실측 두께 ±0.03mm 최근접.
현재 재고 = 최근 월말 재고(MES) + 그 뒤 생산 − 그 뒤 출하(출하 코일번호를 월말 재고·생산 코일과 이어 사양 판정).
월말 예상 = 현재 재고 + 남은 생산 계획(R15 월 생산 − 이번 달 실적, 0 미만은 0) − 남은 판매 예측(R15 월 예측 − 이번 달 출하, 0 미만은 0).
판매 진도는 직선이 아니라 지난 3개월 계획재 사양 출하의 월중 누적 비율(월말 몰림)로 본다.
"""
import calendar
import datetime as dt
from collections import Counter, defaultdict

from . import pages as PG

TOL_T, TOL_W = 0.03, 1.0
DEPT = '컬러건재'


def f(x):
    return PG.f(x)


class _M:
    """R15 정의: 사양 = '두께 폭 상도색상'(품명 무관), 컬러건재판매그룹 재고. 재고는 표기 두께·폭 일치,
    생산 실적은 실측 두께라 폭·색상 일치 + 두께 ±0.03mm 안에서 가장 가까운 사양"""
    def __init__(self, specs):
        self.idx = defaultdict(list)
        for i, s in enumerate(specs):
            self.idx[s['color']].append((i, s))

    def __call__(self, thk, wdt, color, tolt=TOL_T):
        best = None
        for i, s in self.idx.get(str(color or ''), []):
            d = abs(s['thk'] - thk)
            if abs(s['wdt'] - wdt) <= TOL_W and d <= tolt + 1e-9 and (best is None or d < best[0]):
                best = (d, i)
        return best[1] if best else None


def _ym(d):
    return str(d)[:7]


def _days(ym):
    y, m = map(int, ym.split('-'))
    return calendar.monthrange(y, m)[1]


def build(T, today=None, base=None):
    base = base or PG.load_base('planstock_base.json')
    if not base or not T.get('color_prod') or not T.get('snap_stock'):
        return None
    S = base['specs']
    n = len(S)
    m = _M(S)
    # ---- 코일 → 사양: 월말 재고(전 기간) + 생산 실적
    coil = {}
    stock_m = defaultdict(Counter)                                       # 월(YYYYMM) → 사양 → t
    for r in PG._rows(T, 'snap_stock'):
        if r['공장구분'] != 'C' or r['구분명'] != 'P' or not str(r.get('담당부서(HR)') or '').startswith(DEPT):
            continue
        i = m(f(r['제품두께']), f(r['제품폭']), r['표면상도코드'], 0.005)
        if i is None:
            continue
        coil[str(r['소재제품번호'])] = i
        stock_m[str(r['_기준월'])][i] += f(r['중량']) / 1000
    prod = defaultdict(Counter)                                          # 일자 → 사양 → t
    for r in PG._rows(T, 'color_prod'):
        if not str(r.get('DEPT') or '').startswith(DEPT):
            continue
        i = m(f(r['REAL_MSR_THK']), f(r['PDT_WDT']), r['SUR_FINISH_CD'])
        if i is None:
            continue
        coil[str(r['PDT_NO'])] = i
        prod[str(r['PRD_DT'])[:10]][i] += f(r['PDT_WGT']) / 1000
    ship = defaultdict(Counter)                                          # 일자 → 사양 → t (컬러 공장 출하 전체: 판매·이송)
    for r in PG._rows(T, 'ship'):
        if r['PLT_CLS'] != 'C':
            continue
        i = coil.get(str(r['PDT_NO']))
        if i is not None:
            ship[str(r['OUT_DT'])[:10]][i] += f(r['WGT']) / 1000
    last = max(max(prod, default=''), max(ship, default=''))
    if not last:
        return None
    today = today or last
    m0 = max(stock_m)                                                    # 최근 월말 재고 (예: 202609 = 9월말)
    d0 = dt.date(int(m0[:4]), int(m0[4:]), 1) + dt.timedelta(days=_days(f'{m0[:4]}-{m0[4:]}'))   # 그다음 날 (10/1)
    cur_ym = _ym(last)
    # ---- 월중 출하 누적 비율(지난 3개월, 계획재 사양): 일자 → 그 날까지 누적 비중
    hist = Counter()
    hm = sorted({_ym(d) for d in ship if _ym(d) < cur_ym})[-3:]
    for d, c in ship.items():
        if _ym(d) in hm:
            hist[int(d[8:10])] += sum(c.values())
    tot = sum(hist.values()) or 1.0
    cum, acc = [], 0.0
    for day in range(1, 32):
        acc += hist[day]
        cum.append(acc / tot)
    nd = _days(cur_ym)
    dlast = int(last[8:10])
    pace = cum[dlast - 1] if dlast < nd else 1.0                        # 이번 달 이 날까지 보통 나가는 비중
    # ---- 사양별 집계
    ms = base['months']
    mi = ms.index(cur_ym) if cur_ym in ms else None
    since = d0.isoformat()
    p_since = Counter(); s_since = Counter(); p_mon = Counter(); s_mon = Counter()
    for d, c in prod.items():
        for i, t in c.items():
            if d >= since:
                p_since[i] += t
            if _ym(d) == cur_ym:
                p_mon[i] += t
    for d, c in ship.items():
        for i, t in c.items():
            if d >= since:
                s_since[i] += t
            if _ym(d) == cur_ym:
                s_mon[i] += t
    st0 = stock_m[m0]
    rows = []
    for i, s in enumerate(S):
        cur = st0[i] + p_since[i] - s_since[i]
        r = {'i': i, 'stock0Mes': round(st0[i], 1), 'prodM': round(p_mon[i], 1), 'shipM': round(s_mon[i], 1), 'stock': round(cur, 1)}
        if mi is not None:
            plan_due = sum(x[-1] for x in s['sched'] if x[0] <= last)        # 오늘까지 만들었어야 할 양(펼친 일정)
            r['planDue'] = round(plan_due, 1)
            r['planM'] = s['prod'][mi]
            r['fcM'] = s['fc'][mi]
            e, ends = cur, []
            for k in range(mi, len(ms)):
                if k == mi:
                    e += max(0.0, s['prod'][k] - p_mon[i]) - max(0.0, s['fc'][k] - s_mon[i])
                else:
                    e += s['prod'][k] - s['fc'][k]
                ends.append(round(e, 1))
            r['end'] = ends                                              # 이번 달 ~ 3월 월말 예상
            daily = (s['fc'][mi] or s['sale']) / 30.0
            r['cover'] = round(cur / daily, 1) if daily > 0 else None
            flags = []
            if ends[0] < -1:
                flags.append('short')                                    # 이번 달 말 결품 예상
            elif ends[0] < s['safe'] - 0.5:
                flags.append('low')                                      # 안전재고 아래
            if any(x < -1 for x in ends[1:3]):
                flags.append('shortNext')
            if s['target'] > 0 and ends[0] > 2 * s['target'] and ends[0] - s['target'] >= 10:
                flags.append('over')                                     # 목표의 2배 초과
            if plan_due - p_mon[i] >= max(5.0, 0.3 * plan_due):
                flags.append('behind')                                   # 일정 대비 30%·5t 이상 덜 만듦
            if s['fc'][mi] >= 5 and dlast >= 10:
                exp = s['fc'][mi] * pace
                if s_mon[i] > 1.5 * exp + 5:
                    flags.append('fcHigh')                               # 예측보다 빨리 나감
            r['flags'] = flags
        rows.append(r)
    # ---- 합계·일별 추이(계획재 전체)
    def tsum(key, k=None):
        return round(sum((r[key][k] if k is not None else r[key]) for r in rows if key in r), 1)
    days_seq = []
    d = d0
    while d.isoformat() <= last:
        days_seq.append(d.isoformat())
        d += dt.timedelta(days=1)
    stock_line, s_acc = [], sum(st0.values())
    for d in days_seq:
        s_acc += sum(prod[d].values()) - sum(ship[d].values())
        stock_line.append(round(s_acc, 1))
    # 앞으로(이번 달 말까지) 예상: 펼친 일정 생산 − 예측 판매(월중 누적 비율 배분)
    fut = []
    if mi is not None:
        sched_day = Counter()
        for s in S:
            for x in s['sched']:
                if _ym(x[0]) == cur_ym:
                    sched_day[int(x[0][8:10])] += x[-1]
        left_p = sum(max(0.0, s['prod'][mi] - p_mon[i]) for i, s in enumerate(S))
        sch_left = sum(v for k, v in sched_day.items() if k > dlast) or 1.0
        left_s = sum(max(0.0, s['fc'][mi] - s_mon[i]) for i, s in enumerate(S))
        rem = (1.0 - pace) or 1.0
        e = s_acc
        for day in range(dlast + 1, nd + 1):
            e += left_p * sched_day[day] / sch_left - left_s * (cum[day - 1] - cum[day - 2]) / rem
            fut.append([f'{cur_ym}-{day:02d}', round(e, 1)])
    by = defaultdict(lambda: Counter())
    for r in rows:
        s = S[r['i']]
        for key in (s['mat'], s['use'] or '기타'):
            pass
        by[('mat', s['mat'])]['stock'] += r['stock']; by[('mat', s['mat'])]['target'] += s['target']
        by[('mat', s['mat'])]['n'] += 1
        if mi is not None:
            by[('mat', s['mat'])]['end'] += r['end'][0]; by[('mat', s['mat'])]['fcM'] += s['fc'][mi]
            by[('mat', s['mat'])]['shipM'] += r['shipM']; by[('mat', s['mat'])]['prodM'] += r['prodM']
            by[('mat', s['mat'])]['planM'] += s['prod'][mi]
    fl = Counter(x for r in rows for x in r.get('flags', []))
    out = {
        'src': base['src'], 'asOf': last, 'today': today, 'stockMonth': m0, 'month': cur_ym, 'months': ms, 'pace': round(pace, 3),
        'paceFrom': hm, 'n': n,
        'specs': [{k: s[k] for k in ('product', 'kind', 'owner', 'use', 'spec', 'mat', 'eoq', 'sale', 'safe', 'target', 'stock0', 'fc', 'prod', 'test')} for s in S],
        'rows': rows,
        'tot': {'stock0R15': round(sum(s['stock0'] for s in S), 1), 'stock0Mes': round(sum(st0.values()), 1), 'stock': tsum('stock'),
                'prodM': tsum('prodM'), 'shipM': tsum('shipM'), 'planDue': tsum('planDue'), 'planM': tsum('planM'), 'fcM': tsum('fcM'),
                'target': round(sum(s['target'] for s in S), 1), 'safe': round(sum(s['safe'] for s in S), 1),
                'end': [round(sum(r['end'][k] for r in rows), 1) for k in range(len(rows[0].get('end', [])))],
                'fc': [round(sum(s['fc'][k] for s in S), 1) for k in range(len(ms))],
                'prod': [round(sum(s['prod'][k] for s in S), 1) for k in range(len(ms))]},
        'flags': dict(fl),
        'byMat': [{'mat': k[1], **{a: round(v, 1) for a, v in c.items()}} for k, c in sorted(by.items(), key=lambda kv: -kv[1]['stock'])],
        'daily': {'days': days_seq, 'stock': stock_line, 'prod': [round(sum(prod[d].values()), 1) for d in days_seq],
                  'ship': [round(sum(ship[d].values()), 1) for d in days_seq], 'future': fut},
        'shipHist': {ym: round(sum(sum(c.values()) for d, c in ship.items() if _ym(d) == ym), 1) for ym in sorted({_ym(d) for d in ship})[-4:]},
        'prodHist': {ym: round(sum(sum(c.values()) for d, c in prod.items() if _ym(d) == ym), 1) for ym in sorted({_ym(d) for d in prod})[-4:]},
    }
    ev, orders, osum, fh = calendar_events(base, rows, last)
    for d in sorted(prod):                                                      # 지난 날 계획재 생산 실적도 달력에
        if d >= since and d <= last and sum(prod[d].values()) > 0.5:
            items = sorted(((S[i]['product'], S[i]['spec'], '', round(t, 1), S[i]['mat']) for i, t in prod[d].items()), key=lambda z: -z[3])
            ev.append({'d': d, 'kind': 'done', 't': round(sum(prod[d].values()), 1), 'title': f"계획재 생산 실적 {round(sum(prod[d].values())):,}t", 'items': [list(z) for z in items]})
    out.update({'events': sorted(ev, key=lambda e: (e['d'], e['kind'])), 'orders': orders, 'orderSum': osum, 'fh': fh})
    return out


# ------------------------------------------------------------------ 계획재 캘린더: 생산 일정 + 소재 발주(업체·양·발주일)
# 팀 소재 리드타임 표(2026-10-12, data/material_leadtime.json):
#   컬러 투입 = 소재 컬러 입고 + 7일. GI(포스코 광양 P-GI) = 매주 발주 +5주 → 컬러 입고 +0일.
#   서림 GI(27년 입고분부터) = 1~10일 발주 → 차차월 5일 / 10~20일 발주 → 차차차월 1일.
#   P-FH(포스코 FH) = 매주 발주 +5주 → 도금(자가) +5일 → 컬러 입고 +1일.  수입 FH = 전전월 10~20일 발주 → 그 달 7일경 입고 → 도금 +5일 → 컬러 +1일.
COLOR_YIELD, PLATING_YIELD = 1.003, 1.008          # tools/master_plan.py 와 같은 값(제품 ÷ 소재)
SUP = {'P-GI': '포스코(광양) GI', '서림 GI': '서림철강 GI', 'P-FH': '포스코 FH(자가 도금)', '수입 FH': '수입 FH(자가 도금)'}


def _d(s):
    return dt.date.fromisoformat(s)


def _monday(x):
    return x - dt.timedelta(days=x.weekday())


def _addm(y, m, k):
    m2 = m + k
    return y + (m2 - 1) // 12, (m2 - 1) % 12 + 1


def order_rule(mat, prod_day):
    """생산(컬러 투입)일 → (발주 유형, 업체, 발주 시작, 발주 마감, 입고일, 규칙 설명)"""
    P = _d(prod_day)
    if mat in ('P-FH', '수입 FH'):
        A = P - dt.timedelta(days=13)                       # FH 입고 → 도금 +5 → 컬러 입고 +1 → 투입 +7
        if mat == 'P-FH':
            o = _monday(A - dt.timedelta(days=35))
            return 'P-FH', SUP['P-FH'], o, o + dt.timedelta(days=4), A, '매주 발주 → +5주 입고 → 도금 5일 → 컬러 입고 1일 → 투입 7일'
        y, m = A.year, A.month
        if A.day < 7:
            y, m = _addm(y, m, -1)
        oy, om = _addm(y, m, -2)
        return '수입 FH', SUP['수입 FH'], dt.date(oy, om, 10), dt.date(oy, om, 20), dt.date(y, m, 7), '전전월 10~20일 발주 → 그 달 7일경 입고 → 도금 5일 → 컬러 입고 1일 → 투입 7일'
    A = P - dt.timedelta(days=7)                            # GI: 컬러 입고 +0 → 투입 +7
    if mat == '서림 GI' and A.year >= 2027:
        c = []
        for k in range(0, 3):
            y, m = _addm(A.year, A.month, -k)
            for day, lag, o0, o1 in ((5, 2, 1, 10), (1, 3, 10, 20)):
                a = dt.date(y, m, day)
                if a <= A:
                    oy, om = _addm(y, m, -lag)
                    c.append((a, dt.date(oy, om, o0), dt.date(oy, om, o1), f'{o0}~{o1}일 발주 → {"차차월" if lag == 2 else "차차차월"} {day}일 입고'))
        a, o0, o1, rule = max(c)
        return '서림 GI', SUP['서림 GI'], o0, o1, a, rule + ' → 투입 7일'
    o = _monday(A - dt.timedelta(days=35))
    note = ' (서림 GI 사양 — 27년 전 입고분은 포스코 광양으로)' if mat == '서림 GI' else ''
    return 'P-GI', SUP['P-GI'], o, o + dt.timedelta(days=4), A, '매주 발주 → +5주 입고 → 투입 7일' + note


def calendar_events(base, rows, last):
    """계획재 캘린더 행사: prod(그날 계획재 생산 — 지난 날은 실적, 이번 달 남은 날은 계획 − 실적을 남은 일정에 비례), order(소재 발주 마감), arrive(입고 필요)
    rows = build() 의 사양별 행(prodM 등). 반환 [{d, kind, t, title, items:[...]}], 발주 요약"""
    S = base['specs']
    cur_ym = last[:7]
    prod = defaultdict(lambda: defaultdict(float))           # 날짜 → (사양, 라인) → t
    for i, s in enumerate(S):
        r = rows[i]
        fut = [x for x in s['sched'] if x[0] > last]
        cur_f = [x for x in fut if x[0][:7] == cur_ym]
        left = max(0.0, (r.get('planM') or 0) - (r.get('prodM') or 0))
        k = left / sum(x[2] for x in cur_f) if cur_f and sum(x[2] for x in cur_f) else 0
        for d, l, t in fut:
            tt = t * k if d[:7] == cur_ym else t
            if tt >= 0.05:
                prod[d][(i, l)] += tt
    ev = []
    for d in sorted(prod):
        items = sorted(((S[i]['product'], S[i]['spec'], l, round(t, 1), S[i]['mat']) for (i, l), t in prod[d].items()), key=lambda z: -z[3])
        ev.append({'d': d, 'kind': 'prod', 't': round(sum(z[3] for z in items), 1), 'title': f"계획재 생산 {round(sum(z[3] for z in items)):,}t",
                   'lines': sorted({z[2] for z in items}), 'items': [list(z) for z in items]})
    # 소재 발주: (유형, 발주 마감) 별로 묶음
    od = defaultdict(lambda: {'t': 0.0, 'items': defaultdict(float), 'prod': set()})
    fh_need = defaultdict(float)
    for d, m in prod.items():
        for (i, l), t in m.items():
            s = S[i]
            kind, sup, o0, o1, arr, rule = order_rule(s['mat'], d)
            need = t / COLOR_YIELD / (PLATING_YIELD if 'FH' in kind else 1.0)
            key = (kind, o1.isoformat())
            x = od[key]
            x.update({'sup': sup, 'o0': o0.isoformat(), 'o1': o1.isoformat(), 'arr': arr.isoformat(), 'rule': rule})
            x['t'] += need
            x['items'][f"{s['thk']:g}×{s['wdt']:g}"] += need
            x['prod'].add(d)
            if kind == '수입 FH':
                fh_need[arr.isoformat()[:7]] += need
    fh_have = defaultdict(float)
    for a, o, thk, wdt, coat, t in base.get('fhOrdered', []):
        fh_have[a[:7]] += t
    today = last
    orders = []
    for (kind, o1), x in sorted(od.items(), key=lambda kv: kv[0][1]):
        st = 'past' if o1 < today else 'soon' if (_d(o1) - _d(today)).days <= 14 else 'later'
        rec = {'kind': kind, 'sup': x['sup'], 'o0': x['o0'], 'o1': o1, 'arr': x['arr'], 'rule': x['rule'], 't': round(x['t'], 1), 'state': st,
               'prodFrom': min(x['prod']), 'prodTo': max(x['prod']),
               'items': sorted([[k, round(v, 1)] for k, v in x['items'].items()], key=lambda z: -z[1])[:12]}
        if kind == '수입 FH':
            ym = x['arr'][:7]
            rec['ordered'] = round(min(fh_have[ym], fh_need[ym]) * x['t'] / fh_need[ym], 1) if fh_need[ym] else 0
        orders.append(rec)
        ev.append({'d': o1, 'kind': 'order', 't': rec['t'], 'title': f"{kind} 발주 마감 {round(rec['t']):,}t", 'order': rec})
        ev.append({'d': x['arr'], 'kind': 'arrive', 't': rec['t'], 'title': f"{kind} 입고 필요 {round(rec['t']):,}t", 'order': rec})
    summ = defaultdict(lambda: {'t': 0.0, 'past': 0.0, 'soon': 0.0, 'n': 0})
    for o in orders:
        z = summ[o['kind']]
        z['t'] += o['t']; z['n'] += 1
        if o['state'] in ('past', 'soon'):
            z[o['state']] += o['t'] - o.get('ordered', 0)
    return ev, orders, {k: {a: round(v, 1) if isinstance(v, float) else v for a, v in z.items()} for k, z in summ.items()}, \
        {ym: [round(fh_need[ym], 1), round(fh_have[ym], 1)] for ym in sorted(set(fh_need) | set(fh_have))}
