"""브라우저(Pyodide)용 작은 pulp 대용 — tools/master_plan.lp_plant 가 쓰는 만큼만(연속 변수 LP).
식을 CPLEX LP 글로 써서 사이트의 HiGHS(vendor/highs.js)로 푼다: 자바스크립트 쪽 globalThis.cglHighsSolve(lp 글) → JSON 결과.
서버(CPython)에서는 진짜 pulp 를 쓰고, 이 파일은 브라우저에서만 sys.path 앞에 놓인다.
"""
import json

LpMinimize, LpMaximize = 1, -1
LpStatus = {1: 'Optimal', 0: 'Not Solved', -1: 'Infeasible', -2: 'Unbounded', -3: 'Undefined'}


class LpAffineExpression:
    def __init__(self, terms=None, const=0.0):
        self.terms = dict(terms or {})                       # {LpVariable: 계수}
        self.const = float(const)

    @staticmethod
    def of(x):
        if isinstance(x, LpAffineExpression):
            return x
        if isinstance(x, LpVariable):
            return LpAffineExpression({x: 1.0})
        return LpAffineExpression(const=x)

    def copy(self):
        return LpAffineExpression(self.terms, self.const)

    def __add__(self, o):
        o, r = LpAffineExpression.of(o), self.copy()
        for v, c in o.terms.items():
            r.terms[v] = r.terms.get(v, 0.0) + c
        r.const += o.const
        return r

    __radd__ = __add__

    def __neg__(self):
        return LpAffineExpression({v: -c for v, c in self.terms.items()}, -self.const)

    def __sub__(self, o):
        return self + (-LpAffineExpression.of(o))

    def __rsub__(self, o):
        return LpAffineExpression.of(o) + (-self)

    def __mul__(self, k):
        assert not isinstance(k, (LpAffineExpression, LpVariable)), '비선형 식'
        return LpAffineExpression({v: c * k for v, c in self.terms.items()}, self.const * k)

    __rmul__ = __mul__

    def __eq__(self, o):
        return LpConstraint(self - o, '=')

    def __ge__(self, o):
        return LpConstraint(self - o, '>=')

    def __le__(self, o):
        return LpConstraint(self - o, '<=')

    __hash__ = object.__hash__

    def value(self):
        return sum(v.varValue * c for v, c in self.terms.items()) + self.const


class LpVariable(LpAffineExpression):
    def __init__(self, name, lowBound=None, upBound=None, cat='Continuous'):
        assert cat == 'Continuous', '정수 변수는 지원 안 함'
        self.name, self.lowBound, self.upBound, self.varValue = name, lowBound, upBound, None

    @property
    def terms(self):
        return {self: 1.0}

    @property
    def const(self):
        return 0.0

    def copy(self):
        return LpAffineExpression({self: 1.0})

    def value(self):
        return self.varValue

    __hash__ = object.__hash__

    def __repr__(self):
        return self.name


class LpConstraint:
    def __init__(self, expr, sense):
        self.expr, self.sense = expr, sense


def lpSum(xs):
    r = LpAffineExpression()
    for x in xs:
        r = r + x
    return r


class HiGHS:
    def __init__(self, msg=False, **k):
        self.msg = msg


class LpProblem:
    def __init__(self, name='lp', sense=LpMinimize):
        self.name, self.sense, self.obj, self.cons, self.status = name, sense, LpAffineExpression(), [], 0

    def __iadd__(self, x):
        if isinstance(x, LpConstraint):
            self.cons.append(x)
        else:
            self.obj = LpAffineExpression.of(x)
        return self

    def variables(self):
        seen = {}
        for e in [self.obj] + [c.expr for c in self.cons]:
            for v in e.terms:
                seen[id(v)] = v
        return list(seen.values())

    def to_lp(self):
        fmt = lambda c: repr(float(c))
        def lin(terms):
            s = ' '.join(f"{'+' if c >= 0 else '-'} {fmt(abs(c))} {v.name}" for v, c in terms.items() if c != 0)
            return s or '0 ' + self.variables()[0].name
        out = ['Minimize' if self.sense == LpMinimize else 'Maximize', ' obj: ' + lin(self.obj.terms), 'Subject To']
        for i, c in enumerate(self.cons):
            op = {'=': '=', '>=': '>=', '<=': '<='}[c.sense]
            out.append(f' c{i}: {lin(c.expr.terms)} {op} {fmt(-c.expr.const)}')
        out.append('Bounds')
        for v in self.variables():
            lo = '-inf' if v.lowBound is None else fmt(v.lowBound)
            hi = '+inf' if v.upBound is None else fmt(v.upBound)
            out.append(f' {lo} <= {v.name} <= {hi}')
        out.append('End')
        return '\n'.join(out)

    def solve(self, solver=None):
        import js                                                # Pyodide 의 자바스크립트 연결
        R = json.loads(js.globalThis.cglHighsSolve(self.to_lp()))
        st = R.get('Status')
        self.status = 1 if st == 'Optimal' else (-1 if 'nfeasible' in str(st) else -3)
        cols = R.get('Columns') or {}
        for v in self.variables():
            v.varValue = float(cols[v.name]['Primal']) if v.name in cols else 0.0
        return self.status
