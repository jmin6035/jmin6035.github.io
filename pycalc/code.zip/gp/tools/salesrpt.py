"""호환용: 실제 코드는 cglplan/salesrpt.py (사내 PC 자동 실행기도 쓰도록 패키지로 옮김)"""
from cglplan.salesrpt import *  # noqa: F401,F403
from cglplan.salesrpt import _cell, _num  # noqa: F401
