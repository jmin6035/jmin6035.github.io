"""통합 수급계획(S&OP) — 컬러 → 도금 → 소재를 월 단위로 묶어 관장하는 상위 계획.

일별 계획(도금 MILP·컬러 스케줄러)이 '어떻게 만들지'를 정한다면, 이 계획은 '이번 달·다음 달 각 그룹을 얼마나 만들고,
재고를 어디까지 가져가며, 소재를 언제 얼마나 들여올지'를 정한다. 숫자는 전부 MES 실적·재고와 판매계획에서 계산.

조건식
  목표재고(일) = 생산주기/2 + 안전재고일
     생산주기 = 최근 13주 실적에서 (부서, 품명) 생산 회차 간격(톤 가중)
     안전재고 = z × 주간 출고 표준편차(월말 효과 제거) × √(재계획 주기 1주 + 생산 리드타임 1주) ÷ 하루 출고   (z=1.28, 서비스 90%)
        월말 효과 제거: 월말 3일이 든 주와 평상주를 따로 평균 내고, 각 평균에서 벗어난 양만 편차로 봄
        (월말 몰림은 미리 아는 패턴이라 생산계획이 따라가면 되고, 안전재고로 막을 대상은 예측 못 하는 흔들림뿐)
     컬러 건재는 계획재 EOQ 목표(사양별) + 주문재분(위 식)
  기초재고 = 재고현황 월말(마감 후), 재고일수 180일 초과·등급 5 제외
  생산량 = LP(공장별 3개월 동시): 목적 = 목표 미달 1.0 + 목표 초과 0.3 + 안전재고 미달 10 + 결품 100 + 월간 생산 증감 0.15 (t당)
     제약 = 월 능력(라인 합), 기말 = 기초 + 생산 − 판매.  → 능력이 남으면 바로 채우고(고정 1/3 아님), 능력이 모자라는 달은
     앞 달에 미리 만들며(대수리 대비 선생산이 저절로 나옴), 과잉은 바로 줄이되 생산이 한 달에 급변하지 않게 함
     (method='third' 로 예전 방식(부족분 1/3씩 3개월) 비교 가능)
  도금 자가재 판매(V1 calc) = Σ 컬러 그룹 생산 × 그룹 품명 구성 × 품명별 자가재 비중(실적 RAW_NO AA·BA, 품명마다 다름: PGS 72%, PCS 0%, POR2 100% …)
           (V2 plan) = 자가재계획 파일 월 물량 그대로(생산 고정)
  도금 원소재 입고필요_m = 도금 생산_m ÷ 실수율 + 목표 − 기말_{m−1},  발주월 = 입고월 − 리드타임
  컬러 구매소재 입고필요_m = 컬러 생산_m × (1 − 자가재 비중) + 목표 − 기말_{m−1}
실행: python tools/master_plan.py --extra extradata.json --json work/master_plan.json
"""
import argparse, calendar, datetime as dt, json, math, os, statistics as ST, sys
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, HERE)
from cglplan import color as CL  # noqa: E402
from cglplan import tables as TB
import tf_rerun as TR  # noqa: E402

TF = TR.TF
MONTHS = ['2026-10', '2026-11', '2026-12', '2027-01']
DIM = [31, 30, 31, 31]
Z, LR_WEEKS = 1.28, 2
W = {'under': 1.0, 'over': 0.3, 'safety': 10.0, 'short': 100.0, 'swing': 0.15, 'ceil': 2.0}
# 공장 월말 최대(2026-10-12·21 사용자: '27 판생그룹 목표) — 도금 판매재 = 국내·수출·자동차(자가재 제외), 컬러 제품 = 건재·수출·수요개발
from cglplan.salesrpt import STOCK_MAX  # noqa: E402
from cglplan import tfrules as TFR  # noqa: E402
PLANT_CEIL_GROUPS = {'G국내': '도금 제품(판매재)', 'G수출': '도금 제품(판매재)', 'G자동차': '도금 제품(판매재)',
                     'C건재': '컬러 제품', 'C수출': '컬러 제품', 'C수요': '컬러 제품'}
SELF_PLAN = [15880, 10640, 12600, 12600]     # 자가재계획 파일(ctx_가동_판매자가재) 10~12월, 1월은 12월 값
CAP = {  # 월 능력(t): 컬러 = color_cap()(1,440분 − 휴지 × 라인 t/hr)로 바꿔 씀 — 아래 값은 실적이 없을 때만(옛 MES 월차 10월). 도금 = 판생점검 Ver3 (12월 2CGL 대수리 14일 기준 보정)
    'color': [24417, 24417, 24417],
    'plating': [50657, 41852, 42792 + 3 * 906],
}
PLATING_YIELD = 1.008          # 판생점검 소재량 대비 생산량(가중)
COLOR_YIELD = 1.003            # 컬러 실적(제품 ÷ 소재)
MAT_TARGET = {'FH': 16000, 'CMAT': 15500}   # 판매생산속보 목표재고
LT_DAYS = {'FH': 32, 'CMAT': 45}            # P-FH 32일, 컬러 구매소재 평균(서림 65·P-GI 39·수입 60 혼합) 가정


def f(x):
    return float(x) if isinstance(x, (int, float)) else 0.0


def color_cap(ex, weeks=13):
    """컬러 월 능력(t) = 라인·일마다 (1,440분 − 휴지계획 분) × 그 라인의 최근 실적 t/hr(휴지 포함) 합.
    MES 월차로 묶지 않음(2026-10-16 사용자: 1,440분에 만들 수 있는 최대량으로 유연하게). 휴지계획 = data/color_downtime_2026Q4.json"""
    rows = (ex['tables'].get('color_prod') or {})
    cols, data = rows.get('columns') or [], rows.get('rows') or []
    if not data:
        return list(CAP['color'])
    X = [dict(zip(cols, r)) for r in data]
    d1 = max(str(x['PRD_DT'])[:10] for x in X)
    d0 = (dt.date.fromisoformat(d1) - dt.timedelta(days=7 * weeks - 1)).isoformat()
    t, h = Counter(), Counter()
    for x in X:
        if d0 <= str(x['PRD_DT'])[:10] <= d1:
            t[x['LINE']] += f(x['PDT_WGT']) / 1000
            h[x['LINE']] += (f(x['WRK_TIME']) + f(x['PAU_TIME'])) / 60
    tph = {l: t[l] / h[l] for l in t if h[l] > 0}
    p = os.path.join(ROOT, 'data', 'color_downtime_2026Q4.json')
    down = Counter()
    if os.path.exists(p):
        for it in json.load(open(p, encoding='utf-8')).get('items', []):
            down[(it['line'], it['date'])] += f(it.get('min'))
    out = []
    for m, ym in enumerate(MONTHS[:3]):
        cap = 0.0
        for l, r in tph.items():
            for d in range(1, DIM[m] + 1):
                cap += max(0.0, 1440 - down[(l, f'{ym}-{d:02d}')]) / 60 * r
        out.append(round(cap))
    return out


def measure(ex, md, d0='2026-07-06', d1='2026-10-04'):
    """실적에서 생산주기·출고 편차·자가재 비중"""
    T = ex['tables']
    ndays = (dt.date.fromisoformat(d1) - dt.date.fromisoformat(d0)).days + 1

    def runs(days):
        ds, n, prev = sorted(dt.date.fromisoformat(d) for d in days), 0, None
        for d in ds:
            if prev is None or (d - prev).days > 2:
                n += 1
            prev = d
        return max(n, 1)

    def cycle(rows):
        g, t = defaultdict(set), Counter()
        for k, d, w in rows:
            g[k].add(d); t[k] += w
        tot = sum(t.values()) or 1
        return sum(t[k] * (ndays / runs(g[k])) for k in g) / tot
    cd = CL._codes()
    cp = T['color_prod']; I = cp['columns'].index
    crow, aa = defaultdict(list), Counter()
    for r in cp['rows']:
        d = r[I('PRD_DT')]
        if not d0 <= d <= d1:
            continue
        w = f(r[I('PDT_WGT')]) / 1000
        g = 'C건재' if str(r[I('DEPT')]).startswith('컬러건재') else 'C수출'
        crow[g].append((((cd.get(r[I('PDT_NM')]) or {}).get('name', r[I('PDT_NM')]), r[I('SUR_FINISH_CD')]), d, w))
        aa[str(r[I('RAW_NO')])[:2] in ('AA', 'BA')] += w        # 원소재 번호 AA(1CGL)·BA(2CGL) = 도금 자가재
    grow = defaultdict(list)
    for c in md['coils']:
        x = dict(zip(md['coilCols'], c))
        if d0 <= x['day'] <= d1 and not x['dummy']:
            g = {'도금국내': 'G국내', '도금수출': 'G수출', '자가재': 'G자가재'}.get(x['cls'], 'G자동차' if '자동차' in str(x['cls']) else None)
            if g:
                grow[g].append((x['alloy'], x['day'], x['t']))
    cyc = {g: cycle(v) for g, v in list(crow.items()) + list(grow.items())}
    sh = T['ship']; J = sh['columns'].index
    gm = {('C', '컬러건재판매그룹', '1300'): 'C건재', ('C', '컬러수출그룹', '1300'): 'C수출', ('G', '도금판매그룹', '1300'): 'G국내',
          ('G', '도금수출그룹', '1300'): 'G수출', ('G', '자동차강판판매그룹', '1300'): 'G자동차'}
    wk = defaultdict(Counter)
    me = set()                                                   # 월말 3일이 든 주
    for r in sh['rows']:
        d = r[J('OUT_DT')]
        if not d0 <= d <= d1:
            continue
        k = gm.get((r[J('PLT_CLS')], r[J('DEPT')], r[J('OUT_RSN_CD')])) or ('G자가재' if r[J('PLT_CLS')] == 'G' and r[J('OUT_RSN_CD')] == '1360' else None)
        if k:
            x = dt.date.fromisoformat(d)
            wk[k][x.isocalendar()[1]] += f(r[J('WGT')]) / 1000
            if x.day > calendar.monthrange(x.year, x.month)[1] - 3:
                me.add(x.isocalendar()[1])
    dem = {}
    for k, v in wk.items():
        vals = [v[w] for w in sorted(v)]
        a = [v[w] for w in v if w in me]
        b = [v[w] for w in v if w not in me]
        res = [x - ST.mean(a) for x in a] + [x - ST.mean(b) for x in b]
        dem[k] = {'daily': sum(vals) / ndays, 'sdWeekRaw': ST.pstdev(vals), 'sdWeek': math.sqrt(sum(x * x for x in res) / len(res)),
                  'meanWeek': ST.mean(vals), 'meanMonthEndWeek': ST.mean(a), 'meanOtherWeek': ST.mean(b)}
    return {'cycle': cyc, 'demand': dem, 'selfShare': aa[True] / (aa[True] + aa[False]), 'substrate': substrate(ex, md, d0, d1)}


def substrate(ex, md, d0, d1):
    """컬러 품명별 원소재 중 도금 자가재(RAW_NO AA·BA) 비중과 자가재 강종 구성(도금 코일과 연결된 것 기준, 미연결분은 같은 비율로 나눔)"""
    from cglplan import color_full as CF
    alloy = {dict(zip(md['coilCols'], c))['id']: dict(zip(md['coilCols'], c))['alloy'] for c in md['coils']}
    cp = ex['tables']['color_prod']; I = cp['columns'].index
    cd = CL._codes()
    tot, own, al = Counter(), Counter(), defaultdict(Counter)
    for r in cp['rows']:
        if not d0 <= r[I('PRD_DT')] <= d1:
            continue
        raw, w = str(r[I('RAW_NO')]), f(r[I('RAW_TRE_WGT')]) / 1000
        nm = CF.base_name((cd.get(r[I('PDT_NM')]) or {}).get('name', r[I('PDT_NM')]))[0]
        tot[nm] += w
        if raw[:2] in ('AA', 'BA'):
            own[nm] += w
            a = alloy.get(raw)
            if a:
                al[nm]['AL' if a == 'AL-STS' else a] += w
    allal = Counter()
    for v in al.values():
        allal.update(v)
    out = {}
    for nm in tot:
        mix = al[nm] if sum(al[nm].values()) >= 5 else allal
        z = sum(mix.values()) or 1
        out[nm] = {'t': tot[nm], 'self': own[nm] / tot[nm] if tot[nm] else 0, 'alloy': {a: v / z for a, v in mix.items()}}
    z = sum(allal.values()) or 1
    out['_all'] = {'t': sum(tot.values()), 'self': sum(own.values()) / (sum(tot.values()) or 1), 'alloy': {a: v / z for a, v in allal.items()}}
    return out


def self_of(sub, prod):
    """품명 → (자가재 비중, 강종 구성). 실적 없는 품명은 앞 글자가 같은 품명(PGS4→PGS), 그것도 없으면 전체 평균"""
    if prod.endswith('-STS'):
        return 0.0, {}
    if prod in sub and sub[prod]['t'] >= 20:
        x = sub[prod]
    else:
        c = [k for k in sub if k != '_all' and sub[k]['t'] >= 20 and prod[:3] == k[:3] and k.endswith('-AL') == prod.endswith('-AL')]
        x = max((sub[k] for k in c), key=lambda v: v['t']) if c else sub['_all']
    return x['self'], x['alloy']


def targets(M, specs):
    out = {}
    for g, d in M['demand'].items():
        cyc = M['cycle'].get(g, 20)
        safety_t = Z * d['sdWeek'] * math.sqrt(LR_WEEKS)
        out[g] = {'cycleDays': cyc / 2, 'safetyDays': safety_t / d['daily'], 'days': cyc / 2 + safety_t / d['daily']}
    # 컬러 건재 = 계획재 EOQ 목표(톤) + 주문재분(일수 × 주문재 하루 출고)
    plan_daily = sum(s['demand'] for s in specs) / 30.4
    g = out['C건재']
    ord_daily = max(0.0, M['demand']['C건재']['daily'] - plan_daily)
    g['ordDaily'] = ord_daily
    g['planTarget'] = sum(s['target'] for s in specs)
    g['orderTarget'] = ord_daily * g['days']
    g['tons'] = g['planTarget'] + g['orderTarget']
    g['days'] = g['tons'] / M['demand']['C건재']['daily']
    return out


class _SD(defaultdict):
    pass


def sales_plan():
    """TF 판매계획 → 그룹별 월 판매(26.10~27.1), 그룹별 품명 구성 MIX[g] = [(품명, 고객·지역, 컬러그룹, [4개월 톤])]"""
    import openpyxl
    from cglplan import color_full as CF
    wb = openpyxl.load_workbook(TF, read_only=True, data_only=True)
    cs = list(wb['컬러_판매계획'].iter_rows(values_only=True))
    S = _SD(lambda: [0.0] * 4)
    MIX = defaultdict(list)

    def add(g, r, cg):
        v = [f(r[5 + i]) for i in range(4)]
        for i in range(4):
            S[g][i] += v[i]
        MIX[g].append((CF.base_name(r[2])[0], str(r[3] or ''), cg, v))
    for r in cs[183:225]:
        add('C건재', r, '주문재')
    for lo, hi in ((231, 279), (283, 297)):
        for r in cs[lo:hi]:
            if r[0] and r[0] != '합계':
                add('C수출', r, '가전내수' if lo == 283 else ('건재수출' if '건재' in str(r[0]) else '가전수출'))
    for r in cs[301:311]:
        if r[0] and r[0] != '합계':
            add('C수요', r, '수요개발')
    ps = list(wb['도금_판매계획'].iter_rows(values_only=True))
    for r in ps[5:40]:
        if not r[0] or r[0] == '합계':
            continue
        g = {'도금국내': 'G국내', '도금수출': 'G수출'}.get(r[0], 'G자동차')
        for i in range(4):
            S[g][i] += f(r[5 + i])
        if g == 'G자동차':                                       # TF 목표 일수 구분(AL-STS 30 · 임가공 15 · 그 외 45)
            k = '임가공' if str(r[1] or '') == '임가공' else ('AL-STS' if str(r[2] or '').startswith('AL-STS') else '기타')
            MIX['G자동차'].append((str(r[2] or ''), str(r[1] or ''), k, [f(r[5 + i]) for i in range(4)]))
    S.mix = MIX
    return S


SECTION = {'주문재': '컬러건재', '계획재': '컬러건재', '건재수출': '컬러수출-건재', '가전수출': '컬러수출-가전(수출)',
           '가전내수': '컬러수출-가전', '수요개발': '수요개발'}


def self_alloy(sub, prod, cust, cgroup):
    """컬러 1t 생산에 드는 도금 자가재 (구역, 강종) → t. LG 향 가전 AL 은 AL-LG"""
    sh, mix = self_of(sub, prod)
    sec = SECTION[cgroup]
    lg = cgroup == '가전내수' and ('엘지' in cust or 'LG' in cust.upper())
    out = Counter()
    for a, w in mix.items():
        if lg and a == 'AL':
            out[('컬러수출-가전(LG향)', 'AL-LG')] += sh * w
        else:
            out[(sec, a)] += sh * w
    return out


def self_coef(S, sub):
    """컬러 그룹 1t 생산당 자가재 t (판매 구성 가중), 월별"""
    K = {}
    for g, rows in S.mix.items():
        if not g.startswith('C'):                       # 도금 그룹 구성(자동차 AL-STS 등)은 TF 일수용 — 자가재 계수 대상 아님
            continue
        K[g] = []
        for i in range(4):
            tot = sum(v[i] for *_, v in rows)
            K[g].append(sum(v[i] * sum(self_alloy(sub, p, c, cg).values()) for p, c, cg, v in rows) / tot if tot else 0)
    return K


def begin_stock(ex, specs):
    P, excl = TR.pools_from_stock(ex['tables']['snap_stock'], specs)
    B = Counter()
    for k, v in P.items():
        if k[0] in ('계획재', '주문재'):
            B['C건재'] += v
        elif k[0] in ('수출', '내수'):
            B['C수출'] += v
        elif k[0] == '수요':
            B['C수요'] += v
        elif k[0] == '자가재':
            B['G자가재'] += v
        else:
            B[{'도금국내': 'G국내', '도금수출': 'G수출', '도금자동차': 'G자동차'}[k[0]]] += v
    T = [dict(zip(ex['tables']['snap_stock']['columns'], r)) for r in ex['tables']['snap_stock']['rows'] if r[0] == '202609']
    mat = Counter()
    aged = Counter()
    for r in T:
        t = f(r['중량']) / 1000
        bad = f(r['재고일수']) > 180 or str(r['제품등급']).strip() == '5'
        if r['구분명'] == 'R' and not bad:
            if r['공장구분'] == 'G':
                mat['FH'] += t
            elif r['자가재구분'] != '자가재':
                mat['CMAT'] += t
        if r['구분명'] == 'P' and 90 < f(r['재고일수']) <= 180:
            aged[r['공장구분']] += t
    return B, mat, aged


# TF 목표 일수(2026-09-30 확정, 2026-10-12 사용자: 일별계획은 TF 목표 일수 기준 · 월말 최대는 '27 판생그룹 목표 cglplan.salesrpt.STOCK_MAX)
TF_DAYS = TFR.DAYS     # 값 = cglplan/tf_rules.json(포털 '재고 목표 기준'에서 고침 → tools/tf_rules.py pull, 2026-10-22)


def tf_days(g, m, S):
    """그룹의 TF 목표 일수(m 월 판매 구성 가중) — 컬러 수출 = 건재수출·가전수출 15·가전내수 30, 자동차 = AL-STS 30·임가공 15·그 외 45"""
    if g in TF_DAYS:
        return TF_DAYS[g]
    if g == 'C수요':
        return TF_DAYS['수요개발']
    mix = [(TF_DAYS.get(cg, 20), v[min(m, 3)]) for _, _, cg, v in getattr(S, 'mix', {}).get(g, [])]
    tot = sum(v for _, v in mix)
    return sum(d * v for d, v in mix) / tot if tot else 20


def tf_target(g, m, S, TG):
    """m 월말 목표재고(t) — TF 목표 일수 × 다음 달 하루 판매. 컬러 건재 = 계획재 EOQ 목표(판매 증감 비례) + 주문재 20일"""
    n = min(m + 1, 3)
    daily_next = S[g][n] / DIM[n]
    if g == 'C건재':
        t = TG.get(g) or {}
        k = S[g][n] / max(S[g][m], 1)
        od = t.get('ordDaily')
        if od is None and t.get('orderTarget'):                  # 예전 결과 파일(ordDaily 없음): 주문재분 = 하루 × (주기/2 + 안전 일수)
            od = t['orderTarget'] / max(t.get('cycleDays', 0) + t.get('safetyDays', 0), 1)
        return (t.get('planTarget', 0) + TF_DAYS['주문재'] * (od or 0)) * k
    return tf_days(g, n, S) * daily_next


TARGET_MODE = os.environ.get('CGL_TARGET_MODE', 'tf')     # 도금: 'tf' = TF 목표 일수(2026-10-22 사용자 '도금도 tf 규칙으로') · 'cycle' = 예전(생산주기/2 + 안전재고)
TARGET_MODE_C = os.environ.get('CGL_TARGET_MODE_C', 'cycle')   # 컬러: 월 물량 LP 가 9월말 재고에서 출발해 실제 과재고를 몰라 TF 로 바꾸면 생산이 오히려 늘어 보류(10/21 비교)


def tgt_tons(g, m, S, TG):
    """m 월말 목표재고(t), 안전재고(t). 목표 = TF 목표 일수 × 다음 달 하루 판매(tf_target). 안전재고는 그대로(측정 변동 기준)"""
    T, SS = tgt_cycle(g, m, S, TG)
    mode = TARGET_MODE_C if g.startswith('C') else TARGET_MODE
    return (tf_target(g, m, S, TG) if mode == 'tf' else T), SS


def tgt_cycle(g, m, S, TG):
    """예전 목표 — 일수(생산주기/2 + 안전) × 다음 달 하루 판매 (컬러 건재는 EOQ 톤을 판매 증감에 비례)"""
    nxt = S[g][min(m + 1, 3)]
    daily_next = nxt / DIM[min(m + 1, 3)]
    t = TG.get(g) or {'days': 0, 'safetyDays': 0}
    if g == 'C건재':
        k = nxt / max(S[g][m], 1)
        return t['tons'] * k, t['safetyDays'] * daily_next
    return t['days'] * daily_next, t.get('safetyDays', 0) * daily_next


def lp_plant(groups, S, B, TG, cap, fixed=None, prev=None):
    """공장 하나의 3개월 그룹별 생산량 LP. fixed: {g: [3개월 생산]} 고정, prev: {g: 직전 월 생산(증감 기준)}"""
    import pulp
    fixed, prev = fixed or {}, prev or {}
    M3 = range(3)
    pr = pulp.LpProblem('sop', pulp.LpMinimize)
    V = lambda n: {(g, m): pulp.LpVariable(f'{n}_{gi}_{m}', 0) for gi, g in enumerate(groups) for m in M3}
    p, un, ov, sv, sh, up, dn = V('p'), V('un'), V('ov'), V('sv'), V('sh'), V('up'), V('dn')
    obj = []
    for g in groups:
        e = B.get(g, 0.0)
        for m in M3:
            if g in fixed:
                pr += p[g, m] == fixed[g][m]
            e = e + p[g, m] - S[g][m]
            T, SS = tgt_tons(g, m, S, TG)
            pr += e - T == ov[g, m] - un[g, m]
            pr += e + sv[g, m] >= SS
            pr += e + sh[g, m] >= 0
            ref = p[g, m - 1] if m else prev.get(g, S[g][0])
            pr += p[g, m] - ref == up[g, m] - dn[g, m]
            obj += [W['under'] * un[g, m], W['over'] * ov[g, m], W['safety'] * sv[g, m], W['short'] * sh[g, m], W['swing'] * (up[g, m] + dn[g, m])]
    for m in M3:
        pr += pulp.lpSum(p[g, m] for g in groups) <= cap[m]
    ceil_g = [g for g in groups if g in PLANT_CEIL_GROUPS]      # 공장 월말 최대('27 판생그룹 목표) — 그룹 목표보다 우선(가중 2 > 미달 1)
    if ceil_g:
        lim = STOCK_MAX[PLANT_CEIL_GROUPS[ceil_g[0]]]
        for m in M3:
            cx = pulp.LpVariable(f'ceil_{m}', 0)
            pr += pulp.lpSum(B.get(g, 0.0) + pulp.lpSum(p[g, k] - S[g][k] for k in range(m + 1)) for g in ceil_g) - lim <= cx
            obj.append(W['ceil'] * cx)
    pr += pulp.lpSum(obj)
    pr.solve(pulp.HiGHS(msg=False))
    assert pulp.LpStatus[pr.status] == 'Optimal', pulp.LpStatus[pr.status]
    rows = {}
    for g in groups:
        e, rows[g] = B.get(g, 0.0), []
        for m in M3:
            q = p[g, m].value()
            e = e + q - S[g][m]
            T, SS = tgt_tons(g, m, S, TG)
            dn_ = S[g][min(m + 1, 3)] / DIM[min(m + 1, 3)]
            rows[g].append({'month': MONTHS[m], 'sales': S[g][m], 'prod': q, 'end': e, 'endDays': e / dn_ if dn_ else None,
                            'target': T, 'safety': SS, 'short': sh[g, m].value()})
    util = [sum(rows[g][m]['prod'] for g in groups) / cap[m] for m in M3]
    return rows, util


def simulate_third(S, B, TG, M, cap):
    """예전 방식(부족분 1/3씩 3개월 + 능력 초과 시 앞 달 선생산) — 비교용"""
    res = {}

    def plant(groups, cap_m, sales_of, extra=None):
        extra = extra or {}
        end = {g: B[g] for g in groups}
        gap0 = {}
        rows = {g: [] for g in groups}
        for m in range(3):
            req, base, build = {}, {}, {}
            for g in groups:
                s = sales_of(g, m)
                tgt = tgt_tons(g, m, S, TG)[0]
                gap = tgt - end[g]
                if m == 0:
                    gap0[g] = max(0.0, gap)
                b = min(gap, gap0[g] / 3) if gap > 0 else gap
                base[g], build[g] = s, b
                req[g] = max(0.0, s + b) + extra.get((g, m), 0.0)
            tot = sum(req.values())
            short = 0.0
            if tot > cap_m[m]:
                over = tot - cap_m[m]
                bp = sum(max(0.0, build[g]) for g in groups)
                cut = min(over, bp)
                for g in groups:
                    if build[g] > 0 and bp:
                        req[g] -= cut * build[g] / bp
                over -= cut
                if over > 1e-6:
                    short = over
                    sb = sum(req.values())
                    for g in groups:
                        req[g] -= over * req[g] / sb
            for g in groups:
                s = base[g]
                end[g] = end[g] + req[g] - s
                dn_ = sales_of(g, m + 1) / DIM[m + 1]
                rows[g].append({'month': MONTHS[m], 'sales': s, 'prod': req[g], 'end': end[g], 'endDays': end[g] / dn_ if dn_ else None,
                                'target': tgt_tons(g, m, S, TG)[0]})
            res.setdefault('_short', {})[(groups[0][0], m)] = short
            rows['_req'] = rows.get('_req', []) + [dict(req)]
        return rows

    def plant_pre(groups, cap_m, sales_of):
        extra = {}
        for _ in range(8):
            rows = plant(groups, cap_m, sales_of, extra)
            sh = [res['_short'][(groups[0][0], m)] for m in range(3)]
            if not any(v > 1 for v in sh):
                break
            for m in range(2, 0, -1):
                if sh[m] <= 1:
                    continue
                need = sh[m]
                for k in range(m - 1, -1, -1):
                    spare = cap_m[k] - sum(rows['_req'][k].values())
                    mv = min(need, max(0.0, spare))
                    tot = sum(sales_of(g, m) for g in groups) or 1
                    for g in groups:
                        extra[(g, k)] = extra.get((g, k), 0.0) + mv * sales_of(g, m) / tot
                    need -= mv
                    if need <= 1:
                        break
        rows.pop('_req', None)
        return rows
    C = plant_pre(['C건재', 'C수출', 'C수요'], cap['color'], lambda g, m: S[g][min(m, 3)])
    res.update(C)
    color_prod = [sum(C[g][m]['prod'] for g in C) for m in range(3)] + [sum(C[g][2]['prod'] for g in C)]
    S['G자가재'] = [p * M['selfShare'] / COLOR_YIELD for p in color_prod]
    G = plant_pre(['G국내', 'G수출', 'G자동차', 'G자가재'], cap['plating'], lambda g, m: S[g][min(m, 3)])
    res.update(G)
    return {g: v for g, v in res.items() if not g.startswith('_')}


def simulate(S, B, TG, M, cap, self_mode='calc'):
    """컬러 LP → 자가재 판매(품명별 비중 또는 자가재계획) → 도금 LP"""
    C, cu = lp_plant(['C건재', 'C수출', 'C수요'], S, B, TG, cap['color'])
    K = self_coef(S, M['substrate'])
    cprod = {g: [C[g][m]['prod'] for m in range(3)] + [S[g][3]] for g in C}
    if self_mode == 'calc':
        S['G자가재'] = [sum(cprod[g][m] * K[g][m] for g in C) / COLOR_YIELD for m in range(4)]
        fixed = None
    else:
        S['G자가재'] = list(SELF_PLAN)
        fixed = {'G자가재': SELF_PLAN[:3]}
    G, gu = lp_plant(['G국내', 'G수출', 'G자동차', 'G자가재'], S, B, TG, cap['plating'], fixed)
    res = dict(C); res.update(G)
    color_prod = [sum(C[g][m]['prod'] for g in C) for m in range(3)] + [sum(cprod[g][3] for g in C)]
    return res, color_prod, {'C': cu, 'G': gu}, K


def materials(res, mat, M, color_prod):
    out = {}
    plat = [sum(res[g][m]['prod'] for g in ('G국내', 'G수출', 'G자동차', 'G자가재')) for m in range(3)]
    for key, use in (('FH', [p / PLATING_YIELD for p in plat]), ('CMAT', [p * (1 - M['selfShare']) / COLOR_YIELD for p in color_prod[:3]])):
        stock, rows = mat[key], []
        gap0 = max(0.0, MAT_TARGET[key] - stock)
        for m in range(3):
            gap = MAT_TARGET[key] - stock
            b = min(gap, gap0 / 3) if gap > 0 else gap          # 부족은 3개월에 나눠, 과잉은 바로 줄임
            need_in = max(0.0, use[m] + b)
            stock = stock + need_in - use[m]
            order_month = (dt.date.fromisoformat(MONTHS[m] + '-15') - dt.timedelta(days=LT_DAYS[key])).strftime('%Y-%m')
            rows.append({'month': MONTHS[m], 'use': use[m], 'arrive': need_in, 'orderBy': order_month, 'end': stock})
        out[key] = {'begin': mat[key], 'rows': rows}
    return out


def run(ex, md, self_mode='calc'):
    specs = CL.load_specs(TR.EOQ)
    M = measure(ex, md)
    TG = targets(M, specs)
    TG['C수요'] = {'days': 0, 'tons': 0, 'safetyDays': 0}
    S = sales_plan()
    B, mat, aged = begin_stock(ex, specs)
    cap = {'color': color_cap(ex), 'plating': CAP['plating']}
    res, cprod, util, K = simulate(S, B, TG, M, cap, self_mode)
    S2 = sales_plan()
    old = simulate_third(S2, B, TG, M, cap)                     # 예전 방식 비교
    return {'selfMode': self_mode, 'measure': M, 'targets': TG, 'sales': {k: v for k, v in S.items()}, 'begin': dict(B),
            'material': materials(res, mat, M, cprod), 'aged': dict(aged), 'matBegin': dict(mat),
            'plan': res, 'util': util, 'colorProd': cprod[:3], 'cap': cap, 'selfCoef': K, 'third': old,
            'mix': {g: v for g, v in S.mix.items()}}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--extra', required=True)
    ap.add_argument('--mesdata', required=True)
    ap.add_argument('--self', default='calc', choices=['calc', 'plan'])
    ap.add_argument('--json')
    a = ap.parse_args()
    R = run(TB.load_extra(a.extra), json.load(open(a.mesdata, encoding='utf-8')), a.self)
    for g, d in R['measure']['demand'].items():
        print(g, f"σ주 {d['sdWeekRaw']:.0f} → 월말효과 제거 {d['sdWeek']:.0f}")
    for g, t in R['targets'].items():
        print(g, {k: round(v, 1) for k, v in t.items()})
    print('자가재 계수(컬러 1t당)', {g: [round(x, 3) for x in v] for g, v in R['selfCoef'].items()})
    for g, rows in R['plan'].items():
        print(g, '기초', round(R['begin'].get(g, 0)), [(r['month'][5:], round(r['sales']), round(r['prod']), round(r['end']), round(r['endDays'] or 0, 1), round(r['target'])) for r in rows])
    print('가동률', {k: [round(x, 3) for x in v] for k, v in R['util'].items()})
    print('예전 방식(1/3) 생산', {g: [round(r['prod']) for r in rows] for g, rows in R['third'].items()})
    for k, v in R['material'].items():
        print(k, '기초', round(v['begin']), [(r['month'][5:], round(r['use']), round(r['arrive']), r['orderBy'], round(r['end'])) for r in v['rows']])
    if a.json:
        json.dump(R, open(a.json, 'w', encoding='utf-8'), ensure_ascii=False, indent=1, default=str)


if __name__ == '__main__':
    main()
