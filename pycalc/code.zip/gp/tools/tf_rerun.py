"""TF 일별가동계획 엑셀의 생산필요량 계산(재고일수 기준)을 우리 9월말 재고로 다시 돌려 TF 값과 비교.

TF 식(셀 그대로): 목표기말_m = 다음달 판매 × 목표일수 ÷ 다음달 일수
                 생산필요_m = MAX(0, 판매_m + 목표기말_m − 기말_{m−1}),  기말_m = 기말_{m−1} + 생산필요_m − 판매_m
주문재: 생산필요 − 같은 품명 계획재 생산(≥0) 후 '월 생산량 − 계획재' 로 조정(조정계수) — 조정 전·후 둘 다 계산
기초재고: 재고현황 9월말(9/30 마감, 9/30 출하 차감 후). TF 와 같은 제외 기준(재고일수 180일 초과, 등급 5)
풀 배분: 같은 풀(구역·품명) 재고를 10·11월 판매 비중으로 행에 나눔(TF 기초재고_산출과 같은 방식)
실행: python tools/tf_rerun.py --extra extradata.json [--json work/tf_rerun.json]
"""
import argparse, json, os, sys
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
from cglplan import color as CL, color_full as CF  # noqa: E402
from cglplan import tables as TB

TF = os.path.join(ROOT, 'data', 'color', 'TF_컬러도금_일별가동계획_26.10-27.3.xlsx')
EOQ = os.path.join(ROOT, 'data', 'color', 'TF_계획재_사양별_EOQ_추천반순_요약.xlsx')
DIM = [31, 30, 31, 31, 28, 31, 30]          # 26.10 ~ 27.4
MONTHS = ['26.10', '26.11', '26.12', '27.1', '27.2', '27.3']
G_PROD = {'GAL': 'ALCOSTA', 'GAT': 'ALCOSTA', 'GGL': 'AZ', 'GGM': 'PosMAC', 'GAS': 'AL-STS'}


def f(x):
    return float(x) if isinstance(x, (int, float)) else 0.0


def pools_from_stock(snap, specs, month='202609'):
    T = [dict(zip(snap['columns'], r)) for r in snap['rows'] if r[0] == month]
    m = CL.Matcher(specs)
    P, excl = Counter(), Counter()
    for r in T:
        t = f(r['중량']) / 1000
        pl, kind, dept = r['공장구분'], r['구분명'], str(r['담당부서(HR)'] or '')
        own = r['자가재구분'] == '자가재'
        bad = f(r['재고일수']) > 180 or str(r['제품등급']).strip() == '5'
        key = None
        if pl == 'C' and kind == 'P':
            prod, mac = CF.base_name(m.nm(r['품명코드']))[0], str(r['도금량'] or '').startswith('M')
            if dept.startswith('컬러건재판매'):
                key = ('계획재',) if m(r['품명코드'], f(r['제품두께']), f(r['제품폭']), r['표면상도코드'], tolt=0.02) else ('주문재', prod, mac)
            elif dept.startswith('컬러수출'):
                key = ('수출', '컬러건재수출' if '수출1' in dept else '컬러가전수출', prod) if str(r['고객사'] or '').startswith('J') else ('내수', prod)
            elif dept.startswith('수요개발'):
                key = ('수요', prod)
        elif pl == 'G' and kind == 'P':
            prod = G_PROD.get(str(r['품명코드']), str(r['품명코드']))
            if own:
                sec = '컬러건재' if dept.startswith('컬러건재') else ('컬러수출-건재섹션' if '수출1' in dept else ('수요개발' if dept.startswith('수요') else '컬러수출-가전섹션'))
                key = ('자가재', sec, prod)
            else:
                d = '도금국내' if dept.startswith('도금판매') else ('도금수출' if dept.startswith('도금수출') else ('도금자동차' if dept.startswith('자동차') else None))
                key = (d, prod) if d else None
        elif pl == 'C' and kind == 'R' and own:                # 컬러 투입 대기 자가재(소재)
            prod = {'A': 'AZ', 'M': 'PosMAC'}.get(str(r['도금량'] or ' ')[0], 'ALCOSTA')
            sec = '컬러건재' if dept.startswith('컬러건재') else ('컬러수출-건재섹션' if '수출1' in dept else ('수요개발' if dept.startswith('수요') else '컬러수출-가전섹션'))
            key = ('자가재', sec, prod)
        if key is None:
            continue
        (excl if bad else P)[key] += t
    return P, excl


def simulate(sales, begin, days, sub=None):
    """sales: 7개월(26.10~27.4) 판매, begin: 기초재고 → (생산필요 6개월, 기말 6개월, 목표 6개월)"""
    sub = sub or [0] * 7
    end, need, ends, tgts = begin, [], [], []
    for i in range(6):
        nxt = max(0.0, sales[i + 1] - sub[i + 1]) if sub != [0] * 7 else sales[i + 1]
        tg = nxt * days / DIM[i + 1]
        n = max(0.0, sales[i] + tg - end)
        end = end + n - sales[i]
        need.append(n); ends.append(end); tgts.append(tg)
    return need, ends, tgts


def run(ex):
    import openpyxl
    wb = openpyxl.load_workbook(TF, read_only=True, data_only=True)
    specs = CL.load_specs(EOQ)
    P, excl = pools_from_stock(ex['tables']['snap_stock'], specs)
    out = []
    # ---- 컬러 ③ 주문재 (행 184~225)
    cs = list(wb['컬러_판매계획'].iter_rows(values_only=True))
    monthly_total = [f(x) for x in cs[5][5:11]]
    plan_total = [f(x) for x in cs[177][5:11]]
    rows = []
    for r in cs[183:225]:
        prod, mac = CF.base_name(r[2])
        sales = [f(x) for x in r[5:11]] + [f(r[10])]
        plan = [f(x) for x in r[13:19]] + [f(r[18])]
        rows.append({'g': '주문재', 'name': r[2], 'key': ('주문재', prod, mac), 'sales': sales, 'plan': plan, 'days': f(r[45]) or 20,
                     'tfBegin': f(r[44]), 'tfNeed': [f(x) for x in r[53:59]], 'tfT': [f(x) for x in r[19:25]], 'tfAdj': [f(x) for x in r[25:31]]})
    # ---- 컬러 ④ 수출 (232~279), ⑤ 가전내수 (284~297), ⑥ 수요개발 (302~311)
    for lo, hi, kind in ((231, 279, '수출'), (283, 297, '내수'), (301, 311, '수요')):
        for r in cs[lo:hi]:
            if not r[0] or r[0] == '합계':
                continue
            prod = CF.base_name(r[2])[0]
            sales = [f(x) for x in r[5:12]] if kind == '수출' else [f(x) for x in r[5:11]] + [f(r[10])]
            key = ('수출', r[0], prod) if kind == '수출' else ((kind, prod))
            g = {'수출': r[0], '내수': '컬러가전내수', '수요': '수요개발'}[kind]
            rows.append({'g': g, 'name': f'{r[2]} {r[3]}', 'key': key, 'sales': sales, 'days': f(r[29]) or 15, 'tfBegin': f(r[28]),
                         'tfNeed': [f(x) for x in r[38:44]]})
    # ---- 도금 ① (6~40), ② 자가재 (46~63)
    ps = list(wb['도금_판매계획'].iter_rows(values_only=True))
    for r in ps[5:40]:
        if not r[0] or r[0] == '합계':
            continue
        d = {'도금국내': '도금국내', '도금수출': '도금수출'}.get(r[0], '도금자동차')
        rows.append({'g': d, 'name': f'{r[1]} {r[2]} {r[3]}', 'key': (d, r[2]), 'sales': [f(x) for x in r[5:12]], 'days': f(r[29]) or 15,
                     'tfBegin': f(r[28]), 'tfNeed': [f(x) for x in r[38:44]], 'imga': r[1] == '임가공'})
    for r in ps[45:63]:
        if not r[0] or r[0] == '합계':
            continue
        prod = {'AZ': 'AZ', 'PosMAC': 'PosMAC', 'ALCOSTA': 'ALCOSTA'}.get(r[2], r[2])
        rows.append({'g': '도금자가재', 'name': f'{r[1]} {r[2]} {r[3]}', 'key': ('자가재', r[1], prod), 'sales': [f(x) for x in r[5:11]] + [f(r[10])],
                     'days': f(r[29]) or 15, 'tfBegin': f(r[28]), 'tfNeed': [f(x) for x in r[38:44]]})
    # ---- 풀 배분(10·11월 판매 비중)
    pool_s = Counter()
    for x in rows:
        pool_s[x['key']] += x['sales'][0] + x['sales'][1]
    used = set()
    for x in rows:
        w = (x['sales'][0] + x['sales'][1]) / pool_s[x['key']] if pool_s[x['key']] else 0
        if not pool_s[x['key']]:                      # 판매 없는 풀은 첫 행에
            w = 0 if x['key'] in used else 1
        used.add(x['key'])
        x['begin'] = P.get(x['key'], 0) * w
        if x['g'] == '주문재':
            need, ends, tg = simulate(x['sales'], x['begin'], x['days'], x['plan'])
            x['need'] = need
            x['T'] = [max(0.0, n - p) for n, p in zip(need, x['plan'])]
        else:
            need, ends, tg = simulate(x['sales'], x['begin'], x['days'])
            x['need'] = need
        x['end'], x['tgt'] = ends, tg
    # 주문재 조정계수(TF: 월 생산량 − 계획재) — 우리 T 합계에 같은 방식 적용
    js = [sum(x['T'][i] for x in rows if x['g'] == '주문재') for i in range(6)]
    for x in rows:
        if x['g'] == '주문재':
            x['adj'] = [x['T'][i] * ((monthly_total[i] - plan_total[i]) / js[i] if js[i] else 0) for i in range(6)]
    pooled = sum(P.values())
    return {'rows': rows, 'pools': P, 'excl': excl, 'monthlyTotal': monthly_total, 'planTotal': plan_total, 'pooled': pooled}


def summary(R):
    G = ['주문재', '컬러건재수출', '컬러가전수출', '컬러가전내수', '수요개발', '도금국내', '도금수출', '도금자동차', '도금자가재']
    S = {}
    for g in G:
        xs = [x for x in R['rows'] if x['g'] == g]
        if not xs:
            continue
        k = 'T' if g == '주문재' else 'need'
        tk = 'tfT' if g == '주문재' else 'tfNeed'
        S[g] = {'tfBegin': sum(x['tfBegin'] for x in xs), 'begin': sum(x['begin'] for x in xs),
                'tf': [sum(x[tk][i] for x in xs) for i in range(6)], 'ours': [sum(x[k][i] for x in xs) for i in range(6)],
                'sales': [sum(x['sales'][i] for x in xs) for i in range(6)], 'endOurs': [sum(x['end'][i] for x in xs) for i in range(6)]}
        if g == '주문재':
            S[g]['tfAdj'] = [sum(x['tfAdj'][i] for x in xs) for i in range(6)]
            S[g]['adj'] = [sum(x['adj'][i] for x in xs) for i in range(6)]
    return S


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--extra', required=True)
    ap.add_argument('--json')
    a = ap.parse_args()
    R = run(TB.load_extra(a.extra))
    S = summary(R)
    print('그룹 | 기초 TF→우리 | 10월 생산필요 TF→우리 | 6개월 합 TF→우리')
    for g, s in S.items():
        print(f"{g} | {s['tfBegin']:,.0f} → {s['begin']:,.0f} | {s['tf'][0]:,.0f} → {s['ours'][0]:,.0f} | {sum(s['tf']):,.0f} → {sum(s['ours']):,.0f}")
    if a.json:
        json.dump({'summary': S, 'excluded': {' / '.join(map(str, k)): v for k, v in R['excl'].items()}}, open(a.json, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)


if __name__ == '__main__':
    main()
