"""컬러 휴지계획 엑셀(구분 × 월 × 라인: 일자·시간) → data/color_downtime_2026Q4.json

엑셀 양식: 2행 = 월('26.10월 …), 3행 = 라인(1~4CCL), 4행 = 일자/시간(min), 5행~ = 구분(계획휴지 · S/D · 수리/보수 · 청소(오븐등) · Test · 샘플).
일자는 '19일' 또는 '13일~16일'(여러 날이면 시간을 날짜 수로 나눔). 하루 1,440분을 넘는 값은 1,440분으로 자르고 확인 목록에 남김.
    python3 tools/color_downtime.py <엑셀> [--out data/color_downtime_2026Q4.json]
"""
import argparse
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KINDS = {'계획휴지': 'plan', 'S/D': 'sd', '수리/보수': 'repair', '청소(오븐등)': 'clean', 'Test': 'test', '샘플': 'sample'}
HARD = ('plan', 'sd', 'repair')          # 라인 전체 정지(표시 구분용)
SPEED_KINDS = ('test',)                  # 2026-10-21 사용자: Test = MES 4198 단판휴지 → 속도에 포함(막지 않음, 화면엔 표시)
ROUTINE = ('clean', 'test', 'sample')    # 하루 안의 정지(표시 구분용) — 막는 규칙은 blocks()


def parse(path):
    import openpyxl
    ws = openpyxl.load_workbook(path, data_only=True).worksheets[0]
    cols = {}                                                    # 열 번호 → (YYYY-MM, 라인)
    month = None
    for c in range(3, ws.max_column + 1, 2):
        mv = ws.cell(2, c).value
        if mv:
            mm = re.search(r"(\d\d)\.(\d+)월", str(mv))
            month = f"20{mm.group(1)}-{int(mm.group(2)):02d}"
        ln = ws.cell(3, c).value
        if month and ln:
            cols[c] = (month, str(ln).strip())
    items, notes = [], []
    kind = None
    for r in range(5, ws.max_row + 1):
        k = ws.cell(r, 2).value
        if k:
            kind = KINDS.get(str(k).strip())
        if not kind:
            continue
        for c, (ym, line) in cols.items():
            d, mn = ws.cell(r, c).value, ws.cell(r, c + 1).value
            if not d:
                continue
            ds = [int(x) for x in re.findall(r'(\d+)일', str(d))]
            days = list(range(ds[0], ds[-1] + 1)) if len(ds) == 2 else ds
            if mn in (None, ''):
                same = [it['min'] for it in items if it['line'] == line and it['kind'] == kind and it['date'][:7] == ym]
                mn = same[-1] if same else 0
                notes.append(f"{ym} {line} {k or kind} {d}: 시간 빈칸 → 같은 달 같은 구분 값 {mn}분으로 가정")
            mn = float(mn)
            per = mn / len(days)
            if per > 1440:
                notes.append(f"{ym} {line} {d} {mn:.0f}분 — 하루 1,440분 초과, 1,440분으로 자름(오타 확인)")
                per = 1440
            for dd in days:
                items.append({'date': f"{ym}-{dd:02d}", 'line': line, 'kind': kind, 'min': round(per, 1), 'src': f"{d} {mn:.0f}분"})
    return items, notes


def blocks(items, hist, start):
    """{(날짜, 라인): 막을 분} — start 이후만.
    2026-10-21 사용자(단위생산량 엑셀 기준): 휴지계획 항목은 계획정지(1000~2999) → 계획한 날 그 시간을 그대로 막음.
    단 Test 는 MES 4198(단판휴지)로 찍혀 속도(kg/min)에 이미 들어 있으므로 막지 않음(이중 차감 방지). hist 는 쓰지 않음(옛 '평균 초과분' 방식 폐기)"""
    out = {}
    for it in items:
        if it['date'] >= start and it['kind'] not in SPEED_KINDS:
            out[(it['date'], it['line'])] = min(1440, out.get((it['date'], it['line']), 0) + it['min'])
    return out, []


def history(T, months=('202607', '202608', '202609')):
    """지난 3개월 라인별 월평균 정지(분): 테스트·샘플(휴지 구성 '테스트·도막조정' + 샘플) / 청소(오븐·OVEN)"""
    from cglplan import pages as PG
    B = {'X': '1CCL', 'Y': '2CCL', 'Z': '3CCL', 'W': '4CCL'}
    h = {}
    for r in PG._rows(T, 'color_brk'):
        d, l = str(r.get('WRK_DT') or ''), B.get(r.get('LINE_CLS'))
        if not l or d[:6] not in months:
            continue
        rem = str(r.get('SPL_REM') or '').upper()
        t = PG.f(r['PAU_TIME']) / len(months)
        if PG.stop_cat(r.get('SPL_REM')) == '테스트·도막조정' or any(k in rem for k in ('샘플', 'SAMPLE')):   # 실적 화면 휴지 구성과 같은 분류
            h[(l, 'test')] = h.get((l, 'test'), 0) + t
        elif '오븐' in rem or 'OVEN' in rem:
            h[(l, 'clean')] = h.get((l, 'clean'), 0) + t
    return h


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('xlsx')
    ap.add_argument('--out', default=os.path.join(ROOT, 'data', 'color_downtime_2026Q4.json'))
    a = ap.parse_args()
    items, notes = parse(a.xlsx)
    json.dump({'src': os.path.basename(a.xlsx), 'items': items, 'notes': notes,
               'rule': '계획휴지·S/D·수리 = 라인 정지(그대로 막음). 청소·Test·샘플 = 평소 정지라 지난 3개월 월평균을 넘는 만큼만 막음(실적 t/hr 에 평균 정지가 이미 들어 있음)'},
              open(a.out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    import shutil                                                               # 사내 PC 화면 자료용 사본(설치 묶음에 포함)
    shutil.copy(a.out, os.path.join(ROOT, 'cglplan', 'pages_base', 'color_downtime.json'))
    by = {}
    for it in items:
        by[(it['date'][:7], it['line'], it['kind'])] = by.get((it['date'][:7], it['line'], it['kind']), 0) + it['min']
    for k in sorted(by):
        print(k, round(by[k]))
    print('\n'.join(notes))
    print('→', a.out, len(items), '건')


if __name__ == '__main__':
    sys.path.insert(0, ROOT)
    main()
