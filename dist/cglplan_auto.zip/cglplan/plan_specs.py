"""계획재 사양 목록(6개월마다 바뀔 수 있음 — 사용자 11/3). 원본 = data/plan_specs/<판>.json, 지금 쓰는 판 = data/plan_specs/current.json 'active'.
  python3 tools/plan_specs.py                 지금 판 요약·계획재 사양 목록
  python3 tools/plan_specs.py --add 새파일.xlsx --version 2026H2   새 TF 구매 Guide 엑셀('사양수_상세' 시트)로 새 판 만들고 active 로
코드에서: from plan_specs import is_plan; is_plan(두께, 폭, 상도색코드) → True(계획재)/False(주문재)"""
import argparse, datetime as dt, json, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # cglplan/ 의 상위 = 저장소 gadong-plan
DIR = os.path.join(ROOT, 'data', 'plan_specs')
PLAN_BUY = ('수입 FH', '서림 GI')
_C = {}


def load(version=None):
    v = version or json.load(open(os.path.join(DIR, 'current.json'), encoding='utf-8'))['active']
    if v not in _C:
        d = json.load(open(os.path.join(DIR, f'{v}.json'), encoding='utf-8'))
        idx = {}
        for s in d['specs']:
            if s['plan']:
                t, w, c = s['spec'].split()
                idx.setdefault((int(w), c), set()).add(float(t))
        _C[v] = (d, idx)
    return _C[v]


def is_plan(thk, wdt, color, tol=0.03, version=None):
    ts = load(version)[1].get((int(float(wdt or 0)), str(color or '').strip()))
    return bool(ts) and any(abs(float(thk or 0) - t) <= tol + 1e-9 for t in ts)


def from_xlsx(path, version):
    import openpyxl
    ws = openpyxl.load_workbook(path, read_only=True, data_only=True)['사양수_상세']
    specs = []
    for r in ws.iter_rows(values_only=True):
        if len(r) > 11 and r[3] in ('수입 FH', '서림 GI', '미표기') and r[11]:
            specs.append({'spec': str(r[11]).strip(), 'plan': r[3] in PLAN_BUY, 'buy': r[3], 'mat': r[1], 'alloy': r[2], 'prod': r[7], 'op': r[8], 'use': r[9] or ''})
    d = {'version': version, 'src': os.path.basename(path), 'decided': dt.date.today().isoformat(), 'rule': f"계획재 = 구매구분 {'·'.join(PLAN_BUY)} 사양만, 나머지 주문재",
         'count': {'plan': sum(s['plan'] for s in specs), 'all': len(specs)}, 'specs': specs}
    json.dump(d, open(os.path.join(DIR, f'{version}.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    cur = json.load(open(os.path.join(DIR, 'current.json'), encoding='utf-8'))
    cur['active'] = version
    cur['history'].append({'version': version, 'from': d['decided'], 'note': f"{d['count']['plan']} 사양"})
    json.dump(cur, open(os.path.join(DIR, 'current.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    return d




def spec_is_plan(spec):
    """'두께 폭 색상' 문자열 → 계획재 여부"""
    try:
        t, w, c = str(spec).split()[:3]
        return is_plan(t, w, c)
    except ValueError:
        return False
