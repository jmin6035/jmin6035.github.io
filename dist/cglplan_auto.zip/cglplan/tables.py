"""추가 자료(extradata) 표 정리 — 같은 코일·같은 날이 두 번 들어가지 않게.

자동 실행기는 매일 기간을 겹쳐 다시 조회해 mes/extra/*.json 을 누적한다(auto.push_extra).
예전에는 '행 전체가 같을 때만' 중복으로 봐서, 그 사이 MES 값이 바뀐 코일(등급 판정·스크랩·휴지 시간·계약 재배정 등)은
옛 행과 새 행이 둘 다 남았다. 2026-10-16 자료에서 컬러 생산 10월 330코일·1,004t, 출하 5코일이 이렇게 두 번 들어가
컬러 10월 누계가 판매생산속보보다 8% 많았다(중복 제거 후 차이 38t, 0.3%).
→ 표마다 행을 구분하는 열(키)을 정해, 키가 같으면 새 자료 한 행만 남긴다. 키를 모르는 표는 예전처럼 행 전체로 비교."""

import json

# 표 이름 → 행을 구분하는 열. 값이 바뀌어도 같은 대상이면 같은 키
KEYS = {
    'color_prod': ('PDT_NO',),                          # 컬러 제품번호(코일 1개)
    'color_brk': ('LINE_CLS', 'PAU_STA_TM'),           # 라인·휴지 시작 시각
    'ship': ('PDT_NO', 'OUT_RSN_CD'),                   # 제품·출고 사유(11/10: 출고일을 키에 넣어 MES 가 출고일만 고친 코일이 옛 행과 두 번 남았음 — 11/10 자료 139코일, 컬러 89코일 593t. 새 자료 행만 남김)
    'stock_trend': ('WRK_DT', 'KIND'),
    'stock_rpt7': ('WRK_DT', 'CLS', 'CLS_1'),
    'stock_rpt8': ('WRK_DT', 'CLS'),
    'stock_rpt9': ('WRK_DT', 'CLS'),
}


def _key_fn(name, columns):
    ks = KEYS.get(name)
    if ks and all(k in columns for k in ks):
        idx = [columns.index(k) for k in ks]
        return lambda r: tuple(r[i] for i in idx)
    return lambda r: json.dumps(r, ensure_ascii=False)


def dedup(name, table):
    """앞쪽 행(새 자료)을 남기고 같은 키 행 제거. 반환: (새 표, 지운 행 수)"""
    cols, rows = table.get('columns') or [], table.get('rows') or []
    key, seen, out = _key_fn(name, cols), set(), []
    for r in rows:
        k = key(r)
        if k not in seen:
            seen.add(k)
            out.append(r)
    return {**table, 'rows': out}, len(rows) - len(out)


def merge(name, new, old):
    """누적: 새 자료 우선. 열 구성이 다르면 새 자료로 교체"""
    if not old or old.get('columns') != new.get('columns'):
        return dedup(name, new)[0]
    return dedup(name, {'columns': new['columns'], 'rows': new['rows'] + old['rows']})[0]


def merge_months(new, old, keep=6):
    """재고현황(snap_stock, 첫 열 _기준월): 새로 받은 달은 새 자료로 교체, 안 받은 달은 누적본에서 — 최근 keep개월만.
    사내 PC가 마감된 달은 다시 받지 않고 이번 달·지난달만 받음(2026-10-28). 열 구성이 다르면 새 자료로 교체"""
    if not old or old.get('columns') != new.get('columns') or not new.get('rows'):
        return new
    got = {r[0] for r in new['rows']}
    ms = sorted(got | {r[0] for r in old['rows']}, reverse=True)[:keep]
    return {**new, 'rows': new['rows'] + [r for r in old['rows'] if r[0] not in got and r[0] in ms]}


CCL_OF = {'X': '1CCL', 'Y': '2CCL', 'Z': '3CCL', 'W': '4CCL'}


def fill_color_prod(tables):
    """컬러 생산(color_prod)이 끊긴 날을 같은 MES 원천 표(SOPS.PF_CC_CCL_RSLT)의 원격 조회로 채움(11/3: 10/30~ 사내 PC 의 color_prod 조회가
    빈 결과 — 휴지·출하는 정상). 1순위 snap_cc_prod_recent(color_prod 와 같은 열), 2순위 snap_cc_seq_recent(열 이름 바꿔 맞춤:
    라인 X·Y·Z·W → 1~4CCL, 부서 = 계약 → 주문 표·기존 코일, 휴지 시간 = color_brk 코일별 합). 반환: 채운 행 수"""
    cp = tables.get('color_prod')
    if not cp or not cp.get('rows'):
        return 0
    C = cp['columns']
    have = {r[C.index('PDT_NO')] for r in cp['rows']}
    last = max(str(r[C.index('PRD_DT')]) for r in cp['rows'])
    add = []
    src = tables.get('snap_cc_prod_recent')
    if src and src.get('rows') and set(C) <= set(src['columns']):
        idx = [src['columns'].index(c) for c in C]
        add = [[r[i] for i in idx] for r in src['rows'] if r[src['columns'].index('PDT_NO')] not in have]
    else:
        sq = tables.get('snap_cc_seq_recent')
        if not sq or not sq.get('rows'):
            return 0
        dept = {}
        for name in ('snap_cc_ord_full', 'hist_cc_con_dept_a', 'hist_cc_con_dept_b'):
            t = tables.get(name)
            if t and 'DEPART_NM' in t['columns']:
                for r in t['rows']:
                    x = dict(zip(t['columns'], r))
                    dept.setdefault(x['CON_NO'], x['DEPART_NM'])
        for r in cp['rows']:
            dept.setdefault(r[C.index('CON_NO')], r[C.index('DEPT')])
        pau = {}
        b = tables.get('color_brk')
        if b and 'PDT_MOM_NO' in b['columns']:
            bi, ti = b['columns'].index('PDT_MOM_NO'), b['columns'].index('PAU_TIME')
            for r in b['rows']:
                pau[r[bi]] = pau.get(r[bi], 0) + float(r[ti] or 0)
        S = sq['columns']
        dmax = max(str(r[S.index('PRD_DT')]) for r in sq['rows'])     # 조회 시각의 마지막 날은 아직 진행 중 → 뺌
        for r in sq['rows']:
            x = dict(zip(S, r))
            d = str(x['PRD_DT'])
            d = f'{d[:4]}-{d[4:6]}-{d[6:8]}' if len(d) == 8 and '-' not in d else d
            if x['PDT_NO'] in have or d <= last or str(x['PRD_DT']) == dmax:
                continue
            y = {'PRD_DT': d, 'LINE': CCL_OF.get(str(x['LINE_CLS']), x['LINE_CLS']), 'DEPT': dept.get(x['CON_NO']), 'PAU_TIME': pau.get(x['PDT_NO'], 0)}
            add.append([y[c] if c in y else x.get(c) for c in C])
    if add:
        cp['rows'] += add
    return len(add)


def clean(tables):
    """extradata['tables'] 를 제자리 정리. 반환: {표: 지운 행 수} (지운 것만)"""
    fill_color_prod(tables)
    gone = {}
    for name in KEYS:
        t = tables.get(name)
        if t and t.get('rows'):
            tables[name], n = dedup(name, t)
            if n:
                gone[name] = n
    return gone


def data_now(ex):
    """자료 시각(한국 시각, 분 단위) = 사내 PC 가 extradata 를 저장한 시각(savedAt, UTC). 없거나 미래면 지금.
    (10/28 점검: 순서·날짜 계산을 '스크립트 돌린 시각'에서 시작하면 늦게 다시 돌릴 때 하루 몫이 통째로 밀림)"""
    import datetime as _dt
    now = (_dt.datetime.utcnow() + _dt.timedelta(hours=9)).replace(second=0, microsecond=0)
    try:
        t = _dt.datetime.fromisoformat(str(ex.get('savedAt')))
        t = (t.astimezone(_dt.timezone.utc).replace(tzinfo=None) if t.tzinfo else t) + _dt.timedelta(hours=9)
        return min(now, t.replace(second=0, microsecond=0))
    except (TypeError, ValueError):
        return now


def load_extra(path):
    """extradata.json 을 읽어 정리까지 한 번에"""
    ex = json.load(open(path, encoding='utf-8'))
    if isinstance(ex, dict) and isinstance(ex.get('tables'), dict):
        merge_parts(ex)
        clean(ex['tables'])
    return ex


def merge_parts(ex):
    """나눠 받은 표 합치기(11/10 총점검 — MES 조회 화면은 한 번에 1만 행까지라 큰 표가 조용히 잘렸음):
    이름이 '<표>__p2', '<표>__p3' … 인 표를 '<표>' 뒤에 붙이고(같은 행 중복 제외) ex['parts'][표] = [쪽별 행 수] 로 남김.
    마지막 쪽이 1만 행이면 아직 더 있다는 뜻 — tools/cross_check.py D1 이 잡음"""
    T = ex['tables']
    parts = {}
    for n in sorted(k for k in T if '__p' in k):
        base = n.split('__p')[0]
        b, p = T.get(base), T[n]
        if not b or (b.get('columns') or []) != (p.get('columns') or []):
            continue
        ns = parts.setdefault(base, [len(b.get('rows') or [])])
        ns.append(len(p.get('rows') or []))
        seen = {json.dumps(r, ensure_ascii=False, default=str) for r in b['rows']}
        b['rows'] = b['rows'] + [r for r in p.get('rows') or [] if json.dumps(r, ensure_ascii=False, default=str) not in seen]
    for n in [k for k in T if '__p' in k and k.split('__p')[0] in parts]:
        del T[n]
    ex['parts'] = parts
