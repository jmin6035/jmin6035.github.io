"""판매생산속보(snap_salesrpt) 표 해석 — mes_download 가 화면의 <table> 을 행 단위 문자열로 저장한 것을 숫자 표로 바꿈.

칸 표기: 'AL{c2}' = colspan 2, '도금{r15}' = rowspan 15, 칸 구분 ' | '.
rowspan 이 걸린 앞쪽 글자 칸은 '묶음'(예: F/H도금용, 컬러용), 그 뒤 글자 칸은 '항목'으로 본다.
"""
import re

CELL = re.compile(r'^(.*?)((?:\{[cr]\d+\})*)$')
NUM = re.compile(r'^\(?-?[\d,]+(?:\.\d+)?\)?$')


def _cell(s):
    m = CELL.match(s.strip())
    txt, marks = m.group(1).strip(), m.group(2)
    rs = re.search(r'\{r(\d+)\}', marks)
    return txt, int(rs.group(1)) if rs else 1


def _num(t):
    if not NUM.match(t):                           # '-', 빈칸, 글자
        return None
    return float(t.strip('()').replace(',', ''))


def parse(tbl):
    """snap_salesrpt {'columns':[표,제목,행,칸], 'rows':[...]} → {제목: {'asOf', 'rows': [(묶음, 항목, [숫자...])]}}"""
    out, by = {}, {}
    for t, _cap, r, cells in tbl['rows']:
        by.setdefault(t, []).append((r, cells))
    for t, rows in by.items():
        rows.sort()
        title = _cell(rows[0][1].split(' | ')[0])[0]
        m = re.search(r'\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2})\]', title)
        name = re.sub(r'\s*\[.*$', '', title).strip()
        groups, data = [], []                      # groups: [이름, 남은 행 수]
        for _r, cells in rows[1:]:
            cs = [_cell(c) for c in cells.split(' | ')]
            k = next((i for i, (x, _) in enumerate(cs) if NUM.match(x) or (x == '-' and i > 0)), None)
            if k is None:                          # 머리글 행
                continue
            labels = cs[:k]
            groups = [g for g in groups if g[1] > 0]
            item = []
            for x, rs in labels:
                if rs > 1:
                    groups.append([x, rs])
                else:
                    item.append(x)
            data.append((' '.join(g[0] for g in groups if g[0]), ' '.join(i for i in item if i),
                         [_num(x) for x, _ in cs[k:]]))
            for g in groups:
                g[1] -= 1
        out[name] = {'asOf': m.group(1) if m else None, 'rows': data}
    return out


def find(P, title_prefix, item, group=None, nth=0):
    """표 제목 앞부분·항목 이름(·묶음 일부)으로 숫자 목록 찾기"""
    for name, t in P.items():
        if name.startswith(title_prefix):
            hits = [v for g, i, v in t['rows'] if i == item and (group is None or group in g)]
            if len(hits) > nth:
                return hits[nth]
    return None


# 재고 목표(2026-10-12 사용자 결정): 월말 기준(최대) 재고량 = '27년 판생그룹 목표. 일별·그룹별은 TF 목표 일수(tools/master_plan.TF_DAYS).
# 판매생산속보 표의 '목표' 칸(컬러 제품 12,000 등)은 참고로만 targetRpt 에 남김. 도금 제품 22,300t 은 판매재 기준(10/21 사용자 확인)
from .tfrules import STOCK_MAX  # noqa: E402  값 = cglplan/tf_rules.json(포털 '재고 목표 기준'에서 고침, 2026-10-22)


def mat_groups(P):
    """11/12 사용자 '소재 발주한 사람 추적하면 그룹 나온다': 속보 5.소재 표의 발주 부서(판매그룹) 줄 → 그룹별 소재 재고(계 칸).
    도금 F/H: 도금판매·도금수출·자동차강판 + 컬러 부서 발주(자가재 묶음 포함) = 도금 자가재 · DUMMY/포장재는 그룹 없음.
    컬러용: 컬러수출·컬러건재·수요개발(컬러 자가재 줄은 소계 밖이라 뺌). 키 = 엔진 그룹 키"""
    t = next((t for n, t in P.items() if n.startswith('5.소재')), None)
    MAP = {'G': {'도금판매': 'G국내', '도금수출': 'G수출', '자동차강판': 'G자동차', '컬러수출': 'G자가재', '컬러건재': 'G자가재', '수요개발': 'G자가재'},
           'C': {'컬러수출': 'C수출', '컬러건재': 'C건재', '수요개발': 'C수요'}}
    out = {'도금 소재(F/H)': {}, '컬러 소재': {}}
    for g, i, v in (t or {}).get('rows', []):
        pl = 'G' if g.startswith('F/H') else 'C' if g == '컬러용' else None
        k = MAP.get(pl, {}).get(i)
        if k and v and v[-4] is not None:
            o = out['도금 소재(F/H)' if pl == 'G' else '컬러 소재']
            o[k] = o.get(k, 0) + v[-4]
    return {k: v for k, v in out.items() if v}


def summary(tbl):
    """보고서용 요약: 재고(목표·현재·증감), 이번 달 생산·출하(월차계획·일정누계·누계 실적), 장기재고"""
    P = parse(tbl)
    as_of = next((t['asOf'] for t in P.values() if t['asOf']), None)
    S = {'asOf': as_of, 'stock': [], 'prod': [], 'ship': [], 'longTerm': None}

    def stk(name, title, item, group=None, cur_idx=-2, nth=0, sub=None):
        v = find(P, title, item, group, nth)
        if not v:
            return
        S['stock'].append({'name': name, 'target': v[0], 'current': v[cur_idx], 'diff': v[-1], 'sub': sub or []})

    def sub(title, items, group=None, cur_idx=-2):
        r = []
        for it in items:
            v = find(P, title, it, group)
            if v:
                r.append({'name': it, 'target': v[0], 'current': v[cur_idx], 'diff': v[-1]})
        return r
    # 5.소재: 목표, 사내, A·B, 부두, 삼일3물류, 삼일, 외주가공, 기타, 계, 수입소재, 이송중, 증감 → 현재 = 뒤에서 4번째
    stk('도금 소재(F/H)', '5.소재', '소계', 'F/H', -4, sub=sub('5.소재', ['AL', 'AZ', 'GM'], 'F/H', -4))
    # 6-1.도금제품: 목표 … 합계, 증감 → 현재 = 뒤에서 2번째. 자가재는 목표가 없어 따로
    tot, own = find(P, '6-1.도금제품', '합계'), find(P, '6-1.도금제품', '자가')
    if tot and own:
        S['stock'].append({'name': '도금 제품(판매재)', 'target': tot[0], 'current': tot[-2] - own[-2], 'diff': tot[-2] - own[-2] - tot[0],
                           'sub': sub('6-1.도금제품', ['AL', 'AZ', 'GM'])})
        S['stock'].append({'name': '도금 제품(자가재)', 'target': None, 'current': own[-2], 'diff': None, 'sub': []})
    stk('컬러 소재', '5.소재', '소계', '컬러용', -4, sub=sub('5.소재', ['컬러수출', '컬러건재'], '컬러용', -4))
    stk('컬러 제품', '6-2.컬러제품', '합계', sub=sub('6-2.컬러제품', ['컬러수출', '컬러건재']))
    # 2.생산현황: 월차계획, 일정누계, 실적(일, 누계), 증감(일, 누계), T/H(일, 누계), 작업률, 가동률
    for grp, lines in (('도금', ['1CGL', '2CGL']), ('컬러', ['1CCL', '2CCL', '3CCL', '4CCL'])):
        for ln in lines + ['소계']:
            v = find(P, '2.생산현황', ln, grp)
            if v:
                S['prod'].append({'plant': grp, 'line': grp + ' 계' if ln == '소계' else ln, 'month': v[0], 'sched': v[1], 'actual': v[3], 'tph': v[7]})
    # 3.출하현황: 월차계획, 일정누계, 실적(일, 누계, 계획비) …
    for grp in ['도금판매', '도금수출', '자동차강판', '컬러수출', '컬러건재']:
        v = find(P, '3.출하현황', '소계', grp)
        if v:
            e = find(P, '3.출하현황', '수출', grp)            # 11/10: 수출 행 월차계획 — 진도 기준선(수출분 = 배 출항 예정, pages.ship_due)
            S['ship'].append({'name': grp, 'month': v[0], 'sched': v[1], 'actual': v[3], 'exp': (e[0] or 0) if e else 0})
    v = find(P, '3.출하현황', '', '합계')
    if v:
        g5 = [x for x in S['ship'] if x['name'] != '합계']       # 11/10 총점검: 합계 줄 = 보이는 5개 그룹 합(속보 원본 합계엔 수요개발·RM 등이 더 들어 있어 행 합과 780t 달랐음). 원본 값은 rpt* 로 남김
        S['ship'].append({'name': '합계', 'month': sum(x['month'] or 0 for x in g5), 'sched': sum(x['sched'] or 0 for x in g5), 'actual': sum(x['actual'] or 0 for x in g5),
                          'rptMonth': v[0], 'rptSched': v[1], 'rptActual': v[3]})
    for x in S['stock']:
        x['targetRpt'] = x['target']
        if x['name'] in STOCK_MAX:
            x['target'] = STOCK_MAX[x['name']]
            x['diff'] = x['current'] - x['target'] if x['current'] is not None else None
            for s in x['sub']:                     # 속보의 세부 목표는 옛 기준이라 합이 월말 최대와 안 맞음 → 목표·차이 비움(재고만 표시)
                s['targetRpt'], s['target'], s['diff'] = s['target'], None, None
    MG = mat_groups(P)
    for x in S['stock']:
        g = MG.get(x['name'])
        if g and x['current'] is not None:
            x['grp'] = {k: round(v, 1) for k, v in g.items()}
            x['grpNa'] = round(x['current'] - sum(g.values()), 1)     # 그룹 없는 줄(도금 DUMMY/포장재 등) — 공장 줄에만
    v = find(P, '7.장기재고', '총계')
    if v:                                          # 소재(3·6·12개월↑, 계, 전일비, 전월비), 제품(같음), 합계
        S['longTerm'] = {'material': v[3], 'product': v[9], 'total': v[-1], 'momProduct': v[11], 'momMaterial': v[5]}
        for grp in ('도금', '컬러'):
            g = find(P, '7.장기재고', '소계', grp)
            if g:
                S['longTerm'][grp] = g[-1]
    return S


if __name__ == '__main__':
    import json, sys
    ex = json.load(open(sys.argv[1], encoding='utf-8'))
    print(json.dumps(summary(ex['tables']['snap_salesrpt']), ensure_ascii=False, indent=1))
