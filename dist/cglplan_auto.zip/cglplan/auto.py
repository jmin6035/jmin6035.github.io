"""사내 PC 자동 실행기: MES 엑셀 → 누적 → 실적 분석 → 재계획(최적 증명까지) → 암호화 → Supabase 게시 + 누적 실적 업로드.
실행: python -m cglplan auto --config auto_config.json [--dry] [--force]
  --dry   : 업로드하지 않고 out_dir 에만 저장(시험용)
  --force : 새 실적이 없어도 재계획
설정 예시는 auto_config.example.json. 키·암호가 들어가므로 설정 파일은 저장소에 올리지 않는다."""
import datetime as _dt
import glob
import json
import os
import ssl
import time
import traceback
import urllib.request

from . import mes, publish as PB, replan as RP, store as ST, tables as TB, util as U
from .supa import Supa, make_ctx

AUTO_VERSION = '2026-11-03 v80'                     # 설치 묶음 판(실행할 때 맨 위에 표시 — 사내 PC 가 새 판으로 도는지 확인용)
SITES = ('https://jmin6035.github.io/',)   # 사이트 주소(10/30 주소 전환 — 예전 jmin6035.github.io/gadong-plan-web 은 폐기, 새 주소로 넘기는 안내만)
GITHUB_PUBLISHED = 'published/latest.plan.enc.json'
GITHUB_CHANGES = 'published/plan_changes.enc.json'   # 회사 변경 등록(M/C 날짜 지정) — tools/plan_changes.py
DEFAULTS = {'window_days': 91, 'published_bucket': 'published', 'published_path': 'latest.plan.enc.json', 'analysis_path': '', 'analysis_password': '', 'data_bucket': 'mes',
            'replan': {'freeze': 2, 'tradeoff': 100, 'stab': 10}, 'push_data': True, 'label': ''}


def load_config(path):
    try:
        cfg = json.loads(open(path, encoding='utf-8-sig').read(), strict=False)   # 메모장 BOM·붙여넣기 줄바꿈 허용
    except json.JSONDecodeError as e:
        raise SystemExit(f'설정 파일 {path} 형식 오류({e.lineno}번째 줄 {e.colno}번째 글자): 따옴표·쉼표·중괄호를 확인하세요')
    if isinstance(cfg.get('supabase'), dict):
        cfg['supabase']['key'] = ''.join(str(cfg['supabase'].get('key', '')).split())      # 키에 섞인 줄바꿈·공백 제거
        cfg['supabase']['url'] = str(cfg['supabase'].get('url', '')).strip()
    out = dict(DEFAULTS)
    out.update(cfg)
    out['replan'] = dict(DEFAULTS['replan'], **(cfg.get('replan') or {}))
    for k in ('mes_inputs', 'store', 'out_dir', 'password'):
        if not out.get(k):
            raise SystemExit(f'설정 파일에 {k} 가 없습니다')
    # 상대 경로(cgl_store.sqlite·mes/*.xlsx·out)는 설정 파일 폴더 기준 — 다른 폴더에서 실행해도 같은 누적 실적을 씀
    base = os.path.dirname(os.path.abspath(path))
    ab = lambda v: v if os.path.isabs(v) else os.path.join(base, v)
    out['store'], out['out_dir'] = ab(out['store']), ab(out['out_dir'])
    out['mes_inputs'] = [ab(x) for x in out['mes_inputs']]
    return out


def bootstrap_store(cfg, sb, st, log):
    """누적 실적이 비어 있고 새 MES 파일도 없을 때: 지난 자동 실행이 게시한 원자료(mesdata.enc.json, 분석 암호)에서 코일·휴지를 받아 채움.
    재계획에 필요한 계획 기간(10/1~) 실적은 들어 있음. 반환: 채운 코일 수(못 하면 0)"""
    try:
        b = sb.download(cfg['published_bucket'], 'mesdata.enc.json', public=True) if sb else None
        if not b:
            return 0
        e = json.loads(b)
        d = None
        for pw in (cfg.get('analysis_password'), cfg['password']):
            if pw:
                try:
                    d = PB.decrypt(e, pw)
                    break
                except Exception:
                    continue
        if not d:
            return 0
        cs = [dict(zip(d['coilCols'], c)) for c in d['coils']]
        st.upsert(cs)
        if d.get('stops'):
            st.upsert_stops([dict(zip(d['stopCols'], x)) for x in d['stops']])
        log(f"  [warn] 누적 실적이 비어 있어 게시된 원자료에서 채움: 코일 {len(cs)}개 ({d.get('from')}~{d.get('to')}) — 다음부터는 이 폴더의 {os.path.basename(cfg['store'])}에 쌓임")
        return len(cs)
    except Exception as ex:
        log(f'  [warn] 게시된 원자료로 채우기 실패: {ex}')
        return 0


def _get(url, ssl_verify=True, timeout=60):
    """url 이 상대 경로(published/…)면 사이트 주소(SITES)를 차례로 시도"""
    ctx = make_ctx(ssl_verify)
    for u in ([url] if url.startswith('http') else [b + url for b in SITES]):
        try:
            with urllib.request.urlopen(urllib.request.Request(u + f'?v={int(time.time())}', headers={'Cache-Control': 'no-cache'}), timeout=timeout, context=ctx) as r:
                return json.loads(r.read())
        except Exception:
            continue
    return None


def _stamp(e):
    return (e or {}).get('created') or (e or {}).get('savedAt') or ''


def load_changes(cfg, t0, log):
    """회사 변경 등록: 사이트 published/plan_changes.enc.json(계획 암호) → (실적 다음 날 이후 M/C 지정 [{line, date, fam}], 자가재 반순 납기 selfReq 또는 None).
    없거나 못 읽으면 ([], None)"""
    e = _get(GITHUB_CHANGES, (cfg.get('supabase') or {}).get('ssl_verify', True))
    if not e:
        return [], None
    try:
        d = PB.decrypt(e, cfg['password']) if e.get('app') == 'cgl-plan-enc' else e
    except Exception as ex:
        log(f'  [warn] 변경 등록 파일 복호화 실패(무시): {ex}')
        return [], None
    fx = [x for x in d.get('mc', []) if x.get('date', '') > t0]
    if fx:
        log('변경 등록(M/C 날짜 지정): ' + ', '.join(f"{x['line']} {x['date'][5:]} {x['fam']}" + (f" ({x['note']})" if x.get('note') else '') for x in fx))
    if d.get('selfReq'):
        log('자가재 납기: 컬러 필요일 기준 반순(컬러 생산 − 8일) — ' + ', '.join(f"{a} {v[-1][1]:,.0f}t" for a, v in d['selfReq'].items()))
    return [{'line': x['line'], 'date': x['date'], 'fam': x['fam']} for x in fx], d.get('selfReq')


PAGES_BASE_URL = 'published/pages_base.enc.json'


def sync_pages_base(cfg, log):
    """화면 기준 파일 받기(2026-10-22): 계획이 바뀌면(계획 규칙 적용 등) 사이트가 새 기준 파일을 게시 → 설치 묶음보다 새것이면 cglplan/pages_base/ 를 바꿈.
    설치 묶음을 다시 깔지 않아도 홈 요약·재고 추이가 새 계획을 따라감. 실패해도 계획에는 영향 없음(묶음 안 파일 그대로)"""
    from . import pages as PG
    env = _get(PAGES_BASE_URL, (cfg.get('supabase') or {}).get('ssl_verify', True))
    if not env:
        return
    o = None
    for pw in dict.fromkeys(x for x in (cfg.get('analysis_password'), cfg.get('password')) if x):
        try:
            o = PB.decrypt(env, pw)
            break
        except Exception:
            pass
    if not o or not o.get('files'):
        return
    bp = os.path.join(PG.BASE, '_built.json')
    cur = json.load(open(bp, encoding='utf-8')).get('built', '') if os.path.exists(bp) else ''
    if o['built'] <= cur:
        return
    os.makedirs(PG.BASE, exist_ok=True)
    for f, v in o['files'].items():
        if f.endswith('.json') and '/' not in f and '\\' not in f and not f.startswith('_'):
            json.dump(v, open(os.path.join(PG.BASE, f), 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
    json.dump({'built': o['built']}, open(bp, 'w', encoding='utf-8'))
    log(f"화면 기준 파일 갱신(사이트 {o['built'][:16]}, {len(o['files'])}개)")


def load_base(cfg, sb, log):
    """기준 계획: 설정의 base_result(로컬 json) 또는 게시본 중 최신(Supabase·GitHub) → 복호화"""
    if cfg.get('base_result'):
        o = json.load(open(cfg['base_result'], encoding='utf-8'))
        log(f"기준 계획: 로컬 파일 {cfg['base_result']}")
    else:
        cands = []
        if sb:
            b = sb.download(cfg['published_bucket'], cfg['published_path'], public=True)
            if b:
                cands.append(('Supabase', json.loads(b)))
        g = _get(GITHUB_PUBLISHED, (cfg.get('supabase') or {}).get('ssl_verify', True))
        if g:
            cands.append(('GitHub', g))
        if not cands:
            return None, None
        src, o = max(cands, key=lambda x: _stamp(x[1]))
        log(f"기준 계획: {src} 게시본 ({_stamp(o)})")
    if o.get('app') == 'cgl-plan-enc':
        o = PB.decrypt(o, cfg['password'])
    return (o['result'], o.get('meta') or {}) if o.get('app') == 'cgl-plan' else (o, {})


def check_config(cfg):
    """예시 값 그대로 남은 설정 찾기(예: Supabase 키 자리에 안내문) — 실행 중간에 알기 어려운 오류로 멈추지 않게 먼저 알림"""
    bad = []
    key = str((cfg.get('supabase') or {}).get('key') or '')
    if key and (not key.isascii() or '...' in key or ' ' in key):
        bad.append('supabase.key 가 예시 안내문 그대로입니다 — 예전 설치 폴더의 auto_config.json 을 쓰거나 Supabase 비밀 키(sb_secret_로 시작)를 넣으세요')
    for k in ('password', 'analysis_password'):
        v = str(cfg.get(k) or '')
        if '암호' in v or '비우면' in v:
            bad.append(f'{k} 가 예시 안내문 그대로입니다 — 실제 암호를 넣으세요' + (' (분석 암호는 비워도 됨)' if k == 'analysis_password' else ''))
    m = cfg.get('mes') or {}
    if str(m.get('id', '')).startswith('MES ') or '비밀번호' in str(m.get('pw', '')):
        bad.append('mes.id / mes.pw 가 예시 안내문 그대로입니다')
    return bad


def run(cfg, dry=False, force=False):
    os.makedirs(cfg['out_dir'], exist_ok=True)
    t0 = time.time()
    logf = open(os.path.join(cfg['out_dir'], 'auto_log.txt'), 'a', encoding='utf-8')
    now = _dt.datetime.now()

    def log(m):
        line = f'[{now:%Y-%m-%d %H:%M}] {time.time() - t0:5.0f}s {m}'
        print(line, flush=True)
        logf.write(line + '\n')
        logf.flush()

    log(f'자동 실행기 {AUTO_VERSION}')
    bad = check_config(cfg)
    if bad:
        for b in bad:
            log('설정 오류: ' + b)
        raise SystemExit('auto_config.json 을 고친 뒤 다시 실행하세요: ' + ' / '.join(bad))
    st = ST.Store(cfg['store'])
    sbc = cfg.get('supabase') or {}
    sb = Supa(sbc['url'], sbc['key'], sbc.get('ssl_verify', True)) if sbc.get('url') and sbc.get('key') else None
    if not sb and not dry:
        raise SystemExit('설정에 supabase.url/key 가 없습니다(시험은 --dry)')
    try:
        # 1) MES 엑셀 → 정제 → 누적
        pats = list(cfg['mes_inputs']) + [pat[:-5] + ext for pat in cfg['mes_inputs'] if pat.lower().endswith('.xlsx') for ext in ('.json', '.csv')]
        paths = sorted({p for pat in pats for p in glob.glob(pat) if not os.path.basename(p).startswith('~$')})   # ~$ = 엑셀이 열어둔 임시파일
        empty = not st.last_day()                              # 누적 실적이 비었으면 MES 파일이 있어도 게시된 원자료(91일)로 먼저 채움 — 10/30 재설치 때 파일만 읽어 10/1 이전 실적이 빠졌던 일
        if empty and sb:
            bootstrap_store(cfg, sb, st, log)
        if not paths and empty and not st.last_day():
            raise RuntimeError(f"MES 엑셀이 없고 누적 실적도 비어 있습니다 — MES 파일 위치 {cfg['mes_inputs']}, 누적 실적 {cfg['store']}(실행 폴더 {os.getcwd()}). "
                               "새 폴더에 설치했다면 예전 설치 폴더의 cgl_store.sqlite 와 mes 폴더를 같이 옮기거나, py mes_download.py 로 MES 를 먼저 받으세요")
        sheets, okp = [], []
        for p in paths:
            try:
                sheets += mes.sheets_from_workbooks([p])
                okp.append(p)
            except Exception as e:
                log(f"  [warn] 읽지 못한 파일(건너뜀): {os.path.basename(p)} — {e}. 엑셀로 열어 '다른 이름으로 저장 → Excel 통합 문서(*.xlsx)'로 다시 저장하거나, 문서보안(DRM) 해제 후 넣으세요")
        if not okp and not st.last_day() and not bootstrap_store(cfg, sb, st, log):
            raise RuntimeError('읽을 수 있는 MES 엑셀이 없습니다')
        paths = okp
        if okp:
            cl = mes.clean(mes.tables(sheets))
        else:                                                  # 새 MES 파일이 없어도(내려받는 중·이미 정리됨) 누적 실적으로 계속 — 수동 --force 재실행용
            cl = {'coils': [], 'stops': [], 'checks': [{'level': 'warn', 'msg': f"새 MES 파일 없음({cfg['mes_inputs']}) — 누적 실적(~{st.last_day()})으로 계속"}]}
        for c in cl['checks']:
            log(f"  [{c['level']}] {c['msg']}")
        if any(c['level'] == 'error' for c in cl['checks']):
            raise RuntimeError('MES 엑셀 해석 오류')
        new, chg = st.upsert(cl['coils'])
        nst = st.upsert_stops(cl['stops'])
        last = st.last_day()
        log(f"MES {len(paths)}개 파일, 코일 {len(cl['coils'])}개 → 누적 신규 {new} · 변경 {chg}, 휴지 {len(cl['stops'])}건(신규 {nst}) (누적 마지막 날 {last})")

        # 2) 기준 계획
        R, meta = load_base(cfg, sb, log)
        P = R['P'] if R else U.default_params()

        # 3) 실적 분석(최근 window_days)
        d_from = U.add_days(last, -cfg['window_days'])
        win = st.coils(d_from)
        an = mes.analyze(win, P, stops=st.stops(mes.to_min(d_from)))
        summ = mes.summary(an, cl)
        for c in an['cands']:
            if c['apply']:
                log(f"  반영 권장: {c['label']} {c['cur']} → {c['act']:.4g} ({c['basis']})")

        # 4) 재계획
        auto = {'runAt': _dt.datetime.now(_dt.timezone.utc).isoformat(), 'newCoils': new, 'changedCoils': chg, 'replanned': False, 'notes': []}
        R2 = R
        if R is None:
            auto['notes'].append('게시된 기준 계획이 없어 재계획 생략(분석만)')
            log(auto['notes'][-1])
        else:
            H = U.horizon(P)
            coils_h = st.coils(H['D0'])
            act = mes.to_actual(mes.analyze(coils_h, P, stops=st.stops(mes.to_min(H['D0']))), coils_h, R) if coils_h else {'checks': [{'level': 'error', 'msg': f"아직 계획 기간({H['D0']}~) 실적 없음 — 분석만"}], 'quiet': True}
            for c in act.get('checks', []):
                if not act.get('quiet'):
                    log(f"  [{c['level']}] {c['msg']}")
            if any(c['level'] == 'error' for c in act.get('checks', [])):
                auto['notes'].append('재계획 생략: ' + '; '.join(c['msg'] for c in act['checks'] if c['level'] == 'error'))
                log(auto['notes'][-1])
            elif not force and (R.get('replan') or {}).get('t0') == act['t0'] and not (new or chg):
                auto['notes'].append(f"새 실적 없음(기준일 {act['t0']} 그대로) — 재계획 생략")
                auto['actualTo'] = act['t0']
                log(auto['notes'][-1])
            else:
                o = cfg['replan']
                ro = {'freezeDays': o['freeze'], 'lateW': 1 / o['tradeoff'], 'stabW': 1 / o['stab'], 'stabW2': 5000 / o['stab']}
                fx, sreq = load_changes(cfg, act['t0'], log)
                if fx:
                    ro['fixMC'] = fx
                if sreq:
                    ro['selfReq'] = sreq
                R2 = RP.replan(R, act, ro, log)
                if sreq:                                         # 자가재 반순 납기는 직판재 생산·출하에 영향이 없을 때만(2026-10-13 사용자 조건) — 직판재 지연이 생기면 빼고 다시 계산
                    dl = sum(r[4] for r in R2['rows'] if r[0] > act['t0'] and r[3] != '자가재' and r[0] > r[5])
                    if dl > 0.5 or R2['replan'].get('shortBy'):
                        log(f'  자가재 반순 납기로 직판재 지연 {dl:,.0f}t·결품 {len(R2["replan"].get("shortBy") or [])}건 → 반순 납기 없이 다시 계산')
                        ro.pop('selfReq')
                        R2 = RP.replan(R, act, ro, log)
                        auto['notes'].append('자가재 반순 납기 적용 안 함(직판재 지연 발생)')
                auto.update(replanned=True, actualTo=act['t0'], optimal=R2['replan'].get('optimal'))
                auto['warns'] = [c['msg'] for c in act.get('checks', []) if c['level'] == 'warn']

        # 5) 게시
        out = {'mes': summ, 'auto': auto}
        if R2 is not None:
            meta = dict(meta or {}, **out)
            env = PB.pack(R2, meta)
            json.dump(env, open(os.path.join(cfg['out_dir'], 'latest_result.json'), 'w', encoding='utf-8'), ensure_ascii=False)
            P2 = R2['P']
            label = cfg['label'] or f"{P2['year']} {P2['months'][0]}~{P2['months'][-1]}월 계획" + (f" (MES 실적 ~{auto['actualTo']})" if auto.get('actualTo') else '')
            enc = json.dumps(PB.encrypt(env, cfg['password'], label))
            if dry:
                open(os.path.join(cfg['out_dir'], cfg['published_path']), 'w', encoding='utf-8').write(enc)
                log(f"[시험] 게시 파일 저장: {os.path.join(cfg['out_dir'], cfg['published_path'])}")
            else:
                sb.upload(cfg['published_bucket'], cfg['published_path'], enc)
                log(f"게시 완료: {cfg['published_bucket']}/{cfg['published_path']} ({label})")
        # 5-2) 분석 화면용 결과(별도 암호, 없으면 게시 암호) — 시험 위치(test.*)면 분석도 test.analysis.enc.json
        apath = cfg['analysis_path'] or ('test.analysis.enc.json' if cfg['published_path'].startswith('test') else 'analysis.enc.json')
        full = dict(mes.export(an, cl, win), analyzedAt=auto['runAt'], auto=auto)
        aenc = json.dumps(PB.encrypt(full, cfg['analysis_password'] or cfg['password'], f"실적 분석 {an['period']['from']}~{an['period']['to']}"))
        if dry:
            open(os.path.join(cfg['out_dir'], apath), 'w', encoding='utf-8').write(aenc)
            log(f'[시험] 분석 파일 저장: {apath}')
        else:
            sb.upload(cfg['published_bucket'], apath, aenc)
            log(f"분석 게시 완료: {cfg['published_bucket']}/{apath}")
        # 5-3) 원자료(최근 window_days 코일·휴지) 암호화 게시 — Claude 주간 분석용(분석 암호). 시험 위치면 test.mesdata.enc.json
        dpath = 'test.mesdata.enc.json' if apath.startswith('test') else 'mesdata.enc.json'
        nz = lambda v: None if isinstance(v, float) and v != v else v
        raw = {'app': 'cgl-mesdata', 'version': 1, 'savedAt': auto['runAt'], 'from': d_from, 'to': last,
               'coilCols': ST.COLS, 'coils': [[nz(c.get(k)) for k in ST.COLS] for c in win],
               'stopCols': ST.SCOLS, 'stops': [[x[k] for k in ST.SCOLS] for x in st.stops(mes.to_min(d_from))]}
        denc = json.dumps(PB.encrypt(raw, cfg['analysis_password'] or cfg['password'], f"MES 원자료 {d_from}~{last}"))
        if dry:
            open(os.path.join(cfg['out_dir'], dpath), 'w', encoding='utf-8').write(denc)
            log(f'[시험] 원자료 저장: {dpath} ({len(win)}코일)')
        else:
            sb.upload(cfg['published_bucket'], dpath, denc)
            log(f"원자료 게시: {cfg['published_bucket']}/{dpath} ({len(win)}코일, 휴지 {len(raw['stops'])}건)")
        # 5-4) 분석용 추가 자료(mes/extra/*.json: 컬러 생산·휴지, 출하, 재고) — 누적해 암호화 게시(Claude 분석용)
        xt = {}
        try:
            xn, xt = push_extra(cfg, sb, dry, auto['runAt'], 'test.' if apath.startswith('test') else '')
            log(f'분석용 추가 자료 게시: {xn}' if xn else '[warn] 분석용 추가 자료 없음: mes/extra 에 새 파일도 out/extra_acc 누적본도 없음 — 화면의 컬러·재고·출하는 비게 됨')
        except Exception as e:
            log(f'분석용 추가 자료 게시 실패(계획에는 영향 없음): {e}')
        # 5-5) 웹 화면 자료(컬러 실적·조달 판단·홈 요약·자료 상태) — cglplan/pages.py
        try:
            sync_pages_base(cfg, log)
        except Exception as e:
            log(f'화면 기준 파일 받기 실패(묶음 안 파일 그대로): {e}')
        try:
            from . import pages as PG
            PG.publish(cfg, sb, dry, xt, win, R, R2, auto, log, PB.encrypt, stops=st.stops(mes.to_min(d_from)))
        except Exception as e:
            log(f'화면 자료 게시 실패(계획에는 영향 없음): {e}')
            logf.write(traceback.format_exc() + '\n')
        # 6) 누적 실적 업로드(주간 분석용, 비공개 버킷)
        if cfg['push_data']:
            csv_text = st.to_csv()
            ana = json.dumps(dict(summ, daily=an['daily'], auto=auto), ensure_ascii=False, default=lambda x: None)
            if dry:
                open(os.path.join(cfg['out_dir'], 'coils.csv'), 'w', encoding='utf-8-sig').write(csv_text)
                open(os.path.join(cfg['out_dir'], 'analysis.json'), 'w', encoding='utf-8').write(ana)
                log('[시험] 누적 실적 저장: coils.csv, analysis.json')
            else:
                sb.upload(cfg['data_bucket'], 'coils.csv', csv_text, 'text/csv', cache='0')
                sb.upload(cfg['data_bucket'], 'analysis.json', ana, cache='0')
                log(f"누적 실적 업로드: {cfg['data_bucket']}/coils.csv ({csv_text.count(chr(10)) - 1}코일), analysis.json")
        st.log_run(now.isoformat(), True, '; '.join(auto['notes']))
        log('완료')
        return 0
    except Exception as e:
        log(f'실패: {e}')
        logf.write(traceback.format_exc() + '\n')
        st.log_run(now.isoformat(), False, str(e))
        return 1
    finally:
        logf.close()


def push_extra_only(cfg, dry=False):
    """mes_download.py --remote-only 뒤: 재계획 없이 추가 자료(원격 조회 결과 포함)만 게시"""
    sbc = cfg.get('supabase') or {}
    sb = Supa(sbc['url'], sbc['key'], sbc.get('ssl_verify', True)) if sbc.get('url') and sbc.get('key') else None
    if not sb and not dry:
        raise SystemExit('설정에 supabase.url/key 가 없습니다')
    os.makedirs(cfg['out_dir'], exist_ok=True)
    pre = 'test.' if cfg['published_path'].startswith('test') else ''
    run_at = _dt.datetime.now(_dt.timezone.utc).isoformat(timespec='minutes')
    msg, xt = push_extra(cfg, sb, dry, run_at, pre)
    print('추가 자료 게시:', msg or '없음')
    # 화면 자료도 다시 만듦(2시간마다): 실적·계획은 아침 그대로(누적 실적 + 게시된 계획), 원격 조회 표(기발주·입고·작업지시·정지)만 새 값
    try:
        st = ST.Store(cfg['store'])
        last = st.last_day()
        if last and xt:
            from . import pages as PG
            R, _ = load_base(cfg, sb, print)
            d_from = U.add_days(last, -cfg['window_days'])
            auto = {'runAt': run_at, 'remoteOnly': True, 'notes': ['2시간 원격 조회 — 실적·계획은 아침 실행 기준'], 'actualTo': ((R or {}).get('replan') or {}).get('t0')}
            PG.publish(cfg, sb, dry, xt, st.coils(d_from), R, R, auto, print, PB.encrypt, stops=st.stops(mes.to_min(d_from)))
    except Exception as e:
        print(f'화면 자료 게시 실패(추가 자료는 게시됨): {e}')
    return 0


def push_extra(cfg, sb, dry, run_at, prefix=''):
    """mes/extra/*.json(표: columns·rows)을 out_dir/extra_acc 에 누적(같은 행 중복 제외, snap_* 은 최신으로 교체)해
    published/{prefix}extradata.enc.json 으로 암호화 게시. 반환: 요약 문자열(없으면 '')"""
    dirs = {os.path.dirname(pat) or '.' for pat in cfg['mes_inputs']}
    files = sorted({f for d in dirs for f in glob.glob(os.path.join(d, 'extra', '*.json'))})
    acc_dir = os.path.join(cfg['out_dir'], 'extra_acc')
    if not files and not glob.glob(os.path.join(acc_dir, '*.json')):   # 2026-10-28: 새 파일이 없어도 누적본이 있으면 그것으로 화면 계산(예전엔 빈 표로 화면을 덮었음)
        return '', {}
    os.makedirs(acc_dir, exist_ok=True)
    tables = {}
    for f in files:
        name = os.path.splitext(os.path.basename(f))[0]
        new = json.load(open(f, encoding='utf-8'))
        ap = os.path.join(acc_dir, name + '.json')
        old = json.load(open(ap, encoding='utf-8')) if os.path.exists(ap) else None
        if name == 'snap_stock':
            new = TB.merge_months(new, old)                     # 재고현황: 받은 달은 교체, 안 받은 마감 달은 누적본 그대로(최근 6개월)
        elif not name.startswith('snap_'):
            new = TB.merge(name, new, old)                      # 새 자료 우선, 같은 코일·같은 날은 한 행(cglplan/tables.py)
        json.dump(new, open(ap, 'w', encoding='utf-8'), ensure_ascii=False)
        tables[name] = new
    for ap in sorted(glob.glob(os.path.join(acc_dir, '*.json'))):     # 한 번만 받는 조회(once) 결과가 mes/extra 에서 사라져도(설치 폴더 교체 등) 누적본으로 계속 게시
        name = os.path.splitext(os.path.basename(ap))[0]
        if name not in tables and name != 'salesrpt_hist':
            try:
                tables[name] = json.load(open(ap, encoding='utf-8'))
            except Exception:
                pass
    # 판매생산속보는 매일 최신으로 교체되므로 날짜별 사본을 따로 누적(salesrpt_hist: 속보 시각 + 원래 칸) — 속보 누계와 MES 합 대조용
    rp = tables.get('snap_salesrpt')
    if rp and rp.get('rows'):
        import re as _re
        m = next((_re.search(r'\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2})\]', str(r[-1])) for r in rp['rows'] if _re.search(r'\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}\]', str(r[-1]))), None)
        if m:
            hp = os.path.join(acc_dir, 'salesrpt_hist.json')
            h = json.load(open(hp, encoding='utf-8')) if os.path.exists(hp) else {'columns': ['asOf'] + rp['columns'], 'rows': []}
            h['rows'] = [r for r in h['rows'] if r[0] != m.group(1)] + [[m.group(1)] + list(r) for r in rp['rows']]
            json.dump(h, open(hp, 'w', encoding='utf-8'), ensure_ascii=False)
            tables['salesrpt_hist'] = h
    body = {'app': 'cgl-extradata', 'version': 1, 'savedAt': run_at, 'tables': tables}
    enc = json.dumps(PB.encrypt(body, cfg['analysis_password'] or cfg['password'], '분석용 추가 자료'))
    path = prefix + 'extradata.enc.json'
    head = f"새 파일 {len(files)}개 · 암호문 {len(enc) / 1e6:.1f}MB"
    try:
        if dry:
            open(os.path.join(cfg['out_dir'], path), 'w', encoding='utf-8').write(enc)
        else:
            sb.upload(cfg['published_bucket'], path, enc)
    except Exception as e:                                       # 2026-10-28: 업로드가 실패해도 표는 돌려줘 화면 자료(홈·컬러·재고)는 계산되게
        return f"⚠ {path} 업로드 실패({head}): {str(e)[:200]}", tables
    return f"{path} ({head}; " + ', '.join(f"{k} {len(v['rows'])}행" for k, v in tables.items()) + ')', tables


def supatest(cfg):
    """사내 PC에서 Supabase 연결·키·업로드 확인"""
    sbc = cfg.get('supabase') or {}
    sb = Supa(sbc['url'], sbc['key'], sbc.get('ssl_verify', True))
    names = sb.check()
    print('버킷:', names)
    for b in (cfg['published_bucket'], cfg['data_bucket']):
        if b not in names:
            print(f'  ⚠ 버킷 {b} 없음 — Supabase Storage에서 만드세요')
    msg = f'연결 시험 {_dt.datetime.now().isoformat()}'
    sb.upload(cfg['data_bucket'], 'connection_test.txt', msg, 'text/plain', cache='0')
    back = sb.download(cfg['data_bucket'], 'connection_test.txt')
    print('업로드·내려받기:', 'OK' if back and back.decode('utf-8') == msg else f'불일치 {back!r}')
    return 0
