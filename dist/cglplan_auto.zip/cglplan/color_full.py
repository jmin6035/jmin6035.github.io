"""컬러 1~4CCL 전체 일별 가동계획 (계획재 + 주문재 + 건재수출 + 가전수출 + 가전내수 + 수요개발).

TF「컬러·도금 일별가동계획」 구조를 따르되 다음을 우리 자료로 바꿈
  · 월 물량 기준: 라인 한도 없음 — 하루 1,440분(− 휴지계획)에 만들 수 있는 만큼(2026-10-16). MES 월차계획은 비교용으로만
  · 기초재고: MES 재고현황 월말 재고(그룹·품명 풀), 이번 달 실적은 생산필요량에서 뺌
  · T/hr: MES 컬러 실적(최근 3개월, 휴지 포함 = 톤 ÷ (작업+휴지 시간)), 품명·라인별
  · 가능 라인: 필수재 규칙 + 최근 실적 라인(20t 이상). 2CCL 은 최후 순위·이미 가동하는 날에 몰아서
  · 계획재: cglplan.color(EOQ·추천반순, 사양 단위·교체시간 포함)
수요(판매계획) 입력: TF 파일의 '컬러_판매계획' 시트(③ 주문재 ④ 수출 ⑤ 가전내수 ⑥ 수요개발) — 새 버전을 넣으면 다시 계산
수출 목적지·선적창: 같은 TF 파일의 그룹 시트(컬러건재수출·컬러가전수출)에 있는 목적지·배선 비중을 그대로 사용
"""
import calendar
import os
import datetime as dt
import json
import re
from collections import Counter, defaultdict

from . import color as CL

GROUPS = ['계획재', '주문재', '건재수출', '가전수출', '가전내수', '수요개발']
from .tfrules import DAYS as _TFD                                    # 11/9: TF 목표 일수 원본 = cglplan/tf_rules.json(가전내수 30→45)
TARGET_DAYS = {k: _TFD[k] for k in ('주문재', '건재수출', '가전수출', '가전내수', '수요개발')}
LOT_T = {'주문재': 60, '건재수출': 100, '가전수출': 100, '가전내수': 80, '수요개발': 60}
LOT_MAX = {'주문재': 6, '건재수출': 6, '가전수출': 6, '가전내수': 6, '수요개발': 3}
PRIORITY = {'수출벌크': 1, '수출': 2, '가전내수': 3, '수요개발': 3, '주문재': 3}   # 2026-10-17 사용자(산출기준서 L-21): 수출 벌크 → 수출 → 가전내수·수요개발·주문재 → 계획재(남는 시간)
MONTH_COL = re.compile(r'(\d{2})\.(\d{1,2})월\s*판매계획')


def _f(x, d=0.0):
    try:
        return float(x)
    except (TypeError, ValueError):
        return d


def base_name(p):
    """판매계획 품명 → (기본 품명, MAC 여부): 'PGS(MAC.)'→('PGS',True), 'PCS(가전)'→('PCS',False), 'PDF-AL(후물)_유니언스'→('PDF-AL',False)"""
    s = str(p or '').strip()
    mac = '(MAC' in s.upper()
    s = re.sub(r'\(MAC\.?\)', '', s, flags=re.I)
    s = re.sub(r'\((가전|후물|프)\)', '', s)
    s = s.split('_')[0].strip()
    return s, mac


# ---------------------------------------------------------------- 판매계획
def load_sales(path):
    """TF '컬러_판매계획' → 행 목록 {group, product, mac, region, customer, sales{YYYY-MM: t}, targetDays}"""
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    rows = list(wb['컬러_판매계획'].iter_rows(values_only=True))
    out, sec, cols, tdcol = [], None, {}, None
    for r in rows:
        a = str(r[0] or '').strip()
        if a.startswith('③'):
            sec = '주문재'
        elif a.startswith('④'):
            sec = '수출'
        elif a.startswith('⑤'):
            sec = '가전내수'
        elif a.startswith('⑥'):
            sec = '수요개발'
        elif a.startswith(('①', '②')):
            sec = None
        if sec and a in ('부서', '그룹'):                        # 머리글 행
            cols, tdcol = {}, None
            for j, h in enumerate(r):
                m = MONTH_COL.search(str(h or '').replace('\n', ' '))
                if m:
                    cols[j] = f'20{m.group(1)}-{int(m.group(2)):02d}'
                if '목표재고' in str(h or '') and '일수' in str(h or ''):
                    tdcol = j
            continue
        if not sec or not cols or a in ('', '합계') or a.startswith(('③', '④', '⑤', '⑥', '※')):
            continue
        if sec == '주문재' and r[1] != '주문재':
            continue
        grp = {'주문재': '주문재', '가전내수': '가전내수', '수요개발': '수요개발'}.get(sec) or \
            ('건재수출' if '건재' in a else '가전수출')
        prod, mac = base_name(r[2])
        sales = {ym: _f(r[j]) for j, ym in cols.items()}
        if not any(sales.values()):
            continue
        out.append({'group': grp, 'productRaw': r[2], 'product': prod, 'mac': mac,
                    'region': str(r[3] or '').strip() if sec == '수출' else '', 'customer': str(r[3] or '').strip() if sec != '수출' and sec != '주문재' else '',
                    'note': str(r[4] or ''), 'sales': sales,
                    'targetDays': _f(r[tdcol], None) if tdcol is not None else None})
    return out


def load_export_dest(path):
    """TF 그룹 시트(컬러건재수출·컬러가전수출) → (그룹, 기본품명, 지역, 판매월) → [(목적지, 배선, 완료일 또는 None=월중 균등, 비중)]"""
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    agg = defaultdict(Counter)
    for sh, grp in (('컬러건재수출', '건재수출'), ('컬러가전수출', '가전수출')):
        rows = list(wb[sh].iter_rows(values_only=True))
        h = [str(x or '').replace('\n', '') for x in rows[0]]
        ix = {k: h.index(k) for k in ('품명', '지역', '목적지명', '배선일정', '생산량(톤)', '생산기준(배선일정)', '판매월')}
        for r in rows[1:]:
            if not r[ix['품명']]:
                continue
            sm = str(r[ix['판매월']] or '')
            m = re.match(r'(\d{2})\.(\d{1,2})', sm)
            if not m:
                continue
            ym = f'20{m.group(1)}-{int(m.group(2)):02d}'
            basis = str(r[ix['생산기준(배선일정)']] or '')
            due = None
            mm = re.search(r'(\d{1,2})일까지', basis) or re.search(r'완료기한\s*(\d{1,2})일', basis)
            if mm:
                due = int(mm.group(1))
            if '전월 말 선생산' in basis:                       # 판매월 1~5일 벌크 선적 → 전월 말에 생산
                due = -1
            bulk = '벌크' in basis
            region = str(r[ix['지역']] or '').split('→')[0].strip()
            agg[(grp, base_name(r[ix['품명']])[0], region, ym)][(str(r[ix['목적지명']] or '미정'), str(r[ix['배선일정']] or ''), due, bulk)] += _f(r[ix['생산량(톤)']])
    out = {}
    for k, c in agg.items():
        tot = sum(c.values()) or 1
        out[k] = [(d, s, due, bulk, v / tot) for (d, s, due, bulk), v in c.items() if v > 0]
    return out


# ---------------------------------------------------------------- 재고 풀
def stock_pools(snap_stock, specs, month=None):
    """재고현황 컬러 제품 → (그룹, 기본품명, MAC) → 톤. 계획재 사양과 일치하는 건재 재고는 계획재로(여기서 제외)"""
    T = [dict(zip(snap_stock['columns'], r)) for r in snap_stock['rows']]
    month = month or max(r['_기준월'] for r in T)
    m = CL.Matcher(specs)
    pools = Counter()
    for r in T:
        if r['_기준월'] != month or r['공장구분'] != 'C' or r['구분명'] != 'P':
            continue
        dept, cust = str(r['담당부서(HR)'] or ''), str(r['고객사'] or '')
        prod = m.nm(r['품명코드'])
        mac = str(r['도금량'] or '').startswith('M')
        t = _f(r['중량']) / 1000
        if dept.startswith('컬러건재판매'):
            if m(r['품명코드'], _f(r['제품두께']), _f(r['제품폭']), r['표면상도코드'], tolt=0.02):
                continue
            g = '주문재'
        elif dept.startswith('컬러수출'):
            g = ('건재수출' if '수출1' in dept else '가전수출') if cust.startswith('J') else '가전내수'
        elif dept.startswith('수요개발'):
            g = '수요개발'
        else:
            continue
        pools[(g, base_name(prod)[0], mac)] += t
    return pools, month


def _pool_key(row):
    mac = row['mac'] if row['group'] == '주문재' else None      # 수출·가전은 MAC 구분 없이 품명 풀
    return (row['group'], row['product'], mac)


def needs(sales, pools, ym, ndays_next, next_ym, plan_spec_demand=None):
    """판매계획 행별 이번 달 생산필요량 = MAX(0, 판매 + 목표기말 − 기초재고(풀을 판매 비중으로 배분))
    주문재 판매 = 품명 판매계획 − 같은 품명 계획재 수요(EOQ 월평균) — TF 와 같은 정의"""
    plan_spec_demand = plan_spec_demand or {}
    pool_sales = Counter()
    for r in sales:
        s = r['sales'].get(ym, 0)
        if r['group'] == '주문재':
            s = max(0.0, s - plan_spec_demand.get((r['product'], r['mac']), 0))
        r['salesM'] = s
        r['salesNext'] = r['sales'].get(next_ym, 0) if r['group'] != '주문재' else max(0.0, r['sales'].get(next_ym, 0) - plan_spec_demand.get((r['product'], r['mac']), 0))
    for r in sales:
        k = _pool_key(r)
        pool_sales[k] += r['salesM'] + r['salesNext'] * 0.01
    for r in sales:
        k = _pool_key(r)
        tot = sum(v for (g, p, mc), v in pools.items() if (g, p) == k[:2] and (k[2] is None or mc == k[2]))
        share = (r['salesM'] + r['salesNext'] * 0.01) / pool_sales[k] if pool_sales[k] else 0
        r['stock0'] = tot * share
        td = r['targetDays'] if r['targetDays'] else TARGET_DAYS[r['group']]
        r['targetEnd'] = r['salesNext'] * td / ndays_next
        r['need'] = max(0.0, r['salesM'] + r['targetEnd'] - r['stock0'])
    return sales


# ---------------------------------------------------------------- 속도·라인
DEPT_OF_GROUP = {'계획재': '컬러건재판매그룹', '주문재': '컬러건재판매그룹', '건재수출': '컬러수출그룹', '가전수출': '컬러수출그룹',
                 '가전내수': '컬러수출그룹', '수요개발': '수요개발그룹'}
SPLIT = {'dept': True}                                           # 부서별 속도 사용(False = 품명·라인만, 비교용)
# 2026-10-21 사용자 "엑셀로 교체": 계획 속도의 기준 = 「컬러 품목별 단위생산량(2508_2607)」(tools/color_unit_speed.py → data/color_unit_speed.json).
# 엑셀 부서: 컬러건재판매(계획재·주문재) · 컬러수출 건재 · 컬러수출 가전(가전수출·가전내수) · 신수요(수요개발). 엑셀에 없는 품명만 MES 실적(thr_table)
UNIT_DEPT = {'계획재': '컬러건재판매', '주문재': '컬러건재판매', '건재수출': '컬러수출 건재', '가전수출': '컬러수출 가전',
             '가전내수': '컬러수출 가전', '수요개발': '신수요'}
USE_UNIT = {'on': os.environ.get('CGL_UNIT_SPEED', '1') == '1'}
UNIT_KEYS = set()                                                # plan_thr 가 엑셀 값으로 덮은 (품명, 라인)


def unit_speed():
    """(품명, 라인, 엑셀 부서) → (t/hr, 톤) + (품명, 라인) → 부서 합산(톤 가중: 톤 ÷ 시간 합)"""
    here = os.path.dirname(os.path.abspath(__file__))
    p = os.path.join(os.path.dirname(here), 'data', 'color_unit_speed.json')
    if not os.path.exists(p):
        p = os.path.join(here, 'pages_base', 'color_unit_speed.json')
    if not os.path.exists(p):
        return {}
    out, t, h = {}, Counter(), Counter()
    for x in json.load(open(p, encoding='utf-8'))['items']:
        out[(x['p'], x['line'], x['dept'])] = (x['tph'], x['t'])
        t[(x['p'], x['line'])] += x['t']
        h[(x['p'], x['line'])] += x['t'] / x['tph']
    for k in t:
        out[k] = (t[k] / h[k], t[k])
    return out


def plan_thr(color_prod, d0, d1):
    """계획 속도표 = MES 실적(thr_table) 위에 단위생산량 엑셀을 덮어씀 — (품명, 라인) 은 엑셀 값, (품명, 라인, 'U:'+엑셀 부서) 추가.
    엑셀 품명은 판매계획 이름 그대로(POR5-STS 등) — MES 제품코드 이름(POR5)으로는 못 찾던 품명이 해결됨"""
    thr = thr_table(color_prod, d0, d1)
    if not USE_UNIT['on']:
        return thr
    U = unit_speed()
    for k, v in U.items():
        if len(k) == 2:
            thr[k] = v
            UNIT_KEYS.add(k)
            for kk in [kk for kk in thr if len(kk) == 3 and kk[:2] == k and not str(kk[2]).startswith('U:')]:
                del thr[kk]                                     # 엑셀에 있는 품명·라인은 MES 부서별 값도 쓰지 않음
        else:
            thr[(k[0], k[1], 'U:' + k[2])] = v
    return thr


def thr_table(color_prod, d0, d1):
    """(기본품명, 라인) → 휴지 포함 t/hr, 톤. 품명은 제품코드 → 판매 품명.
    + (기본품명, 라인, 부서) — 같은 품명·라인이라도 부서마다 두께·폭 구성이 달라 속도가 다름(7~9월 검증: 일·라인 오차 21.1% → 20.0%)"""
    cd = CL._codes()
    t, h = Counter(), Counter()
    for r in color_prod['rows']:
        x = dict(zip(color_prod['columns'], r))
        if not (d0 <= x['PRD_DT'] <= d1):
            continue
        p = base_name((cd.get(x['PDT_NM']) or {}).get('name', x['PDT_NM']))[0]
        for k in ((p, x['LINE']), (p, x['LINE'], str(x.get('DEPT') or ''))):
            t[k] += _f(x['PDT_WGT']) / 1000
            h[k] += (_f(x['WRK_TIME']) + _f(x['PAU_TIME'])) / 60
    return {k: (t[k] / h[k], t[k]) for k in t if h[k] > 0}


RULE_LINES = [  # 필수재 규칙(TF 필수재 시트 + 사용자: print 는 2·4라인, POR2 는 빠른 라인)
    (lambda p, g: p.startswith('PVS'), ['1CCL']),
    (lambda p, g: p.startswith(('PPG', 'PPK', 'PPH')), ['4CCL', '2CCL']),
    (lambda p, g: p.endswith('-AL') or p in ('PVDF', 'PUR2', 'PDFM'), ['4CCL']),
    (lambda p, g: p.endswith('-STS') or p.startswith(('PLY', 'ETC4')), ['3CCL']),
]


FASTEST = {'on': os.environ.get('CGL_LINE_FASTEST', '1') == '1'}   # 11/3 사용자 't/hr 최우선, 가장 빠른 라인' — 0 이면 예전(규칙 파일·2CCL 후순위)
USE_LINE_RULES = {'on': os.environ.get('CGL_LINE_RULES', '1') == '1'}   # 품목별 필수·우선 라인 파일(cglplan.line_rules) — 2026-10-14 사용자 결정으로 기본 켬(필수 라인이 서면 두 번째 라인)


def lines_for(prod, group, thr, row=None):
    """가능 라인(앞 순서 우선). USE_LINE_RULES 가 켜져 있고 규칙 파일에 품명이 있으면 그 규칙(필수라인 = 그 라인만, 우선라인 = 순서), 없으면 아래 기존 규칙"""
    if FASTEST['on']:                                          # 11/3 사용자: t/hr 최우선 — 단 라인 규칙 안에서(필수재·고객별 라인·Print 4CCL 은 지킴)
        if prod.startswith(('PPG', 'PPK', 'PPH', 'PPF')):        # Print 는 무조건 4CCL(사용자 11/3)
            return ['4CCL']
        ls = None
        if USE_LINE_RULES['on']:
            from . import line_rules as LR
            x = LR.lookup(prod, group, (row or {}).get('mac'), (row or {}).get('region', ''), (row or {}).get('customer', ''))
            if x and x['must']:
                return [x['must']]                             # 필수 라인(고객·품목별) 그대로
            ls = list(x['prefer']) if x else None
        if not ls:
            ls = [l for l in CL.LINES if (thr.get((prod, l)) or (0, 0))[1] >= 20]
        if ls:                                                 # 허용 라인 안에서 빠른 순, 2CCL 은 맨 뒤(11/9 회의: 회사 정책상 2CCL 은 1·3·4CCL 이 찰 때만)
            return sorted(ls, key=lambda l: (l == '2CCL', -((thr.get((prod, l)) or (0,))[0])))
    if USE_LINE_RULES['on']:
        from . import line_rules as LR
        ls = LR.lines(prod, group, (row or {}).get('mac'), (row or {}).get('region', ''), (row or {}).get('customer', ''))
        if ls:
            return ls
    for f, ls in RULE_LINES:
        if f(prod, group):
            hist = [l for l in ls if (prod, l) in thr]
            return ls if not hist else sorted(ls, key=lambda l: (l == '2CCL', -(thr.get((prod, l), (0,))[0])))
    hist = [l for l in CL.LINES if thr.get((prod, l), (0, 0))[1] >= 20]
    if not hist:                                               # 실적 없는 품명: 3라인(가전 전용) 제외 일반 라인
        hist = ['1CCL', '4CCL', '2CCL'] if not group.startswith('가전') else ['3CCL', '4CCL', '1CCL', '2CCL']
    if '3CCL' in hist and not group.startswith('가전') and len(hist) > 1 and thr.get((prod, '3CCL'), (0, 0))[1] < 200:
        hist.remove('3CCL')                                    # 3라인은 가전 전용 운영(실적 적은 건재 품명은 제외)
    return sorted(hist, key=lambda l: (l == '2CCL', -(thr.get((prod, l)) or (0,))[0]))


def backup_lines(prod, group, thr, row=None):
    """두 번째 라인 목록. 규칙 파일에 backup 이 적혀 있으면 그것(11/9 사용자 — 가전 PCS 4·2CCL, PPG 2CCL, POR2 3CCL, PES5 건재 1·4CCL), 없으면 backup_line 하나"""
    if not USE_LINE_RULES['on']:
        return []
    from . import line_rules as LR
    x = LR.lookup(prod, group, (row or {}).get('mac'), (row or {}).get('region', ''), (row or {}).get('customer', ''))
    if x and x.get('backup'):
        return list(x['backup'])
    b = backup_line(prod, group, thr, row)
    return [b] if b else []


def backup_line(prod, group, thr, row=None):
    """필수 라인이 있는 품명의 두 번째 라인(2026-10-13 사용자 결정: 필수 라인이 서면 두 번째 라인으로).
    = 13주 실적에서 필수 라인 다음으로 많이 만든 라인(코일 20개 이상), 없으면 기존 규칙(규칙 파일 없을 때의 가능 라인) 중 필수 라인이 아닌 첫 라인.
    규칙 파일을 켰을 때만, 필수 라인이 있을 때만 값이 있음"""
    if not USE_LINE_RULES['on']:
        return None
    from . import line_rules as LR
    x = LR.lookup(prod, group, (row or {}).get('mac'), (row or {}).get('region', ''), (row or {}).get('customer', ''))
    if not x or not x['must']:
        return None
    m = x['must']
    hist = sorted((l for l in CL.LINES if l != m and thr.get((prod, l), (0, 0))[1] >= 20), key=lambda l: -thr[(prod, l)][1])
    if hist:
        return hist[0]
    USE_LINE_RULES['on'] = False
    try:
        rest = [l for l in lines_for(prod, group, thr, row) if l != m]
    finally:
        USE_LINE_RULES['on'] = True
    return rest[0] if rest else None


def tph_for(prod, line, thr, group=None):
    if SPLIT['dept'] and group:
        v = thr.get((prod, line, 'U:' + UNIT_DEPT.get(group, '')))
        if v and v[1] >= 30:
            return v[0], '단위생산량(품명·라인·부서)'
        v = thr.get((prod, line, DEPT_OF_GROUP.get(group, '')))
        if v and v[1] >= 30:
            return v[0], '품명·라인·부서 실적'
    v = thr.get((prod, line))
    if v and v[1] >= 10:
        return v[0], ('단위생산량(품명·라인)' if (prod, line) in UNIT_KEYS else '품명·라인 실적')
    vs = [(a, b) for k, (a, b) in thr.items() if len(k) == 2 and k[0] == prod and b >= 10]
    if vs:
        return sum(a * b for a, b in vs) / sum(b for a, b in vs), '품명 실적(타라인 평균)'
    vs = [(a, b) for k, (a, b) in thr.items() if len(k) == 2 and k[1] == line]
    return (sum(a * b for a, b in vs) / sum(b for a, b in vs), '라인 평균') if vs else (10.0, '가정')


# ---------------------------------------------------------------- 로트 만들기
def make_lots(sales, dest, ym, ndays, start_day, next_ym=None):
    lots = []
    span0 = start_day
    for r in sales:                                            # 다음 달 1~5일 벌크 선적분 → 이번 달 말 10일 안에 선생산
        if r['group'] not in ('건재수출', '가전수출') or not next_ym or not r['salesNext']:
            continue
        for d, ship, due, bulk, w in dest.get((r['group'], r['product'], r['region'], next_ym)) or []:
            if due != -1:
                continue
            q = max(0.0, (r['salesNext'] - r['targetEnd']) * w)
            if q < 0.5:
                continue
            r['preNext'] = r.get('preNext', 0) + q
            n = 1                                              # 11/9 회의: 로트 톤 기준(벌크 400t 등) 삭제 — 선적 상한일수(TF, 수출 15일) 창 안에서 한 묶음
            for k in range(n):
                lots.append({'row': r, 'group': r['group'], 'dest': d, 'ship': ship + ' (다음달 판매분 선생산)', 't': q / n,
                             'release': max(start_day, ndays - _TFD[r['group']] + 1), 'due': ndays, 'prio': PRIORITY['수출벌크'], 'k': k + 1})
    for r in sales:
        need = r.get('needLeft', r['need'])
        if need < 1:
            continue
        g = r['group']
        if g in ('건재수출', '가전수출'):
            ds = dest.get((g, r['product'], r['region'], ym)) or [('미정', '', None, False, 1.0)]
            for d, ship, due, bulk, w in ds:
                q = need * w
                if q < 0.5:
                    continue
                if due == -1:                                  # 이번 달 1~5일 선적분: 지난달 생산 대상 → 남았으면 바로
                    due = start_day + 2
                if due:                                        # 선적 완료기한 있음: 벌크는 기한 전 10일 안, 컨테이너 월말은 기한 전
                    due = max(due, start_day)
                    n = 1                                      # 11/9 회의: 로트 톤 기준 삭제, 선적 전 상한일수(15일) 안에서 생산
                    for k in range(n):
                        lots.append({'row': r, 'group': g, 'dest': d, 'ship': ship, 't': q / n, 'release': max(start_day, due - _TFD[g]),
                                     'due': due, 'prio': PRIORITY['수출벌크' if bulk else '수출'], 'k': k + 1})
                else:
                    lots += _even(r, g, q, ndays, span0, PRIORITY['수출'], d, ship)
        else:
            lots += _even(r, g, need, ndays, span0, PRIORITY[g], '', '')
    return lots


def _even(r, g, q, ndays, start, prio, dest, ship):
    n = max(1, min(LOT_MAX[g], -(-(ndays - start + 1) // 7)))   # 11/9 회의: 로트 톤(주문재 60t 등)으로 자르지 않음 — 남은 기간을 주 단위로 고르게
    span = (ndays - start + 1) / n
    out = []
    for k in range(n):
        rel = start + int(k * span)
        out.append({'row': r, 'group': g, 'dest': dest, 'ship': ship, 't': q / n, 'release': rel,
                    'due': min(ndays, int(start + (k + 1) * span + 2)), 'prio': prio, 'k': k + 1})
    return out


# ---------------------------------------------------------------- 일별 배정
SEQ = os.environ.get('CGL_SEQ') == '1'                     # 2026-10-20 사용자: 일 단위 순서는 전환 휴지 최소(학습 방 key_matrix) — 켜기 전 전후 비교 후 확인
_TR = []


def _trans():
    if not _TR:
        from .transition import Trans
        _TR.append(Trans())
    return _TR[0]


def schedule(lots, thr, cap_t, occ, ndays, start_day, prefer=None):
    """lots 를 (라인, 일) 1,440분 칸에 배정. cap_t: 라인 남은 월 톤 한도, occ: (일, 라인) → 이미 쓴 분(계획재)
    prefer: 로트 키 → [(일, 라인)] — 재계획 때 지난 계획 자리를 먼저 시도(일정이 통째로 바뀌지 않게). 키 = lot_key(로트)
    반환: 배정 행 목록, 미편성 로트"""
    free = defaultdict(lambda: 1440.0)
    for k, v in occ.items():
        free[k] = max(0.0, 1440.0 - v)
    used_t = Counter()
    run_days = defaultdict(set)
    for (d, l), v in occ.items():
        if v > 0:
            run_days[l].add(d)
    placed, unplaced = [], []
    TR = _trans() if SEQ else None
    on = defaultdict(set)                                   # (일, 라인) → 그날 도는 단위(섹션·목적지·품명) — CGL_SEQ: 같은 단위가 도는 날·그 앞뒤 날에 먼저 붙여 전환 휴지를 줄임
    ukey = lambda x, l: TR.key(l, x['group'], x['row']['product'], x.get('dest', ''), x['row'].get('customer') or x['row'].get('region') or '')
    # 한 라인에서만 되는 품명(STS→3CCL, 후물·AL→4CCL 등)을 먼저 넣고, 여러 라인이 되는 품명은 남은 칸에 — 전용 라인을 범용 품명이 먼저 차지하지 않게
    # 집약 묶음(camp)은 맨 먼저, 묶음 안 순서대로 연속 배치(2026-10-19 사용자: 라인별 필수품목 집약)
    lots.sort(key=lambda x: (not x.get('camp'), x.get('campOrd', 0), (len(x['force']) > 1) if x.get('force') else (len(lines_for(x['row']['product'], x['group'], thr, x['row'])) > 1), x['prio'], x['due'], -x['t']))
    for x in lots:
        prod = x['row']['product']
        cands = x.get('force') or lines_for(prod, x['group'], thr, x['row'])
        if FASTEST['on'] and x.get('campLine') == '3CCL' and not x.get('force'):    # STS·Lami 집약(3CCL)은 3CCL 먼저 — 4CCL 은 AL·광폭 STS·Print 전용이 많아 빠르다고 보내면 전용 품명이 밀림(1월 시험 551t 미편성). Print 묶음은 빠른 라인(PPG → 2CCL)
            cands = [x['campLine']] + [l for l in cands if l != x['campLine']]
        left = x['t']
        days_pref = list(range(max(start_day, x['release']), min(ndays, x['due']) + 1)) or [min(ndays, max(start_day, x['due']))]
        days_early = list(range(min(ndays, max(start_day, x['release']) - 1), start_day - 1, -1))
        days_late = list(range(min(ndays, x['due']) + 1, ndays + 1))
        bks = [] if x.get('force') else [b_ for b_ in backup_lines(prod, x['group'], thr, x['row']) if b_ not in cands]
        for d, l in ([] if x.get('camp') else (prefer or {}).get(lot_key(x)) or []):            # 지난 계획 자리 먼저(집약 묶음은 연속이 우선이라 안 씀)
            if left < 0.05:
                break
            if d < start_day or d > ndays or (l not in cands and l not in bks):
                continue
            if d > x['due']:                                   # 어제 자리가 기한 넘긴 자리면 쓰지 않고 처음부터 다시 찾음(11/5 사용자 — VERACRUZ 벌크 기한 11/9 가 11/23~ 에 묶여 있던 것)
                continue
            tph, src = (x['tph'], x.get('tphSrc', '로트 지정')) if x.get('tph') else tph_for(prod, l, thr, x['group'])
            room_t = cap_t.get(l, 0) - used_t[l]
            if room_t <= 0.05 or free[(d, l)] < 5:
                continue
            q = min(left, free[(d, l)] / 60 * tph, room_t)
            mins = q / tph * 60
            free[(d, l)] -= mins
            used_t[l] += q
            run_days[l].add(d)
            left -= q
            placed.append({'lot': x, 'day': d, 'line': l, 't': q, 'min': mins, 'tph': tph, 'src': src, 'late': d > x['due'], 'early': d < x['release'], 'kept': True})
            if TR:
                on[(d, l)].add(ukey(x, l))
        if bks:                                                # 필수·우선 라인 먼저(납기 안 → 앞당김) → 그래도 남으면 백업 라인(순서대로) → 늦게
            seq = [(p_, l) for p_ in ('pref', 'early') for l in cands] + [(p_, b_) for b_ in bks for p_ in ('pref', 'early')] + [('late', l) for l in cands + bks]
        else:
            seq = [(p_, l) for p_ in ('pref', 'early', 'late') for l in cands]
        for pass_, l in seq:
            if left < 0.05:
                break
            tph, src = (x['tph'], x.get('tphSrc', '로트 지정')) if x.get('tph') else tph_for(prod, l, thr, x['group'])
            ds = {'pref': days_pref, 'early': days_early, 'late': days_late}[pass_]
            if l == '2CCL':                                # 2CCL: 이미 가동하는 날 먼저(몰아주기)
                ds = sorted(ds, key=lambda d: (d not in run_days[l], d))
            if TR and pass_ != 'late':
                uk = ukey(x, l)
                ds = sorted(ds, key=lambda d: (uk not in on[(d, l)] and uk not in on[(d - 1, l)] and uk not in on[(d + 1, l)], ds.index(d)))
            for d in ds:
                if left < 0.05:
                    break
                room_t = cap_t.get(l, 0) - used_t[l]
                if room_t <= 0.05 or free[(d, l)] < 5:
                    continue
                q = min(left, free[(d, l)] / 60 * tph, room_t)
                mins = q / tph * 60
                free[(d, l)] -= mins
                used_t[l] += q
                run_days[l].add(d)
                left -= q
                placed.append({'lot': x, 'day': d, 'line': l, 't': q, 'min': mins, 'tph': tph, 'src': src,
                               'late': pass_ == 'late', 'early': pass_ == 'early', 'backup': l in bks})
                if TR:
                    on[(d, l)].add(ukey(x, l))
        if left >= 0.05:
            if os.environ.get('CGL_DBG_UNPL'):
                print('DBG 미편성', prod, x['group'], round(left, 1), 'cands', cands, 'bk', bks, 'win', x['release'], x['due'], 'camp', x.get('camp'), {l: round(sum(free[(d, l)] for d in range(start_day, ndays + 1))) for l in cands})
            unplaced.append((x, left))
    return placed, unplaced, used_t


# ---------------------------------------------------------------- 집약(2026-10-19 사용자 조건 시트) · STS 폭 기준
CAMPAIGNS = [   # 라인별 필수품목은 제품군별로 모아 정한 횟수로만 생산(묶음 안에서는 연속)
    {'name': 'PVC Sol', 'line': '1CCL', 'prods': ('PVS2', 'PVS5', 'PVS4'), 'per': 'month', 'n': 1},
    {'name': 'Lami', 'line': '3CCL', 'prods': ('PLY3', 'PLY2', 'PLS2', 'PLY8'), 'per': 'month', 'n': 1},
    {'name': 'STS', 'line': '3CCL', 'prods': ('POR-STS', 'POR3-STS', 'POR5-STS'), 'per': 'week', 'n': 1},
    {'name': '가전 Print', 'line': '4CCL', 'prods': ('PPH',), 'per': 'month', 'n': 1},
    {'name': '건재 Print', 'line': '4CCL', 'prods': ('PPG', 'PPF', 'PPK3', 'PPK', 'PPK-AL'), 'per': 'month', 'n': 2},
]
STS_WIDE = 1270          # STS 폭 1,270mm 이상 = 4CCL(사용자 10/19, 품목별 적용라인의 필수 3CCL 예외)
STS_PRODS = ('POR-STS', 'POR3-STS', 'POR5-STS')


def sts_wide_share(color_prod, d0, d1):
    """STS 품명별 폭 1,270mm 이상 톤 비중(최근 실적) — 판매계획 행에는 폭이 없어서 이 비중으로 4CCL 몫을 나눔"""
    cd = CL._codes()
    I = color_prod['columns'].index
    tot, wide = Counter(), Counter()
    for r in color_prod['rows']:
        if not (d0 <= r[I('PRD_DT')] <= d1):
            continue
        nm = base_name((cd.get(r[I('PDT_NM')]) or {}).get('name', r[I('PDT_NM')]))[0]
        if nm in ('POR', 'POR3', 'POR5'):                      # MES 품명 POR·POR3·POR5 = STS 소재(1년 실적 99.9%, 탄소강은 POR2)
            nm += '-STS'
        if nm in STS_PRODS:
            t = _f(r[I('PDT_WGT')])
            tot[nm] += t
            if _f(r[I('PDT_WDT')]) >= STS_WIDE:
                wide[nm] += t
    return {p: (wide[p] / tot[p] if tot[p] else 0.0) for p in STS_PRODS}


def _periods(per, n, year, month, ndays, start_day):
    """집약 회차 구간 [(시작일, 끝일)] — 이번 달 남은 날 안에서"""
    if per == 'week':
        out, d = [], start_day
        while d <= ndays:
            wd = calendar.weekday(year, month, d)
            e = min(ndays, d + (6 - wd))
            out.append((d, e))
            d = e + 1
        return out
    span = list(range(start_day, ndays + 1))
    k = max(1, min(n, len(span)))
    return [(span[i * len(span) // k], span[(i + 1) * len(span) // k - 1]) for i in range(k)]


def apply_campaigns(lots, r15_left, year, month, ndays, start_day, wide_share):
    """① STS 로트를 폭 비중으로 나눠 넓은 몫은 4CCL 고정 ② 집약 품목 로트(계획재 운영안 배치 포함)를 회차별 한 묶음으로.
    회차 = 그 구간 첫날부터 연속, 묶음 안 순서 = 품명 → (계획재) 운영안 순서. 계획재 배치는 운영안 시간(순수 생산 + 교체)을 그대로 씀.
    반환: (새 로트, 남은 계획재 운영안 배치, 묶음 요약)"""
    if os.environ.get('CGL_CAMP', '1') == '0':                  # 비교용: 집약·STS 폭 끔
        return lots, r15_left, []
    out = []
    for x in lots:                                              # ① STS 폭
        p = x['row']['product']
        w = wide_share.get(p, 0.0) if p in STS_PRODS else 0.0
        if w > 0.01:
            out.append(dict(x, t=x['t'] * w, force=['4CCL'], note='STS 폭 1,270mm 이상 몫(4CCL)'))
            x = dict(x, t=x['t'] * (1 - w))
        out.append(x)
    lots = out
    rest = {l: list(bs) for l, bs in (r15_left or {}).items()}
    summ = []
    for ci, C in enumerate(CAMPAIGNS):
        per = _periods(C['per'], C['n'], year, month, ndays, start_day)
        mine = [x for x in lots if x['row']['product'] in C['prods'] and not x.get('force')]
        lots = [x for x in lots if x not in mine]
        bs = [b for b in rest.get(C['line'], []) if base_name(b['product'])[0] in C['prods']]
        if bs:
            rest[C['line']] = [b for b in rest[C['line']] if b not in bs]
        if not mine and not bs:
            continue
        items = []                                              # (회차, 로트)
        for x in mine:                                          # 마감이 든 회차(마감이 없거나 지났으면 첫 회차)
            k = next((i for i, (a, e) in enumerate(per) if x['due'] <= e), len(per) - 1) if C['per'] == 'week' else \
                next((i for i, (a, e) in enumerate(per) if x['due'] <= e), len(per) - 1)
            items.append((k, x))
        for b in bs:                                            # 계획재: 운영안 원래 날짜가 든 회차
            k = next((i for i, (a, e) in enumerate(per) if b.get('day0', start_day) <= e), len(per) - 1)
            row = {'product': base_name(b['product'])[0], 'productRaw': b['product'], 'region': b['spec'], 'customer': '', 'mac': '(MAC' in b['product']}
            items.append((k, {'row': row, 'group': '계획재', 'dest': '', 'ship': '운영안', 't': b['t'], 'release': start_day, 'due': ndays, 'prio': 4,
                              'k': b['id'], 'tph': b['t'] / b['min'] * 60 if b['min'] else None, 'tphSrc': '계획재 운영안(순수 생산 + 교체)', 'mat': b['mat'], 'spec': b['spec']}))
        for k, (a, e) in enumerate(per):
            grp = sorted((x for kk, x in items if kk == k), key=lambda x: (x['row']['product'], x['group'] == '계획재', str(x['k'])))
            for j, x in enumerate(grp):
                lots.append(dict(x, camp=f"{C['name']} {k + 1}회", campOrd=ci * 1000 + k * 100 + j / 1000, release=a, due=e,
                                 force=[C['line']] if x['group'] == '계획재' else None, campLine=C['line']))   # 주문 로트는 필수라인 규칙 그대로(필수 라인이 차면 두 번째 라인 — 10/13 결정)
            if grp:
                summ.append({'camp': C['name'], 'line': C['line'], 'n': k + 1, 'from': a, 'to': e, 't': round(sum(x['t'] for x in grp), 1)})
    return lots, rest, summ


def lot_key(x):
    r = x['row']
    return '|'.join(map(str, (x['group'], r.get('productRaw'), r.get('region') or r.get('customer'), x.get('dest'), x.get('ship'), x.get('k'))))


def plan_month(specs, tbl_speed, ex_tables, sales, dest, month_plan, year, month, start_day, act_from, act_to, official_target=None):
    """official_target: {'컬러수출': t, '컬러건재': t} (판매생산속보 6-2 목표재고). 주면 TF 목표재고일수로 만든 목표기말재고를
    부서 합계가 공식 목표와 같아지도록 줄이거나 늘림(컬러건재 = 계획재 목표 + 주문재). None 이면 TF 일수 그대로"""
    T = ex_tables
    ndays = calendar.monthrange(year, month)[1]
    ym = f'{year}-{month:02d}'
    ny, nm = (year + 1, 1) if month == 12 else (year, month + 1)
    next_ym, nd_next = f'{ny}-{nm:02d}', calendar.monthrange(ny, nm)[1]
    # ① 계획재(사양 단위)
    stock, smon = CL.stock_by_spec(specs, T['snap_stock'])
    act = CL.actual_stats(specs, T['color_prod'], act_from, act_to)
    act['share'] = {l: (0.0 if l == '3CCL' else 1.0) for l in CL.LINES}   # 전체 계획에서는 계획재도 라인 전체 시간 안에서(나머지 그룹과 같이 1,440분 칸을 나눠 씀)
    dact, made = CL.actual_days(specs, T['color_prod'], year, month, start_day)
    PR = CL.plan(specs, stock, month_plan, act, tbl_speed, year, month, start_day=start_day, made_before=made)
    occ = Counter()
    plan_t_line = Counter()
    for x in PR['lots']:
        s0 = x['startH'] - x['coMin'] / 60
        a, b = s0, x['endH']
        while a < b - 1e-9:
            d = int(a // 24) + 1
            e = min(b, d * 24)
            occ[(min(d, ndays), x['line'])] += (e - a) * 60
            a = e
        plan_t_line[x['line']] += x['t']
    # ② 나머지 그룹: 판매계획 − 재고 + 목표재고 → 이번 달 실적 빼고 남은 필요량
    pools, _ = stock_pools(T['snap_stock'], specs, smon)
    spec_dem = Counter()
    for s in specs:
        spec_dem[(s['name'], '(MAC' in str(s['nameMat']))] += s['demand']
    needs(sales, pools, ym, nd_next, next_ym, spec_dem)
    scale = {}
    if official_target:
        exp = sum(r['targetEnd'] for r in sales if r['group'] in ('건재수출', '가전수출', '가전내수'))
        odr = sum(r['targetEnd'] for r in sales if r['group'] == '주문재')
        plan_tg = sum(sp['target'] for sp in specs)
        scale = {'수출': (official_target.get('컬러수출', 0) / exp) if exp else 1,
                 '주문재': max(0.0, official_target.get('컬러건재', 0) - plan_tg) / odr if odr else 1, '수요개발': 0.0}
        for r in sales:
            k = '수출' if r['group'] in ('건재수출', '가전수출', '가전내수') else r['group']
            r['targetTF'] = r['targetEnd']
            r['targetEnd'] *= scale.get(k, 1)
            r['need'] = max(0.0, r['salesM'] + r['targetEnd'] - r['stock0'])
    thr = plan_thr(T['color_prod'], act_from, act_to)
    # 이번 달 실적(계획재 사양 제외)을 그룹·품명별로 빼기 — 컬러수출 실적은 그 품명의 수출·가전 행에 필요량 비례
    cd = CL._codes()
    m = CL.Matcher(specs)
    done = Counter()
    done_line = Counter()
    for r in T['color_prod']['rows']:
        x = dict(zip(T['color_prod']['columns'], r))
        if not x['PRD_DT'].startswith(ym + '-') or int(x['PRD_DT'][8:]) >= start_day:
            continue
        t = _f(x['PDT_WGT']) / 1000
        done_line[x['LINE']] += t
        if m(x['PDT_NM'], _f(x['REAL_MSR_THK']), _f(x['PDT_WDT']), x['SUR_FINISH_CD']):
            continue
        p = base_name((cd.get(x['PDT_NM']) or {}).get('name', x['PDT_NM']))[0]
        dept = str(x['DEPT'] or '')
        fam = '주문재' if dept.startswith('컬러건재') else ('수요개발' if dept.startswith('수요') else '수출')
        done[(fam, p)] += t
    for r in sales:
        fam = '수출' if r['group'] in ('건재수출', '가전수출', '가전내수') else r['group']
        tot = sum(z['need'] for z in sales if z['product'] == r['product'] and ('수출' if z['group'] in ('건재수출', '가전수출', '가전내수') else z['group']) == fam)
        r['doneM'] = done[(fam, r['product'])] * (r['need'] / tot if tot else 0)
        r['needLeft'] = max(0.0, r['need'] - r['doneM'])
    # ③ 라인 톤 한도 없음(2026-10-16 사용자: 월차로 묶지 않고 하루 1,440분 − 휴지에 만들 수 있는 최대량). 월차는 비교용으로만 남김
    cap = {l: float('inf') for l in CL.LINES}
    lots = make_lots(sales, dest, ym, ndays, start_day, next_ym)
    placed, unplaced, used = schedule(lots, thr, cap, occ, ndays, start_day)
    return {'year': year, 'month': month, 'ndays': ndays, 'ym': ym, 'startDay': start_day, 'planned': PR, 'occ': occ,
            'sales': sales, 'placed': placed, 'unplaced': unplaced, 'cap': cap, 'usedT': used, 'doneLine': done_line,
            'planTLine': plan_t_line, 'monthPlan': month_plan, 'thr': thr, 'stockMonth': smon, 'dayAct': dact,
            'specs': specs, 'pools': pools, 'targetScale': scale, 'officialTarget': official_target}
