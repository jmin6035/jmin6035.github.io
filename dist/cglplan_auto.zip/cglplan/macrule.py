"""2CGL 월 1회 MAC 창 + AL-STS 칸(11/13 사용자 승인) — 재계획 옵션 macRule 로 켬. 웹 엔진 engine/replan.js GP.macRule 과 같은 규칙.
rule(params.js macRule): line·from(이날부터 규칙)·fam(MAC)·base(AL)·day(MAC 시작일, 기본 11)·dayOf({'YYYY-MM': 일})·len(MAC 일수 11)
  · alloy(AL-STS)·slots([[3, 13], [22, 30]] 월초·월말 칸 — 11/16 넓힘)·gap(MAC→AL 복귀 뒤 AL-STS 금지 일수 2)·cap(칸당 연속 최대 3,500t)
  · mac/sts(켜고 끄기 — tools/order_replan 이 data/plan_conditions.json cgl2-mac-window·cgl2-alsts-* use=apply 로 정함)
 ① MAC: from 부터 그 라인 강종 = MAC 창(매달 day일 ~ day+len−1일)이면 MAC, 아니면 AL — 다른 M/C 금지(M/C 고정 lock 으로 넣음, from 전은 기존 고정 그대로)
 ② AL-STS: from 부터 그 라인 AL-STS 는 칸 날짜(복귀 뒤 gap 일·정지 날 뺌)에만, 칸당 cap t 이하
 ③ AL-STS 수요 납기(지연 기준) = 칸 끝: 납기 이전 마지막 칸(소재 입고 rel 뒤), 없으면 그 뒤 첫 칸 — 행에는 원래 납기(due0)를 그대로 씀"""
from . import util as U


def months(a, b):
    y, m = int(a[:4]), int(a[5:7])
    out = []
    while f'{y}-{m:02d}' <= b[:7]:
        out.append(f'{y}-{m:02d}')
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return out


def windows(rule, D1):
    """[(MAC 시작, AL 복귀일)] — 복귀일 = 시작 + len"""
    out = []
    for m in months(rule['from'], D1):
        s = f"{m}-{int((rule.get('dayOf') or {}).get(m, rule.get('day', 11))):02d}"
        out.append((s, U.add_days(s, rule['len'])))
    return out


def setup(P, H, act, rule, MO, notes):
    """MO['lock'][line] 을 규칙대로 바꾸고 MO['slots'] 를 넣음. 반환: 칸 목록 [{from, to, days, cap}]"""
    l, t0, D1, fam, base = rule['line'], act['t0'], H['D1'], rule['fam'], rule['base']
    lock = MO.setdefault('lock', {}) if rule.get('mac', True) else (MO.get('lock') or {})
    k = lock.get(l) or {'from': U.add_days(t0, 1), 'days': {}}
    W = windows(rule, D1)
    if rule.get('mac', True):
        want = lambda d: fam if any(s <= d < e for s, e in W) else base
        start = max(rule['from'], U.add_days(MO.get('freezeUntil') or t0, 1))
        days = {d: f for d, f in k['days'].items() if d < rule['from']}
        prev = None
        for d in U.date_range(start, D1):
            if U.is_blackout(P, l, d):
                continue
            w = want(d)
            if w != prev:
                days[d] = w
            prev = w
        lock[l] = {'from': k['from'], 'days': days, 'to': D1}
        notes.append(f"{l} MAC 월 1회 규칙({U.md(rule['from'])}~): " + ', '.join(f'{U.md(s)}~{U.md(U.add_days(e, -1))}' for s, e in W if e > t0) + ' — 그 외 M/C 없음')
    if not rule.get('sts', True):
        return []
    st, rets = act['state'][l], []                                   # MAC→AL 복귀일(S/D 재가동 포함)
    for d in sorted((lock.get(l) or {}).get('days') or {}):
        f = lock[l]['days'][d]
        if st == fam and f == base:
            rets.append(d)
        st = f
    gapd = {U.add_days(r, i) for r in rets for i in range(int(rule.get('gap') or 0))}
    made = {}
    for d, ln, a, c, t, du in act['rows']:
        if ln == l and a == rule['alloy']:
            made[d] = made.get(d, 0) + t
    slots = []
    for m in months(rule['from'], D1):
        for a, b in rule['slots']:
            s0, s1 = f'{m}-{a:02d}', f'{m}-{b:02d}'
            ds = [d for d in U.date_range(s0, min(s1, D1)) if d > t0 and d not in gapd and not U.is_blackout(P, l, d)]
            if ds:
                cap = max(0.0, rule['cap'] - sum(v for d, v in made.items() if s0 <= d <= s1))
                slots.append({'from': s0, 'to': s1, 'days': ds, 'cap': cap})
    MO['slots'] = {'line': l, 'alloy': rule['alloy'], 'from': rule['from'], 'day': {d: i for i, s in enumerate(slots) for d in s['days']}, 'cap': [s['cap'] for s in slots]}
    notes.append(f"{l} {rule['alloy']} 칸: " + ', '.join(f"{U.md(s['days'][0])}~{U.md(s['days'][-1])}({U.fmt(s['cap'])}t)" for s in slots) + f" — MAC→AL 복귀 뒤 {rule.get('gap')}일 금지")
    return slots


def slot_due(slots, due, rel=None):
    """AL-STS 지연 기준 = 칸 끝(칸의 원래 끝 날짜): 납기 이전 마지막 칸, 없으면 그 뒤 첫 칸 — 소재 입고(rel) 전에 끝나는 칸은 뺌"""
    ends = sorted({s['to'] for s in slots if not rel or s['to'] >= rel})
    le = [e for e in ends if e <= due]
    return le[-1] if le else (ends[0] if ends else due)


def remap(rem, slots, rule):
    """AL-STS 버킷 납기 → 칸 끝(due0 = 원래 납기). 반환: (새 버킷, {'부서|원래 납기': 칸 끝})"""
    out, ref = [], {}
    for b in rem:
        if slots and b['alloy'] == rule['alloy'] and b['orig'] > 1e-6:
            r = slot_due(slots, b['due'], b.get('rel'))
            k = f"{b['cls']}|{b['due']}"
            ref[k] = max(ref.get(k, r), r)
            if r != b['due']:
                b = dict(b, due=r, due0=b['due'])
        out.append(b)
    return out, ref


def summary(rows, items, t0, rule, slots, ref):
    """게시용: 칸·지연 기준·날짜별 AL-STS 톤과 그중 예약(판매계획 보충 — 주문 아님) 톤"""
    tot, res = {}, {}
    for it in items or []:
        if it['alloy'] != rule['alloy'] or it.get('dest') == '생산 완료':
            continue
        k = (it['cls'], it['due'])
        tot[k] = tot.get(k, 0) + it['tons']
        if it.get('src') != '주문':
            res[k] = res.get(k, 0) + it['tons']
    day = {}
    for d, l, a, c, t, du in rows:
        if a != rule['alloy'] or d <= t0:
            continue
        x = day.setdefault((d, l), [0.0, 0.0])
        x[0] += t
        x[1] += t * (res.get((c, du), 0) / tot[(c, du)] if tot.get((c, du), 0) > 0 else 1)
    return {'line': rule['line'], 'alloy': rule['alloy'], 'slots': [[s['days'][0], s['days'][-1], U.js_round(s['cap'], 1)] for s in slots], 'ref': ref,
            'days': [[d, l, U.js_round(t, 1), U.js_round(r, 1)] for (d, l), (t, r) in sorted(day.items())]}


def contig(rows, cal, slots, rule, t0):
    """11/17 사용자 'AL-STS 이어서, 칸당 3,500t 미만': 칸 안에서 AL-STS 가 든 날을 한 덩어리로 붙임(날 단위 순서만 바꿈 — 하루 내용·톤 그대로).
    AL-STS 덩어리 앞/뒤 중 지연(톤·일)이 적은 쪽. 칸 안 날의 하루 능력(cal cap)이 다르면(정지·M/C 등) 그 칸은 그대로. 반환: (rows, notes)"""
    l, a = rule['line'], rule['alloy']
    cap = {c['date']: round(c.get('cap') or 0) for c in cal if c['line'] == l}
    rows = [list(r) for r in rows]
    notes = []
    for s in slots:
        days = [d for d in s['days'] if d > t0]
        has = {d: any(r[1] == l and r[0] == d and r[2] == a for r in rows) for d in days}
        sd = [d for d in days if has[d]]
        if len(sd) < 2:
            continue
        win = [d for d in days if sd[0] <= d <= sd[-1]]
        if len(win) == len(sd):
            continue
        if len({cap.get(d) for d in win}) > 1:
            notes.append(f"{l} {a} {U.md(win[0])}~{U.md(win[-1])}: 하루 능력이 달라 이어 붙이지 못함")
            continue
        A = [d for d in win if not has[d]]
        best = None
        for order in (sd + A, A + sd):
            mp = dict(zip(order, win))
            late = sum(r[4] * max(0, U.diff_days(mp[r[0]], r[5])) for r in rows if r[1] == l and r[0] in mp)
            if best is None or late < best[0] - 1e-6:
                best = (late, mp)
        mp = best[1]
        for r in rows:
            if r[1] == l and r[0] in mp:
                r[0] = mp[r[0]]
        notes.append(f"{l} {a} 이어 붙임 {U.md(win[0])}~{U.md(win[-1])}")
    return rows, notes


def check(R, rule=None):
    """규칙 점검(재계획 결과): [(ok, 글)] — 2CGL M/C 날짜·횟수, AL-STS 날짜가 칸 안·칸당 ≤ cap·복귀 2일 안 없음"""
    rp = R.get('replan') or {}
    rule = rule or (rp.get('options') or {}).get('macRule')
    if not rule:
        return [(False, '규칙 꺼짐(재계획 옵션 macRule 없음)')]
    P, l, t0 = R['P'], rule['line'], rp.get('t0') or ''
    H = U.horizon(P)
    cal = sorted((c for c in R['cal'] if c['line'] == l), key=lambda c: c['date'])
    sw = []
    for a, b in zip(cal, cal[1:]):
        if b['date'] > t0 and a['fam'] != b['fam']:
            sw.append((b['date'], a['fam'], b['fam']))
    W = windows(rule, H['D1'])
    exp = set()
    for s, e in W:
        exp.add((s, rule['fam']))
        if e <= H['D1']:
            exp.add((e, rule['base']))
    out = []
    late = [x for x in sw if x[0] >= rule['from'] and (x[0], x[2]) not in exp and not (x[2] == rule['base'] and any(c['date'] == x[0] and 'S/D 재가동' in (c.get('event') or '') for c in cal))]
    out.append((not late, f"{l} M/C {U.md(rule['from'])}~ = 규칙 날짜만: " + (', '.join(f'{U.md(d)} {a}→{b}' for d, a, b in sw if d >= rule['from']) or '없음') + (f" / 어긋남 {late}" if late else '')))
    for m in months(rule['from'], H['D1']):
        n = sum(1 for d, a, b in sw if d[:7] == m and b == rule['fam'])
        out.append((n <= 1, f'{m} MAC 시작 {n}회'))
    st = rp.get('sts') or {}
    sl = st.get('slots') or []
    inn = lambda d: any(a <= d <= b for a, b, _ in sl)
    rows = [r for r in R['rows'] if r[1] == l and r[2] == rule['alloy'] and r[0] > t0 and r[0] >= rule['from']]
    outside = sorted({r[0] for r in rows if not inn(r[0])})
    out.append((not outside, f"{rule['alloy']} 칸 밖 생산 " + (', '.join(outside) or '없음')))
    for a, b, cap in sl:
        t = sum(r[4] for r in rows if a <= r[0] <= b)
        out.append((t <= cap + 1, f"칸 {U.md(a)}~{U.md(b)} {U.fmt(t)}t ≤ {U.fmt(cap)}t"))
    rets = [d for d, a, b in sw if a == rule['fam'] and b == rule['base']]
    bad = sorted({r[0] for r in rows for d in rets if 0 <= U.diff_days(r[0], d) < int(rule.get('gap') or 0)})
    out.append((not bad, f"MAC→AL 복귀({', '.join(U.md(d) for d in rets) or '-'}) 뒤 {rule.get('gap')}일 안 {rule['alloy']} " + (', '.join(bad) or '없음')))
    return out
