"""날짜·숫자 공통 함수. 날짜는 'YYYY-MM-DD' 문자열(웹 엔진 engine/util.js 와 동일 규칙)."""
import calendar
import datetime as _dt
import json
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(_HERE, 'defaults.json'), encoding='utf-8') as _f:
    DEFAULTS = json.load(_f)


DAY_START_H = 7                                                   # MES 모든 일수 기준 = 07:00~다음날 07:00(2026-10-22 사용자) — 계획의 '하루'도 같은 생산일


def prod_today():
    """오늘 생산일(한국 시각 − 7시간의 날짜) — 07시 전이면 전날"""
    return (_dt.datetime.utcnow() + _dt.timedelta(hours=9 - DAY_START_H)).date().isoformat()


def default_params():
    return json.loads(json.dumps(DEFAULTS['DEFAULT_PARAMS']))


def ymd(y, m, d):
    return f'{y:04d}-{m:02d}-{d:02d}'


def to_date(s):
    return _dt.date(int(s[:4]), int(s[5:7]), int(s[8:10]))


def add_days(s, n):
    return (to_date(s) + _dt.timedelta(days=n)).isoformat()


def diff_days(a, b):
    """a - b (일)"""
    return (to_date(a) - to_date(b)).days


def days_in_month(y, m):
    return calendar.monthrange(y, m)[1]


def month_end(y, m):
    return ymd(y, m, days_in_month(y, m))


def date_range(a, b):
    out, d = [], a
    while d <= b:
        out.append(d)
        d = add_days(d, 1)
    return out


def md(s):
    return f'{int(s[5:7])}/{int(s[8:10])}'


def fmt(x, k=0):
    return f'{x:,.{k}f}'


def js_round(x, k=0):
    """JS Math.round(x*10^k)/10^k 와 같은 반올림(0.5는 +방향)."""
    import math
    p = 10 ** k
    return math.floor(x * p + 0.5) / p


def horizon(P):
    ms = P['months']
    ym, y = [], P['year']
    for i, m in enumerate(ms):
        if i > 0 and m < ms[i - 1]:
            y += 1
        ym.append((y, m))
    D0 = ymd(ym[0][0], ym[0][1], 1)
    D1 = month_end(ym[-1][0], ym[-1][1])
    return {'ym': ym, 'D0': D0, 'D1': D1, 'days': date_range(D0, D1)}


def is_blackout(P, line, d):
    return any(s['line'] == line and s['start'] <= d <= s['end'] for s in P['shutdowns'])


def restart_days(P, H):
    out = {}
    for s in P['shutdowns']:
        r = add_days(s['end'], 1)
        if H['D0'] < r <= H['D1'] and not is_blackout(P, s['line'], r):
            out[f"{s['line']}|{r}"] = {'line': s['line'], 'day': r, 'sd': s}
    return out


def rate_for(P, line, alloy, cls, b=None):
    # 11/10: 묶음(버킷)에 주문 두께·폭으로 계산한 속도(b['rate'][라인], t/분)가 있으면 그 값 — 없으면 예전처럼 부서 평균(웹 엔진 GP.rateFor 와 같음)
    if b is not None and b.get('rate') and b['rate'].get(line):
        return b['rate'][line]
    k1, k2 = f'{line}|{alloy}|{cls}', f"{line}|{P['alloyFamily'][alloy]}|{cls}"
    if k1 in P['rateDept']:
        return P['rateDept'][k1]
    if k2 in P['rateDept']:
        return P['rateDept'][k2]
    b = P['rateBase'].get(f'{line}|{alloy}')
    if b is None:
        raise ValueError(f'속도 없음: {line} {alloy} {cls}')
    return b


def is_switch(c):
    import re
    return bool(c and c.get('event')) and re.match(r'^(M/C|S/D 재가동)', c['event']) is not None


def is_down(c):
    import re
    return bool(c and c.get('event')) and re.search(r'추가정지|실적 미달', c['event']) is not None
