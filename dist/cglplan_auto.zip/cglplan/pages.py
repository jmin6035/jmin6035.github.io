"""웹 화면용 자료를 매일 다시 계산한다(사내 PC 자동 실행기 5-5단계, 클라우드에서는 tools/pages_build.py).

만드는 것(모두 published/ 버킷에 게시):
  color_actual.enc.json  컬러 실적(진도·일별·주별·품명·휴지)            ← extradata: color_prod·color_brk·snap_salesrpt
  procure.enc.json       조달 판단(수요·업체는 기준 파일, 재고만 매일)   ← pages_base/procure_base.json + snap_mat_stock_cc·snap_stock + 도금 코일
  planstock.enc.json     계획재 분석·예측(R15 ∩ plan_specs)                  ← pages_base/planstock_base.json + color_prod·ship·snap_stock (cglplan/planstock.py)
  color_cond.enc.json    컬러 조건 분석(계획 t/hr vs 최근 4주)               ← pages_base/color_cond_base.json + color_prod (cglplan/color_cond.py)
  portal.enc.json        홈 요약(오늘 볼 것·계획 정확도·지표)           ← 위 둘 + 최신 계획(R2) + pages_base/portal_base.json + 정확도 이력
  status.json            자료 상태(암호 없음, 날짜·건수만)               ← 원천별 마지막 날짜·실행 결과
정의는 tools/color_actual.py·procure_data.py·portal_data.py 와 같다(그 스크립트들도 이 모듈을 쓴다).
기준 파일(pages_base/*.json)은 계획이 바뀔 때 클라우드에서 tools/pages_build.py --base 로 다시 만든다.
"""
import calendar
import datetime as dt
import json
import os
import re
from collections import Counter, defaultdict

from . import salesrpt, util as U, yields as YL

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'pages_base')
CCL = ['1CCL', '2CCL', '3CCL', '4CCL']
CGL = ['1CGL', '2CGL']
STOP_CATS = [('색상교체·청소', ('청소', '색상', '준비')), ('테스트·도막조정', ('TEST', '단판', '도막', '조색')),
             ('폭·롤·두께 전환', ('폭', 'ROLL', '두께', 'DUMMY')), ('기타', ())]
FH_OF = {'AL': 'H', 'AL-LG': 'H', 'AZ': 'F', 'MAC': 'F', 'AL-STS': 'N'}
USABLE = ('사용가능', '작업지시대기', '가공대기', '가공대상')
# 마케팅 그룹(MES 판매그룹 이름 기준). 자가재 = 도금이 만든 컬러 소재(MES 에선 컬러 그룹 이름으로 잡힘)
GROUPS = [('G수출', '도금수출', 'G'), ('G국내', '도금판매(국내)', 'G'), ('G자동차', '자동차강판', 'G'), ('G자가재', '도금 자가재(컬러 소재)', 'G'),
          ('C수출', '컬러수출', 'C'), ('C건재', '컬러건재', 'C'), ('C수요', '수요개발', 'C')]
PLAN_GROUP = {'도금수출': 'G수출', '도금국내': 'G국내', '자동차수출': 'G자동차', '자동차내수': 'G자동차', '자가재': 'G자가재'}        # 계획 부서 → 그룹
SHIP_NAME = {'G국내': '도금판매', 'G수출': '도금수출', 'G자동차': '자동차강판', 'C수출': '컬러수출', 'C건재': '컬러건재'}   # 재고 그룹 → 판매생산속보 출하 줄
COLOR_GROUP = {'가전수출': 'C수출', '가전내수': 'C수출', '건재수출': 'C수출', '계획재': 'C건재', '주문재': 'C건재', '수요개발': 'C수요'}   # cglplan/color_full 분류
COIL_GROUP = {'도금수출그룹': 'G수출', '도금판매그룹': 'G국내', '자동차강판판매그룹': 'G자동차',
              '컬러수출그룹': 'G자가재', '컬러건재판매그룹': 'G자가재', '수요개발그룹': 'G자가재', '컬러공장': 'G자가재'}
CPROD_GROUP = {'컬러수출그룹': 'C수출', '컬러건재판매그룹': 'C건재', '수요개발그룹': 'C수요'}
SHIP_GROUP = {'도금판매': 'G국내', '도금수출': 'G수출', '자동차강판': 'G자동차', '컬러수출': 'C수출', '컬러건재': 'C건재'}
SHIP_DEPT = {'도금판매그룹': 'G국내', '도금수출그룹': 'G수출', '자동차강판판매그룹': 'G자동차', '컬러수출그룹': 'C수출', '컬러건재판매그룹': 'C건재'}   # MES 출하(ship) 부서 → 그룹(tools/integrated_web 과 같음)
BRK_LINE = {'X': '1CCL', 'Y': '2CCL', 'Z': '3CCL', 'W': '4CCL'}
from .leadtime import SAFETY as _LT_SAFETY
SAFETY = dict(_LT_SAFETY)                                    # 입고 → 투입 여유(팀 소재 리드타임 표 2026-10-12: 컬러 +7일 · 도금 = 11/9 회의 최소 1일, 예전 +5일)
POSCO_SUPPLIED = {('G', 'N')}                                # 임가공 AL-STS F/H = 포스코 지급(우리 발주 아님)


def f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def D(s):
    return dt.date.fromisoformat(str(s)[:10])


def week_of(d):
    x = D(d)
    return (x - dt.timedelta(days=x.weekday())).isoformat()


_COLOR_SWAP = None


def stop_cat(t):
    global _COLOR_SWAP
    t = t or ''
    if _COLOR_SWAP is None:
        import re
        _COLOR_SWAP = re.compile(r'(?<![A-Z0-9])(?=[A-Z0-9]*\d)(?=[A-Z0-9]*[A-Z])[A-Z0-9]{5,9}(?![A-Z0-9])(\s*/\s*[A-Z0-9]{4,9})*\s*-+>')   # 'GT1BW10S/VL9N270S -> GS1KS20S' = 도료(색상) 코드 교체
    if _COLOR_SWAP.search(t.upper()) and not any(k in t.upper() for k in ('폭', 'ROLL', '두께', 'DUMMY')):
        return STOP_CATS[0][0]
    for name, keys in STOP_CATS:
        if any(k in t for k in keys):
            return name
    return '기타'


def load_base(name):
    p = os.path.join(BASE, name)
    d = json.load(open(p, encoding='utf-8')) if os.path.exists(p) else None
    if d and name == 'planstock_base.json' and d.get('specs'):  # 11/3 사용자: 계획재 = 수입 F/H·서림 GI 사양만(data/plan_specs) — P-FH·P-GI 사양은 주문재
        try:
            from .plan_specs import is_plan
            d = dict(d, specs=[s for s in d['specs'] if is_plan(s['thk'], s['wdt'], s['color'])])
        except (OSError, KeyError, ValueError) as e:                 # 11/5: 사내 PC 설치 묶음에 data/plan_specs 가 없어 화면 자료 전체가 멈췄음 → 사양 거르기만 건너뜀
            print(f'계획재 사양 목록 없음 — 거르기 생략: {e}')
    return d


def _rows(T, name):
    t = T.get(name)
    return [dict(zip(t['columns'], r)) for r in t['rows']] if t else []


def sr_summary(T, coils=None, ship=False):
    """판매생산속보 요약 + 생산 실적은 MES(11/9 회의 F7: 생산 실적 = MES 코일 — 속보는 다음 날 등급·부적합 조정으로 끼워 맞춘 값).
    11/10 점검: 같은 11월 실적이 화면마다 속보 14,993 / MES 14,975 두 값 → 속보 생산 줄 actual 을 MES(속보와 같은 기간 = 속보일 전날까지)로 바꾸고 속보 값은 srActual"""
    if not T.get('snap_salesrpt'):
        return None
    S = salesrpt.summary(T['snap_salesrpt'])
    try:
        rep = (D(S['asOf']) - dt.timedelta(days=1)).isoformat()
    except (TypeError, ValueError):
        return S
    m, tot, seen = rep[:7], defaultdict(float), set()
    for c in coils or []:
        d = str(c['day'])
        if not c.get('dummy') and d[:7] == m and d <= rep:
            tot[c['line']] += f(c['t']); seen.add('G')
    cp = T.get('color_prod')
    if cp and cp.get('rows') and 'LINE' in cp['columns']:
        I = cp['columns'].index
        for r in cp['rows']:
            d = str(r[I('PRD_DT')])[:10]
            if d[:7] == m and d <= rep:
                tot[r[I('LINE')]] += f(r[I('PDT_WGT')]) / 1000; seen.add('C')
    for x in S.get('prod', []):
        pl = 'G' if x['plant'] == '도금' else 'C'
        if pl in seen:
            v = sum(tot[l] for l in (CGL if pl == 'G' else CCL)) if x['line'].endswith(' 계') else tot[x['line']]
            x['srActual'], x['actual'], x['src'] = x['actual'], round(v, 1), 'MES'
    if ship and T.get('ship'):                                 # 출하 실적 = MES 영업매출 1300(F8) — 주간 보고용. 합계 = 5개 그룹 합(속보 합계엔 다른 항목이 섞여 표 합과 달랐음)
        sm = defaultdict(float)
        for r in _rows(T, 'ship'):
            g, d = SHIP_DEPT.get(r.get('DEPT')), str(r.get('OUT_DT') or '')[:10]
            if g and str(r.get('OUT_RSN_CD')) == '1300' and d[:7] == m and d <= rep:
                sm[g] += f(r.get('WGT')) / 1000
        G5 = [x for x in S.get('ship', []) if x['name'] in SHIP_GROUP]
        for x in G5:
            x['srActual'], x['actual'] = x['actual'], round(sm.get(SHIP_GROUP[x['name']], 0.0), 1)
        for x in S.get('ship', []):
            if x['name'] == '합계' and G5:
                x.update({k: round(sum(y[k] for y in G5), 1) for k in ('month', 'sched', 'actual')})
    return S


SHIP_ARR = (('snap_cg_ship_arr', 'snap_cg_ord_full', 'G'), ('snap_cc_ship_arr', 'snap_cc_ord_full', 'C'))   # 배선지시(계약·행 → 배 출항일) · 주문량


def _kday(v):
    """epoch ms(KST)·'YYYY-MM-DD…'·'YYYYMMDD' → 'YYYY-MM-DD'"""
    if v in (None, ''):
        return None
    if isinstance(v, (int, float)) and v > 1e11:
        return (dt.datetime.fromtimestamp(v / 1000, dt.timezone.utc) + dt.timedelta(hours=9)).date().isoformat()
    s = str(v).replace('-', '')[:8]
    return f'{s[:4]}-{s[4:6]}-{s[6:8]}' if s.isdigit() and len(s) == 8 else None


def ship_pattern(T, cur):
    """그룹별 월중 출하 패턴(11/10 사용자 '매일 똑같이 나간다고 가정하지 말고 1년치 패턴으로 — 모든 그룹 같은 기준'):
    판매 출고(1300) 실적으로 달마다 '그 달 날짜 비율(날/그 달 날수) → 누계 출하 비율' 곡선을 만들고 완결 월(cur 전) 평균.
    자료 = ship 표(2026-07~) + hist_ship_daily(2025-11~2026-06 일 × 부서 합계). 반환 {그룹: [(달 수, [0..1 구간 21점 누계 비율])]}"""
    day = defaultdict(lambda: defaultdict(float))
    for r in _rows(T, 'ship'):
        g, d = SHIP_DEPT.get(r.get('DEPT')), str(r.get('OUT_DT') or '')[:10]
        if g and str(r.get('OUT_RSN_CD')) == '1300' and len(d) == 10:
            day[(g, d[:7])][int(d[8:10])] += f(r.get('WGT')) / 1000
    have = set(day)
    for r in _rows(T, 'hist_ship_daily'):
        g, d = SHIP_DEPT.get(r.get('DEPT')), str(r.get('OUT_DT') or '')
        d = f"{d[:4]}-{d[4:6]}-{d[6:8]}" if len(d) == 8 else d[:10]
        if g and len(d) == 10 and (g, d[:7]) not in have:
            day[(g, d[:7])][int(d[8:10])] += f(r.get('WGT')) / 1000
    pts = [i / 20 for i in range(21)]
    acc = defaultdict(list)
    for (g, m), dd in day.items():
        if m >= cur:
            continue
        n, tot = calendar.monthrange(int(m[:4]), int(m[5:7]))[1], sum(dd.values())
        if tot <= 0 or len(dd) < 10:                                   # 그 달 자료가 일부만 있으면(조회 시작 달) 빼기
            continue
        cum, c = [0.0], 0.0
        for k in range(1, n + 1):
            c += dd.get(k, 0.0)
            cum.append(c / tot)
        acc[g].append([cum[min(n, int(p * n))] + (cum[min(n, int(p * n) + 1)] - cum[min(n, int(p * n))]) * (p * n - int(p * n)) for p in pts])
    return {g: (len(v), [sum(x) / len(v) for x in zip(*v)]) for g, v in acc.items()}


def ship_due(T, rep, ship):
    """출하 진도 기준선 = 그날까지 나갔어야 할 누계 = 월 계획 × 그룹 월중 출하 패턴(ship_pattern) 의 그날 누계 비율 — 모든 그룹 같은 기준(11/10 사용자).
    예전: 경과일 비례(매일 같은 양 가정) → 월말에 몰리는 그룹(도금국내·컬러건재)은 월초 늘 미달로 보였음. 패턴 자료가 없는 그룹만 경과일 비례.
    ship[g] 에 due(t) · dueBy('패턴 n개월'·'경과일') 추가"""
    if not rep:
        return
    m, nd = rep[:7], calendar.monthrange(int(rep[:4]), int(rep[5:7]))[1]
    fr = int(rep[8:10]) / nd
    PT = ship_pattern(T, m)
    for g, x in ship.items():
        mon = f(x.get('month'))
        pt = PT.get(g)
        if pt and pt[0] >= 2:
            c = pt[1]
            k = min(19, int(fr * 20))
            share = c[k] + (c[k + 1] - c[k]) * (fr * 20 - k)
            x['due'], x['dueBy'] = round(mon * share), f'출하 실적 패턴 {pt[0]}개월'
        else:
            x['due'], x['dueBy'] = round(mon * fr), '경과일'
        if x.get('sched') is not None and 'schedSR' not in x:     # 11/10 사용자 '단순 출하 기준으로': 모든 화면의 출하 '일정 누계'(sched)를 출하 예정 누계로 — 홈·관제·실적 화면이 따로 속보 일정을 쓰지 않게(속보 값은 schedSR)
            x['schedSR'] = x['sched']
        x['sched'] = x['due']


_CODES = None


def product_name(code):
    global _CODES
    if _CODES is None:
        _CODES = (load_base('color_product_codes.json') or {}).get('codes', {})
    s = str((_CODES.get(code) or {}).get('name', code) or '').strip()
    import re
    s = re.sub(r'\(MAC\.?\)', '', s, flags=re.I)
    s = re.sub(r'\((가전|후물|프)\)', '', s)
    return s.split('_')[0].strip()


# ------------------------------------------------------------------ 컬러 실적
def show_days(d_first, d_last):
    """일별 그래프 기간: 이번 달 1일부터(7일 미만 지났으면 지난달 1일부터), 자료 시작일 이전은 빼고 — 자료 없는 날을 0으로 그리지 않게"""
    a = d_last.replace(day=1)
    if d_last.day < 7:
        a = (a - dt.timedelta(days=1)).replace(day=1)
    a = max(a, d_first)
    return [(a + dt.timedelta(days=i)).isoformat() for i in range((d_last - a).days + 1)]


def full_months(months, d_first):
    """월별 표: 자료가 1일부터 있는 달만(첫 달이 중간부터면 뺌 — '9월(28일~)' 같은 잘린 달 제외). 다 빠지면 그대로"""
    out = [m for m in months if not (m == d_first.isoformat()[:7] and d_first.day > 1)]
    return out or months


CG_PLAN = ('계획재', '주문재', '건재수출', '가전수출', '가전내수', '수요개발')           # 컬러 계획 그룹(통합 계획 color 행의 g 키)


def con_export(cn, dom=None):
    """계약이 수출인지 — MES 주문 머리 DOM_CLS(E 수출 / D 내수)가 있으면 그것, 없으면 계약번호의 수주형태 글자
    (P… 계약 5번째·C… 계약 2번째 자리, K = 종합상사수출 K0). 2026-10-20 검증: 컬러 계약 5,235건에서 두 기준 예외 없이 일치.
    (10/13 'PG…K = 내수' 예외는 재고현황 수주(임)를 믿은 오류 — PG…K 는 DOM_CLS E·K0, 도착지 GEMLIK·LAZARO CARDENAS 등 실제 수출)"""
    if dom in ('E', 'D'):
        return dom == 'E'
    cn = str(cn or '')
    if len(cn) < 5:
        return False
    return (cn[4] if cn[0] == 'P' else cn[1]) == 'K'


def con_dom_map(T):
    """계약번호 → DOM_CLS (hist_cc_con_dept_a/b · snap_raw_ask_dept)"""
    m = {}
    for n in ('hist_cc_con_dept_a', 'hist_cc_con_dept_b', 'snap_raw_ask_dept'):
        for r in _rows(T, n):
            if r.get('DOM_CLS') in ('E', 'D'):
                m[str(r['CON_NO'])] = r['DOM_CLS']
    return m


def color_grouper(T):
    """MES 컬러 생산 코일 → 계획 그룹(통합 계획과 같은 6개, tools/integrated_plan.py 도 이 함수를 씀)
    · 컬러건재판매그룹 → 계획재 사양(data/plan_specs 90 사양, 두께 ±0.03·폭·상도색상)이면 계획재, 아니면 주문재(건재 주문재)
    · 수요개발그룹 → 수요개발
    · 컬러수출그룹: 주문 용도 CC*(건재) → 건재수출, 그 밖(CE* 가전) → 계약이 수출이면 가전수출, 내수면 가전내수(con_export)
      판매계획 그룹과 같은 뜻: 가전내수 = 엘지(창원·저가내수·저가수출)·삼성 등 내수 계약, 가전수출 = 멕시코·인도·터키 등 수출 계약"""
    dom = con_dom_map(T)
    try:                                                       # 11/9 사용자: 계획재 판정 = data/plan_specs(90 사양) 한 곳 — R15 사양 목록(88개만 겹침) 대신
        from .plan_specs import is_plan
        is_plan(0, 0, '')
    except (OSError, KeyError, ValueError):                    # 사내 PC 설치 묶음에 data/plan_specs 가 없을 때만 예전 방식(planstock_base 거른 사양)
        from . import planstock as PSm
        base = load_base('planstock_base.json') or {}
        _m = PSm._M(base['specs']) if base.get('specs') else None
        is_plan = (lambda t, w, c: _m is not None and _m(t, w, c) is not None)

    def g(x):
        dept = str(x.get('DEPT') or '')
        if dept.startswith('컬러건재'):
            return '계획재' if is_plan(f(x['REAL_MSR_THK']), f(x['PDT_WDT']), x['SUR_FINISH_CD']) else '주문재'
        if dept.startswith('수요'):
            return '수요개발'
        if str(x.get('ORD_USG_CD') or '').startswith('CC'):
            return '건재수출'
        cn = str(x.get('CON_NO') or '')
        return '가전수출' if con_export(cn, dom.get(cn)) else '가전내수'
    return g


def color_group_daily(T):
    """컬러 가동현황용 일·라인별 실적: {d: {line: [{그룹: t}, 작업+정지 분]}} — 매일 사내 PC 가 다시 계산(계획 그룹으로 분류)"""
    rows = _rows(T, 'color_prod')
    if not rows:
        return None
    grp = color_grouper(T)
    out = defaultdict(lambda: defaultdict(lambda: [defaultdict(float), 0.0, defaultdict(float)]))
    for r in rows:
        x = out[str(r['PRD_DT'])[:10]][r['LINE']]
        t = f(r['PDT_WGT']) / 1000
        x[0][grp(r)] += t
        x[1] += f(r['WRK_TIME']) + f(r['PAU_TIME'])
        x[2][product_name(r['PDT_NM'])] += t
    top = lambda p: [[k, round(v, 1)] for k, v in sorted(p.items(), key=lambda kv: -kv[1])[:5]]
    return {'asOf': max(out), 'days': {d: {l: [{g: round(t, 1) for g, t in v[0].items()}, round(min(1440.0, v[1])), top(v[2])] for l, v in L.items()} for d, L in sorted(out.items())}}


DOWN_KIND = {'색상교체·청소': 'color', '테스트·도막조정': 'test', '폭·롤·두께 전환': 'roll', '기타': 'etc'}


PROD_DAY_START = 420                                            # MES 모든 일수 기준 = 07:00(10/22 사용자) — 07:00~다음날 07:00 이 하루


def color_down_actual(T, d0='2026-10-01'):
    """컬러 지난 날 실제 휴지(분): {d: {line: [[종류, 분], ...]}} — 그날 07시~다음날 07시를 1분 칸으로 나눠 코일 작업 > 휴지 기록 순으로 채우고,
    둘 다 없는 시간 = 'gap'(기록 없는 정지 — TEST 운전·라인 정지처럼 MES 휴지 기록에 안 남는 시간).
    2026-10-21 사용자: 4CCL 10/14 화면은 계획 Test 8h 였는데 실제 TEST 11.8h — 휴지 기록엔 4.8h 뿐이고 10:17~22:25 는 0t·시험 코일만 있어 기록 없는 정지로 잡아야 맞음"""
    prod, brk = _rows(T, 'color_prod'), _rows(T, 'color_brk')
    if not prod:
        return None
    ms = lambda v: f(v) / 1000 + 9 * 3600 if f(v) > 1e11 else None          # 한국 시각 초
    last = max(str(r['PRD_DT'])[:10] for r in prod)
    days = []
    x = D(d0)
    while x <= D(last):
        days.append(x.isoformat()); x += dt.timedelta(days=1)
    if not days:
        return None
    base = (dt.datetime.fromisoformat(days[0]) - dt.datetime(1970, 1, 1)).total_seconds() + PROD_DAY_START * 60   # 하루 = 07:00~다음날 07:00(MES 일수 기준, 10/22 사용자)
    n = len(days) * 1440
    slot = {l: [None] * n for l in CCL}

    def paint(l, s, e, k, over):
        if s is None or e is None or e <= s:
            return
        a, b = max(0, int((s - base) // 60)), min(n, int((e - base) // 60 + 0.999))
        sl = slot[l]
        for i in range(a, b):
            if over or sl[i] is None:
                sl[i] = k
    for r in prod:
        if r.get('LINE') in slot:
            paint(r['LINE'], ms(r.get('WRK_STA_TM')), ms(r.get('WRK_END_TM')), 'run', True)
    seen = set()
    for r in brk:
        l = BRK_LINE.get(str(r.get('LINE_CLS') or '')[:1])
        key = (l, r.get('PAU_STA_TM'))
        if not l or key in seen:
            continue
        seen.add(key)
        paint(l, ms(r.get('PAU_STA_TM')), ms(r.get('PAU_END_TM')), DOWN_KIND.get(stop_cat(r.get('SPL_REM')), 'etc'), False)
    out = {}
    for di, d in enumerate(days):
        for l in CCL:
            c = Counter(slot[l][di * 1440:(di + 1) * 1440])
            c.pop('run', None)
            c['gap'] = c.pop(None, 0)
            v = [[k, m] for k, m in sorted(c.items(), key=lambda kv: -kv[1]) if m > 0]
            if v:
                out.setdefault(d, {})[l] = v
    return {'asOf': last, 'days': out}


def color_actual(T):
    rows = _rows(T, 'color_prod')
    if not rows:
        return None
    last = max(r['PRD_DT'] for r in rows)
    d_last = D(last)
    d_first = D(min(r['PRD_DT'] for r in rows))
    full = lambda w: D(w) >= d_first and D(w) + dt.timedelta(days=6) <= d_last      # 자료 첫 주·마지막 주가 잘린 주는 추이에서 뺌
    weeks = sorted({week_of(r['PRD_DT']) for r in rows if full(week_of(r['PRD_DT']))}) or [week_of(last)]   # 자료가 1주 미만이어도 동작
    w1 = weeks[-1]
    cut4 = weeks[-4] if len(weeks) >= 4 else weeks[0]                       # 품목별 = 최근 4주(자료가 짧으면 있는 만큼)
    w0s = weeks[-13:-1] or weeks[-1:]
    day = defaultdict(float)
    wk = defaultdict(lambda: [0.0, 0.0, set(), 0.0, 0.0])
    mon = defaultdict(float)
    dept = defaultdict(float)
    prod = defaultdict(lambda: [0.0, 0.0, 0.0])
    for r in rows:
        d, l = r['PRD_DT'], r['LINE']
        t = f(r['PDT_WGT']) / 1000
        h = (f(r['WRK_TIME']) + f(r['PAU_TIME'])) / 60
        day[(d, l)] += t
        x = wk[(week_of(d), l)]
        x[0] += t; x[1] += h; x[2].add(d); x[3] += f(r['PAU_TIME']) / 60; x[4] += t * f(r['REAL_MSR_THK'])
        mon[(d[:7], l)] += t
        dept[(d[:7], str(r['DEPT'] or '기타'))] += t
        if d >= cut4:
            p = prod[(l, product_name(r['PDT_NM']))]
            p[0] += t; p[1] += h; p[2] += t * f(r['REAL_MSR_THK'])
    stop = defaultdict(float)
    for r in _rows(T, 'color_brk'):
        d = str(r['WRK_DT'])
        d = f'{d[:4]}-{d[4:6]}-{d[6:]}'
        l = BRK_LINE.get(str(r.get('LINE_CLS') or '')[:1], str(r.get('LINE_CLS')))
        stop[(week_of(d), l, stop_cat(r.get('SPL_REM')))] += f(r['PAU_TIME']) / 60

    def agg(l, ws):
        t = sum(wk[(w, l)][0] for w in ws); h = sum(wk[(w, l)][1] for w in ws); n = sum(len(wk[(w, l)][2]) for w in ws)
        s = sum(wk[(w, l)][3] for w in ws); th = sum(wk[(w, l)][4] for w in ws)
        return {'tpd': t / (7 * len(ws)), 'tph': t / h if h else None, 'days': n / len(ws), 'stopH': s / max(n, 1), 'thick': th / t if t else None}
    SR = sr_summary(T)
    months = sorted({m for (m, _) in mon})
    dsum = Counter()
    for k, v in dept.items():
        dsum[k[1]] += v
    names = [k for k, _ in dsum.most_common()]
    days35 = show_days(d_first, d_last)
    months = full_months(months, d_first)
    return {'built': dt.datetime.now(dt.timezone(dt.timedelta(hours=9))).replace(tzinfo=None).isoformat(timespec='minutes'), 'asOf': last, 'from': min(r['PRD_DT'] for r in rows), 'w1': w1, 'w0': [w0s[0], w0s[-1]], 'nW0': len(w0s), 'plant': 'C', 'byGroup': color_group_daily(T), 'downAct': color_down_actual(T),
            'lines': [{'line': l, 'w0': agg(l, w0s), 'w1': agg(l, [w1])} for l in CCL],
            'month': {'asOf': SR['asOf'] if SR else None, 'rows': [x for x in (SR['prod'] if SR else []) if x['plant'] == '컬러']},
            'daily': [{'d': d, **{l: round(day[(d, l)], 1) for l in CCL}} for d in days35],
            'weekly': [{'w': w, **{l: {'tpd': round(wk[(w, l)][0] / 7, 2), 'tph': round(wk[(w, l)][0] / wk[(w, l)][1], 2) if wk[(w, l)][1] else None} for l in CCL}} for w in weeks],
            'monthly': [{'m': m, **{l: round(mon[(m, l)]) for l in CCL}} for m in months],
            'dept': {'names': names, 'rows': [{'m': m, **{k: round(dept[(m, k)]) for k in names}} for m in months]},
            'products': {l: [[p, round(v[0]), round(v[0] / v[1], 1) if v[1] else None, round(v[2] / v[0], 3) if v[0] else None]
                             for (ll, p), v in sorted(prod.items(), key=lambda kv: -kv[1][0]) if ll == l][:10] for l in CCL},
            'stops': {'cats': [c for c, _ in STOP_CATS],
                      'w1': {l: {c: round(stop[(w1, l, c)] / 7, 2) for c, _ in STOP_CATS} for l in CCL},
                      'w0': {l: {c: round(sum(stop[(w, l, c)] for w in w0s) / (7 * len(w0s)), 2) for c, _ in STOP_CATS} for l in CCL},
                      'trend': [{'w': w, **{c: round(sum(stop[(w, l, c)] for l in CCL) / 7, 2) for c, _ in STOP_CATS}} for w in weeks]}}


# ------------------------------------------------------------------ 도금 실적 (컬러 실적과 같은 구성·같은 정의)
G_STOP_CATS = ['강종 전환(M/C)', '정기수리', '설비·운전', '기타']


def g_stop_cat(nm, dtl):
    nm, dtl = str(nm or ''), str(dtl or '')
    if 'mode change' in nm.lower() or 'MODE CHANGE' in dtl.upper():
        return G_STOP_CATS[0]
    if '정기수리' in nm or '정기수리' in dtl:
        return G_STOP_CATS[1]
    if any(k in dtl for k in ('기계', '전기', '운전')):
        return G_STOP_CATS[2]
    return G_STOP_CATS[3]


def plating_actual(T, coils, stops=None):
    """도금 1·2CGL 실적 — color_actual 과 같은 키(lines·month·daily·weekly·monthly·dept·products·stops) + mc(강종 전환 실적).
    톤 = 더미 제외 코일(판매생산속보·재계획과 같은 기준), 속도 = 생산 t ÷ 작업시간(정지 포함 = 달력 시간), 컬러 실적과 같은 정의"""
    C = [c for c in (coils or []) if not c.get('dummy')]
    if not C:
        return None
    last = max(str(c['day']) for c in C)
    d_last = D(last)
    d_first = D(min(str(c['day']) for c in C))
    full = lambda w: D(w) >= d_first and D(w) + dt.timedelta(days=6) <= d_last
    weeks = sorted({week_of(c['day']) for c in C if full(week_of(c['day']))}) or [week_of(last)]
    w1 = weeks[-1]
    cut4 = weeks[-4] if len(weeks) >= 4 else weeks[0]
    w0s = weeks[-13:-1] or weeks[-1:]
    day, mon, dept = defaultdict(float), defaultdict(float), defaultdict(float)
    wk = defaultdict(lambda: [0.0, 0.0, set(), 0.0, 0.0])
    prod = defaultdict(lambda: [0.0, 0.0, 0.0])
    for c in coils:                                              # 시간은 더미 코일 포함(M/C 정지가 더미에 붙음), 톤은 더미 제외
        d, l, t = str(c['day']), c['line'], (0.0 if c.get('dummy') else f(c['t']))
        h = f(c.get('work')) / 60
        day[(d, l)] += t
        x = wk[(week_of(d), l)]
        x[0] += t; x[1] += h; x[2].add(d); x[3] += f(c.get('stop')) / 60; x[4] += t * f(c.get('thick'))
        mon[(d[:7], l)] += t
        dept[(d[:7], str(c.get('dept') or '기타'))] += t
        if d >= cut4:
            p = prod[(l, f"{c.get('pname') or '-'} · {c.get('alloy') or c.get('fam') or '-'}")]
            p[0] += t; p[1] += h; p[2] += t * f(c.get('thick'))
    prd_day = {c.get('prd'): str(c['day']) for c in coils or []}
    run = defaultdict(float)                                     # 일·라인 가동 분(더미 제외 코일 run) — 화면 가동시간, 생산일 경계에 걸친 코일로 넘치는 날은 1,440분
    for c in C:
        run[(str(c['day']), c['line'])] += f(c.get('run'))
    drun = defaultdict(float)                                    # 더미 코일 가동 분(M/C·전환 때 통판) — 24시간 구성(10/22 사용자: 24시간 안 되는 날 이유)
    for c in coils or []:
        if c.get('dummy'):
            drun[(str(c['day']), c['line'])] += f(c.get('run'))
    stop = defaultdict(float)
    dstop = defaultdict(float)                                   # 일·라인·종류·사유 휴지 분
    mc = defaultdict(lambda: {'h': 0.0, 'nm': ''})
    for x in stops or []:
        d = prd_day.get(x.get('prd')) or (dt.datetime(1970, 1, 1) + dt.timedelta(minutes=f(x.get('s')) - PROD_DAY_START)).date().isoformat()   # 생산번호 없는 휴지 = 07시 기준 날짜
        cat = g_stop_cat(x.get('nm'), x.get('dtl'))
        stop[(week_of(d), x['line'], cat)] += f(x.get('t')) / 60
        if d >= '2026-10-01':
            dstop[(d, x['line'], cat, str(x.get('nm') or x.get('dtl') or '사유 없음').strip())] += f(x.get('t'))
        if cat == G_STOP_CATS[0]:
            m = mc[(d, x['line'])]
            m['h'] += f(x.get('t')) / 60
            m['nm'] = m['nm'] or str(x.get('nm') or '')

    def agg(l, ws):
        t = sum(wk[(w, l)][0] for w in ws); h = sum(wk[(w, l)][1] for w in ws); n = sum(len(wk[(w, l)][2]) for w in ws)
        s_ = sum(wk[(w, l)][3] for w in ws); th = sum(wk[(w, l)][4] for w in ws)
        return {'tpd': t / (7 * len(ws)), 'tph': t / h if h else None, 'days': n / len(ws), 'stopH': s_ / max(n, 1), 'thick': th / t if t else None}
    SR = sr_summary(T, coils)
    months = sorted({m for (m, _) in mon})
    dsum = Counter()
    for k, v in dept.items():
        dsum[k[1]] += v
    names = [k for k, _ in dsum.most_common()]
    days35 = show_days(d_first, d_last)
    months = full_months(months, d_first)
    import re
    mcl = []
    for (d, l), m in sorted(mc.items()):
        g = re.search(r'\(\s*(\w+)\s*-?>\s*(\w+)\s*\)', m['nm'])
        fr, to = (g.group(1), g.group(2)) if g else ('', '')
        fam = {'GI': 'MAC'}
        mcl.append({'d': d, 'line': l, 'from': fam.get(fr, fr), 'to': fam.get(to, to), 'h': round(m['h'], 1), 'sd': '정기수리' in m['nm']})
    return {'built': dt.datetime.now(dt.timezone(dt.timedelta(hours=9))).replace(tzinfo=None).isoformat(timespec='minutes'), 'asOf': last, 'from': min(str(c['day']) for c in C), 'w1': w1, 'w0': [w0s[0], w0s[-1]], 'nW0': len(w0s), 'plant': 'G',
            'lines': [{'line': l, 'w0': agg(l, w0s), 'w1': agg(l, [w1])} for l in CGL],
            'month': {'asOf': SR['asOf'] if SR else None, 'rows': [x for x in (SR['prod'] if SR else []) if x['plant'] == '도금']},
            'daily': [{'d': d, **{l: round(day[(d, l)], 1) for l in CGL}} for d in days35],
            'weekly': [{'w': w, **{l: {'tpd': round(wk[(w, l)][0] / 7, 2), 'tph': round(wk[(w, l)][0] / wk[(w, l)][1], 2) if wk[(w, l)][1] else None} for l in CGL}} for w in weeks],
            'dayMin': {d: {l: round(min(1440.0, run[(d, l)])) for l in CGL if run[(d, l)] > 0} for d in sorted({k[0] for k in run}) if d >= '2026-10-01'},
            'dayDummy': {d: {l: round(drun[(d, l)]) for l in CGL if drun[(d, l)] > 0} for d in sorted({k[0] for k in drun}) if d >= '2026-10-01'},
            'dayStops': {d: {l: [[c, round(m), nm] for (d2, l2, c, nm), m in sorted(dstop.items(), key=lambda kv: -kv[1]) if d2 == d and l2 == l and m >= 1] for l in CGL}
                         for d in sorted({k[0] for k in dstop})},
            'monthly': [{'m': m, **{l: round(mon[(m, l)]) for l in CGL}} for m in months],
            'dept': {'names': names, 'rows': [{'m': m, **{k: round(dept[(m, k)]) for k in names}} for m in months]},
            'products': {l: [[p, round(v[0]), round(v[0] / v[1], 1) if v[1] else None, round(v[2] / v[0], 3) if v[0] else None]
                             for (ll, p), v in sorted(prod.items(), key=lambda kv: -kv[1][0]) if ll == l][:10] for l in CGL},
            'stops': {'cats': G_STOP_CATS,
                      'w1': {l: {c: round(stop[(w1, l, c)] / 7, 2) for c in G_STOP_CATS} for l in CGL},
                      'w0': {l: {c: round(sum(stop[(w, l, c)] for w in w0s) / (7 * len(w0s)), 2) for c in G_STOP_CATS} for l in CGL},
                      'trend': [{'w': w, **{c: round(sum(stop[(w, l, c)] for l in CGL) / 7, 2) for c in G_STOP_CATS}} for w in weeks]},
            'mc': mcl[-12:]}


# ------------------------------------------------------------------ 조달 판단: 재고
def procure_stock(T, coils, today):
    """컬러 = 소재재고List 재고중량(사용 가능 구분, 자가 제외) · 도금 FH = 최근 월말 재고현황 − 그 뒤 도금 실적 사용량(실수율 반영)"""
    st = defaultdict(float)
    for r in _rows(T, 'snap_mat_stock_cc'):
        b = str(r.get('구매처') or '')
        if ':' not in b or b.startswith('A1') or r.get('재고구분') not in USABLE:
            continue
        w = f(r.get('재고중량')) / 1000
        if w > 0:
            st[('C', str(r.get('Zn') or '')[:1])] += w
    S = _rows(T, 'snap_stock')
    months = sorted({str(r['_기준월']) for r in S if r.get('공장구분') == 'G'})
    m_last = months[-1] if months else None
    if m_last:
        for r in S:
            if r['구분명'] == 'R' and r['공장구분'] == 'G' and str(r['_기준월']) == m_last and str(r.get('소재공급업체') or '') != 'A1':
                if not (f(r.get('재고일수')) > 180 or str(r.get('제품등급')).strip() == '5'):
                    st[('G', str(r['품명코드']))] += f(r['중량']) / 1000
        y, m = int(m_last[:4]), int(m_last[4:])
        after = dt.date(y + (m == 12), m % 12 + 1, 1).isoformat()
        for c in coils or []:
            if after <= str(c['day']) < today:
                a = c.get('alloy') or c.get('fam')
                st[('G', FH_OF.get(a, 'F'))] -= f(c['t']) / (YL.plating(c['line'], a, c.get('cls')) / 100)
        E = [r for r in _rows(T, 'snap_raw_ent') if r.get('PLT_CLS') == 'G' and str(r.get('RAW_SUP_CPY') or '') != 'A1']
        e0 = min((str(r['ENT_DT']) for r in E if r.get('ENT_DT')), default='99999999')
        got = e0 <= after.replace('-', '')                          # 입고 원장이 월말 다음 날부터 있을 때만(빠진 날이 없게)
        if got:
            for r in E:
                d = str(r.get('REAL_ENT_DT') or r.get('ENT_DT') or '')
                if after.replace('-', '') <= d < today.replace('-', ''):
                    st[('G', str(r.get('RAW_GRP') or 'F'))] += f(r.get('RAW_ENT_WGT')) / 1000
    note = (f"컬러 = 소재재고List(CC) 재고중량 · 도금 FH = {m_last[:4]}.{m_last[4:]}월말 재고 + 이후 MES 입고 − 이후 도금 실적 사용" if m_last and got
            else f"컬러 = 소재재고List(CC) 재고중량 · 도금 FH = {m_last[:4]}.{m_last[4:]}월말 재고 − 이후 도금 실적 사용(입고는 자료 없음)" if m_last else '재고 자료 없음')
    return {f'{k[0]}:{k[1]}': round(max(0.0, v), 1) for k, v in st.items()}, note


def sup_names(T):
    """소재 공급사 코드 → 이름: 누적 기록(pages_base/supplier_names.json) + 오늘 소재재고List 구매처('코드: 이름') + MES 공급사 표(SMKT.CR_SUP, 있으면)"""
    names = dict((load_base('supplier_names.json') or {}).get('names', {}))
    for r in _rows(T, 'snap_mat_stock_cc'):
        b = str(r.get('구매처') or '')
        if ':' in b:
            c, n = (x.strip() for x in b.split(':', 1))
            if c and n:
                names.setdefault(c, n)                                   # 누적 기록에서 고친 이름(C2 등) 유지
    # MES 공급사 표: 업체 구분코드(SUP_CPY_CLS, 15자리) 앞 2자리 = 발주번호 앞 2자리(원료업체만 — 선사·운송 등도 앞자리가 겹침).
    # 소재재고List 구매처와 겹치는 15개 코드가 모두 같은 업체로 확인됨(C2 동부제철 = 현 케이지스틸). 같은 앞자리가 둘이면 끝자리 1(현행) 우선, X(구) 는 뒤
    best = {}
    for r in _rows(T, 'snap_sup_name') + _rows(T, 'snap_sup_name2'):
        c, n = str(r.get('SUP_CPY_CLS') or ''), str(r.get('CPY_NM_KOR_LANG') or r.get('CPY_NM_ENG') or '').strip()
        if r.get('SUP_CPY_CLS_NM') != '원료업체' or not n or not re.fullmatch(r'[0-9A-Z]{2}[0-9X]{13}', c):
            continue
        rank = 0 if c.endswith('1') else 2 if 'X' in c else 1
        if c[:2] not in best or rank < best[c[:2]][0]:
            best[c[:2]] = (rank, n)
    for c, (_, n) in best.items():                                # 이미 아는 코드는 짧은 이름 유지(표 이름은 법인 정식명)
        names.setdefault(c, re.sub(r'\s*(주식회사|유한회사|\(주\))\s*', '', n) or n)
    for r in _rows(T, 'snap_code_detail') + _rows(T, 'snap_code_detail1') + _rows(T, 'snap_code_detail2') + _rows(T, 'snap_code_detail3'):
        if r.get('MASTER_CD') == 'RAW_MFG_CPY_CD' and r.get('CD_VAL') and r.get('CD_NM'):   # MES 코드조회-소재제조업체(SCOMB0030 과 같은 표) — 새 업체도 자동
            names.setdefault(str(r['CD_VAL']), str(r['CD_NM']).strip())
    for r in _rows(T, 'snap_raw_ask'):                               # V 계열 = 해외 업체(V0 DB Inc.·V1 천진TROSCO·V2 REN ZE) — 표에 없는 V3·V4 는 이름 확인 전까지 이렇게 표시
        c = str(r.get('RAW_SUP_CPY') or '')
        if c[:1] == 'V' and c not in names:
            names[c] = f'수입({c}, 업체명 확인 중)'
    return names


def color_supply(T, today):
    """컬러 구매 소재 공급(코드별 날짜별 t): 소재재고List(사용 가능, 자가 제외) = 오늘, MES 미입고 발주 = 입고 예정일.
    톤만 담음(단가 없음) — 웹 컬러 계획 계산(몰기 소재 입고 제약)용으로 color_calc_mes 에 'color_supply' 표로 실림"""
    st, _ = procure_stock(T, [], today)
    sup = defaultdict(Counter)
    for k, t in st.items():
        pl, c = k.split(':', 1)
        if pl == 'C' and t > 0:
            sup[c][today] += t
    mo, _ = open_orders(T, today, load_base('procure_base.json') or {})
    for a in mo or []:
        if a.get('plant') == 'C':
            sup[a['code']][a['date']] += a['t']
    return sup


STALE_DAYS = 30                                                      # 기발주: 예정일(발주일+리드타임)이 이만큼 지나면 충당에서 제외(확인 목록)
G_GROUPS = ('F', 'H', 'T', 'Y', 'N')                                # F/H 계열·도금용 SUS = 도금 소재, 나머지 = 컬러 구매 소재


def open_orders(T, today, base):
    """MES 미입고 발주(기발주) = 발주(SMAT.MO_GC_ORD_ASK) − 입고(SMAT.MO_ENT), 발주 행번별.
    · 빼는 것: 자가(A1, 도금→컬러 사내 공급)·삭제(WRK_CLS D)·주문량의 10% 또는 1t 이하 잔량(입고 끝난 것으로 봄 — 입고/주문 중앙값 0.98)
    · 입고 합계(snap_raw_ent_sum, 240일)가 있으면 180일 발주 전부, 없으면 입고 원장(60일) 시작일 이후 발주만(그 전 발주는 앞선 입고를 몰라 뺌)
    · 입고 예정일 = 발주일 + 그 업체·소재 리드타임(업체 기준정보, MES 발주→입고 실적) — MES 의 납기 칸은 발주일과 거의 같아 쓰지 않음.
      예정일이 지났는데 안 들어온 것은 내일 입고로 봄(지연 표시)"""
    A, S_, E = _rows(T, 'snap_raw_ask'), _rows(T, 'snap_raw_ent_sum'), _rows(T, 'snap_raw_ent')
    if not A or not (S_ or E):
        return [], None
    rec, start = Counter(), '00000000'
    if S_:
        for r in S_:
            rec[(r['RAW_PUR_NO'], r['RAW_PUR_SEQ'])] += f(r.get('ENT_WGT'))
    else:
        start = min(str(r['ENT_DT']) for r in E if r.get('ENT_DT'))
        for r in E:
            rec[(r['RAW_PUR_NO'], r['RAW_PUR_SEQ'])] += f(r.get('RAW_ENT_WGT'))
    lt = {}
    for s in base.get('suppliers', []):
        lt.setdefault((s['plant'], s['code'], s['sup']), s['lt'])
        lt.setdefault(('*', s['sup']), s['lt'])
        lt[('code', s['plant'], s['code'])] = max(lt.get(('code', s['plant'], s['code']), 0), s['lt'])
    D = lambda s: dt.date(int(s[:4]), int(s[4:6]), int(s[6:8]))
    t0, tomorrow, out, stale = D(today.replace('-', '')), None, [], []
    tomorrow = (t0 + dt.timedelta(days=1)).isoformat()
    for r in A:
        sup, grp, od = str(r.get('RAW_SUP_CPY') or ''), str(r.get('RAW_GRP') or ''), str(r.get('RAW_ORD_DT') or '')
        if not od or od < start or sup == 'A1' or r.get('WRK_CLS') == 'D' or not grp:
            continue
        o = f(r.get('RAW_PUR_SEQ_ORD_WGT'))
        got = rec[(r['RAW_PUR_NO'], r['RAW_PUR_SEQ'])]
        left = o - got
        # 입고가 시작된 발주의 10t 미만 잔량은 코일 1개(도금 소재 99%가 11.7t 이상)가 못 되는 발주·입고 중량 차이 → 마감으로 봄
        if left <= max(1000.0, 0.1 * o) or (got > 0 and left < 10000.0):
            continue
        plant = 'G' if grp in G_GROUPS else 'C'
        days = lt.get((plant, grp, sup)) or lt.get(('*', sup)) or lt.get(('code', plant, grp)) or 60
        eta = (D(od) + dt.timedelta(days=int(days))).isoformat()
        late = eta <= today
        if (t0 - dt.date.fromisoformat(eta)).days > STALE_DAYS:                       # 예정일 30일+ 지남 = 들어온다고 보기 어려움 → 충당에서 빼고 확인 목록으로(부족을 숨기지 않게)
            stale.append({'eta': eta, 'plant': 'G' if grp in G_GROUPS else 'C', 'code': grp, 't': round(left / 1000, 1), 'sup': sup, 'po': f"{r['RAW_PUR_NO']}-{r['RAW_PUR_SEQ']}",
                          'days': (t0 - dt.date.fromisoformat(eta)).days, 'note': f"{od[4:6]}/{od[6:]} 발주 + 리드타임 {days}일 → 예정 {eta[5:7]}/{eta[8:]}, {(t0 - dt.date.fromisoformat(eta)).days}일 지남"})
            continue
        out.append({'date': tomorrow if late else eta, 'ord': _iso(od), 'plant': plant, 'code': grp, 't': round(left / 1000, 1), 'sup': sup, 'po': f"{r['RAW_PUR_NO']}-{r['RAW_PUR_SEQ']}",
                    'src': 'mes', 'note': f"MES 미입고 발주 · {od[4:6]}/{od[6:]} 발주 + 리드타임 {days}일" + (' · 예정일 지남(내일 입고로 봄)' if late else '')})
    stale.sort(key=lambda x: -x['t'])
    return out, {'n': len(out), 't': round(sum(x['t'] for x in out)), 'from': start if start != '00000000' else None, 'full': bool(S_),
                 'stale': stale, 'staleT': round(sum(x['t'] for x in stale)), 'staleDays': STALE_DAYS}


def _lt_of(base):
    """업체·소재 리드타임(일) 찾기 — open_orders 와 같은 순서(업체·소재 → 업체 → 소재 최대 → 60일)"""
    lt = {}
    for s_ in (base or {}).get('suppliers', []):
        lt.setdefault((s_['plant'], s_['code'], s_['sup']), s_['lt'])
        lt.setdefault(('*', s_['sup']), s_['lt'])
        lt[('code', s_['plant'], s_['code'])] = max(lt.get(('code', s_['plant'], s_['code']), 0), s_['lt'])
    return lambda plant, grp, sup: lt.get((plant, grp, sup)) or lt.get(('*', sup)) or lt.get(('code', plant, grp)) or 60


def _ord_dates(T):
    """발주 행번 → 발주일(YYYYMMDD) — 180일 발주표 + 입고 코일의 발주(창 밖, snap_raw_ask_ent)"""
    od = {}
    for n in ('snap_raw_ask_ent', 'snap_raw_ask'):
        for r in _rows(T, n):
            if r.get('RAW_ORD_DT'):
                od[(str(r['RAW_PUR_NO']), str(r['RAW_PUR_SEQ']))] = str(r['RAW_ORD_DT'])
    return od


def _iso(s):
    s = str(s or '')
    return f"{s[:4]}-{s[4:6]}-{s[6:8]}" if len(s) >= 8 else None


def cg_raw(T, coils, base=None):
    """11/18 사용자 '전부 MES에서 받아와': 도금 생산(날짜·강종) → 그날 쓴 소재 코일(MES 도금 코일 실적의 소재번호) → 입고일(MO_ENT) → 발주일(MO_GC_ORD_ASK).
    발주일이 없으면 입고일 − 업체·소재 리드타임으로 역산(ordEst). 키 = '날짜|강종'(AZ·MAC·AL…), 값 = 입고일·발주일 범위"""
    ent = {}
    for n in sorted(k for k in T if k.startswith('snap_raw_ent_coil')):
        for r in _rows(T, n):
            if r.get('RAW_NO'):
                ent[str(r['RAW_NO']).strip()] = r
    if not ent or not coils:
        return {}
    od, ltf = _ord_dates(T), _lt_of(base)
    p2r = {}                                                    # 도금 생산번호(PRD_NO = 코일 실적 prd) → 투입 소재번호(RAW_NO) — 작업지시·주문 데이터 표
    for n in [k for k in T if k.startswith(('hist_cg_wo_', 'snap_cg_ord_data', 'hist_cg_orddata_', 'snap_wo_cg'))]:
        for r in _rows(T, n):
            if r.get('PRD_NO') and r.get('RAW_NO'):
                p2r.setdefault(str(r['PRD_NO']).strip(), str(r['RAW_NO']).strip())
    acc = defaultdict(lambda: {'in': [], 'ord': [], 'est': 0, 'n': 0})
    for c in coils:
        rn = p2r.get(str(c.get('prd') or '').strip(), '')
        e = ent.get(rn)
        if not e or c.get('dummy'):
            continue
        d_in = _iso(e.get('REAL_ENT_DT') or e.get('ENT_DT'))
        grp, sup = str(e.get('RAW_GRP') or ''), str(e.get('RAW_SUP_CPY') or '')
        o = _iso(od.get((str(e.get('RAW_PUR_NO')), str(e.get('RAW_PUR_SEQ')))))
        x = acc[f"{c['day']}|{c.get('fam') or ''}"]
        if not o and d_in:
            o = (dt.date.fromisoformat(d_in) - dt.timedelta(days=int(ltf('G' if grp in G_GROUPS else 'C', grp, sup)))).isoformat()
            x['est'] += 1
        x['n'] += 1
        if d_in: x['in'].append(d_in)
        if o: x['ord'].append(o)
    return {k: {'in': [min(v['in']), max(v['in'])] if v['in'] else None, 'ord': [min(v['ord']), max(v['ord'])] if v['ord'] else None, 'est': v['est'] > 0, 'n': v['n']} for k, v in acc.items()}


def self_in(T, base=None, days=150):
    """11/18 사용자 '자가재 재고 10/1 이전 생산 — 이게 제일 중요': 컬러공장 자가재 입고 코일(MO_ENT 업체 A1, 소재번호 = 도금 제품번호)마다
    컬러공장 입고일 · 도금 생산일(도금 코일 이력) · 소재 입고일(투입 소재 코일 MO_ENT) · 발주일(MO_GC_ORD_ASK, 없으면 입고일 − 리드타임).
    강종 = 소재그룹 V AZ · O MAC · A AL. 화면이 재고 묶음(먼저 들어온 것 먼저)을 이 기록으로 날짜를 붙임"""
    ent = {}
    for n in sorted(k for k in T if k.startswith('snap_raw_ent_coil')):
        for r in _rows(T, n):
            if r.get('RAW_NO'):
                ent.setdefault(str(r['RAW_NO']).strip(), r)
    if not ent:
        return {}
    C = {}
    for n in [k for k in T if k.startswith('hist_cg_coil_')] + ['snap_cg_prod_recent']:
        for r in _rows(T, n):
            if r.get('PDT_NO'):
                C[str(r['PDT_NO']).strip()] = r
    p2r = {}
    for n in [k for k in T if k.startswith(('hist_cg_wo_', 'snap_cg_ord_data', 'hist_cg_orddata_', 'snap_wo_cg'))]:
        for r in _rows(T, n):
            if r.get('PRD_NO') and r.get('RAW_NO'):
                p2r.setdefault(str(r['PRD_NO']).strip(), str(r['RAW_NO']).strip())
    od, ltf = _ord_dates(T), _lt_of(base)
    FAMC = {'V': 'AZ', 'O': 'MAC', 'A': 'AL'}
    lim = (dt.date.today() - dt.timedelta(days=days)).strftime('%Y%m%d')
    out = defaultdict(list)
    for rn, e in ent.items():
        if str(e.get('RAW_SUP_CPY') or '') != 'A1' or str(e.get('ENT_DT') or '') < lim:
            continue
        fam = FAMC.get(str(e.get('RAW_GRP') or ''))
        if not fam:
            continue
        x = {'c': _iso(e.get('REAL_ENT_DT') or e.get('ENT_DT')), 't': round(f(e.get('RAW_ENT_WGT')) / 1000, 1)}
        c = C.get(rn)
        if c:
            x['p'] = _iso(c.get('PRD_DT'))
            fr = ent.get(p2r.get(str(c.get('PRD_NO') or '').strip(), ''))
            if fr:
                x['i'] = _iso(fr.get('REAL_ENT_DT') or fr.get('ENT_DT'))
                o = _iso(od.get((str(fr.get('RAW_PUR_NO')), str(fr.get('RAW_PUR_SEQ')))))
                if not o and x['i']:
                    g = str(fr.get('RAW_GRP') or '')
                    o = (dt.date.fromisoformat(x['i']) - dt.timedelta(days=int(ltf('G', g, str(fr.get('RAW_SUP_CPY') or ''))))).isoformat()
                x['o'] = o
        out[fam].append(x)
    return {k: sorted(v, key=lambda z: z['c'] or '') for k, v in out.items()}


def ord_chain(T, base=None):
    """11/18 사용자 '진행해'(주문별 실제 코일 날짜): MES 소재 매치(SSCHC1040, snap_cc_coil_match)에 코일이 붙은 컬러 계약마다
    소재 발주 · 소재 입고 · (자가재) 도금 생산 · 컬러공장 입고 — 계약 안 코일 중 가장 늦은 날(소재가 다 갖춰진 날).
    화면은 계획 행(품목·목적지·납기)과 같은 계약을 찾아 이 날짜를 씀(계획 숫자는 안 바뀜)"""
    M = defaultdict(list)
    for n in T:
        if n.startswith('snap_cc_coil_match'):
            for r in _rows(T, n):
                M[(str(r['CON_NO']), str(r['CON_SEQ']))].append(r)
    if not M:
        return []
    O = {}
    for n in sorted(k for k in T if k.startswith('snap_cc_open_ord')):
        for r in _rows(T, n):
            O[(str(r['CON_NO']), str(r['CON_SEQ']))] = r
    dn = {}
    for n in ('snap_cc_dst_code', 'snap_dst_names'):
        for r in _rows(T, n):
            if r.get('CD_VAL') and r.get('CD_NM'):
                dn[str(r['CD_VAL'])] = str(r['CD_NM']).strip()
    ent = {}
    for n in sorted(k for k in T if k.startswith('snap_raw_ent_coil')):
        for r in _rows(T, n):
            if r.get('RAW_NO'):
                ent.setdefault(str(r['RAW_NO']).strip(), r)
    C = {}
    for n in [k for k in T if k.startswith('hist_cg_coil_')] + ['snap_cg_prod_recent']:
        for r in _rows(T, n):
            if r.get('PDT_NO'):
                C[str(r['PDT_NO']).strip()] = r
    p2r = {}
    for n in [k for k in T if k.startswith(('hist_cg_wo_', 'snap_cg_ord_data', 'hist_cg_orddata_', 'snap_wo_cg'))]:
        for r in _rows(T, n):
            if r.get('PRD_NO') and r.get('RAW_NO'):
                p2r.setdefault(str(r['PRD_NO']).strip(), str(r['RAW_NO']).strip())
    od, ltf = _ord_dates(T), _lt_of(base)
    out = []
    for k, L in M.items():
        o_ = O.get(k)
        if not o_:
            continue
        x = {'o': [], 'i': [], 'p': [], 'c': []}
        for r in L:
            rn = str(r['RAW_NO']).strip()
            e = ent.get(rn)
            if not e:
                continue
            if str(e.get('RAW_SUP_CPY') or '') == 'A1':                # 자가재: 컬러공장 입고 → 도금 코일 → 투입 소재
                x['c'].append(_iso(e.get('REAL_ENT_DT') or e.get('ENT_DT')))
                c = C.get(rn)
                if not c:
                    continue
                x['p'].append(_iso(c.get('PRD_DT')))
                e = ent.get(p2r.get(str(c.get('PRD_NO') or '').strip(), ''))
                if not e:
                    continue
            d_in = _iso(e.get('REAL_ENT_DT') or e.get('ENT_DT'))
            x['i'].append(d_in)
            o = _iso(od.get((str(e.get('RAW_PUR_NO')), str(e.get('RAW_PUR_SEQ')))))
            if not o and d_in:
                g = str(e.get('RAW_GRP') or '')
                o = (dt.date.fromisoformat(d_in) - dt.timedelta(days=int(ltf('G' if g in G_GROUPS else 'C', g, str(e.get('RAW_SUP_CPY') or ''))))).isoformat()
            x['o'].append(o)
        if not x['i']:
            continue
        dc = str(o_.get('ARV_DST_CD') or o_.get('DST_CD') or '')
        dv = o_.get('ORD_DLV_DAT') or o_.get('UPD_DLV')
        due = dt.datetime.fromtimestamp(dv / 1000, dt.timezone(dt.timedelta(hours=9))).date().isoformat() if isinstance(dv, (int, float)) else _iso(dv)
        out.append({'pn': product_name(o_.get('PDT_NM') or ''), 'dst': dn.get(dc, dc), 'due': due,
                    't': round(sum(f(r.get('RAW_MCH_WGT')) for r in L) / 1000, 1), **{f_: max(v for v in x[f_] if v) if any(x[f_]) else None for f_ in 'oipc'}})
    return sorted(out, key=lambda z: (z['due'] or '9'))


def stock_lots(T, stock, base=None):
    """지금 재고를 이루는 입고분(소재별) — 11/18 사용자 '언제 소재 발주해서 언제 입고됐는지 날짜를 적어야'.
    입고 합계(snap_raw_ent_sum: 발주 행번별 입고 톤·마지막 입고일) × 발주(snap_raw_ask: 발주일). 먼저 들어온 것을 먼저 쓴다고 보고
    최근 입고부터 거꾸로 지금 재고 톤만큼 모은 뒤 오래된 순으로 — 화면이 그날 쓰는 몫이 어느 입고분인지 이어 붙임(재고 → 발주 입고 예정 순)"""
    S_, A = _rows(T, 'snap_raw_ent_sum'), _rows(T, 'snap_raw_ask')
    if not S_:
        return {}
    od, ltf = _ord_dates(T), _lt_of(base)   # 발주일 없으면 입고일 − 리드타임 역산(11/18 사용자)
    by = defaultdict(list)
    for r in S_:
        grp, d = str(r.get('RAW_GRP') or ''), str(r.get('LAST_DT') or r.get('FIRST_DT') or '')
        t = f(r.get('ENT_WGT')) / 1000
        if not grp or len(d) < 8 or t < 0.5 or str(r.get('RAW_SUP_CPY') or '') == 'A1':
            continue
        k = f"{'G' if grp in G_GROUPS else 'C'}:{grp}"
        o, est = _iso(od.get((str(r['RAW_PUR_NO']), str(r['RAW_PUR_SEQ'])))), False
        if not o:
            o, est = (dt.date.fromisoformat(_iso(d)) - dt.timedelta(days=int(ltf(k[0], grp, str(r.get('RAW_SUP_CPY') or ''))))).isoformat(), True
        by[k].append({'in': _iso(d), 'ord': o, 'est': est, 't': round(t, 1)})
    out = {}
    for k, L in by.items():
        need, acc, keep = f((stock or {}).get(k)), 0.0, []
        for x in sorted(L, key=lambda z: z['in'], reverse=True):
            if acc >= need - 0.5:
                break
            keep.append(dict(x, t=round(min(x['t'], need - acc), 1)))
            acc += x['t']
        if keep:
            out[k] = keep[::-1]
    return out


def procure(T, coils, today, base=None):
    base = base or load_base('procure_base.json')
    if not base:
        return None
    stock, note = procure_stock(T, coils, today)
    ps = load_base('planstock_base.json') or {}
    sm = max((str(r['_기준월']) for r in _rows(T, 'snap_stock')), default='202609')
    y, m = int(sm[:4]), int(sm[4:])
    snap_end = (dt.date(y + (m // 12), m % 12 + 1, 1) - dt.timedelta(days=1)).isoformat()
    arr = [{'date': a, 'plant': 'G', 'code': 'F', 't': t, 'sup': '수입 FH', 'note': f'{thk}×{wdt} {coat} ({o} 발주)'}            # 수입 FH 기발주(○월적, 기초재고 파일)
           for a, o, thk, wdt, coat, t in ps.get('fhOrdered', []) if a > snap_end]
    mo, minfo = open_orders(T, today, base)
    if mo:                                                       # MES 미입고 발주가 있으면 그것을 씀 — 수입 FH(V3)도 MES 발주에 있어 앞날 일정은 MES 로 대체(이중 계상 방지)
        arr = ([] if 'MES 입고' in note else [a for a in arr if a['date'] <= today]) + mo   # 재고에 MES 입고를 넣었으면 지난 수입 FH 도 이미 재고에 있음
    # 도금 FH 재고는 월말 재고 − 이후 사용(입고 자료 없음) → 월말 이후 들어온 수입 FH 기발주도 입고로 더함(날짜가 지났으면 이미 들어온 것)
    return dict(base, today=today, built=dt.datetime.now(dt.timezone(dt.timedelta(hours=9))).replace(tzinfo=None).isoformat(timespec='minutes'), stock=stock, stockNote=note, stockLots=stock_lots(T, stock, base), cgRaw=cg_raw(T, coils, base), selfIn=self_in(T, base), ordChain=ord_chain(T, base), known=arr, knownInfo=minfo, supNames=sup_names(T))


FH_DUE_GRP = {'F': 'F/H(AZ·MAC용)', 'H': 'F/H(AL용)', 'T': 'F/H(Ti 첨가)', 'Y': 'F/H(고내식 AL용)', 'N': 'AL-STS 임가공'}   # MES 소재군 코드표 RAW_GRP — T = F/H(Ti-AL/GI/GL용)


def _ymd(v):
    v = str(v or '')
    return dt.date(int(v[:4]), int(v[4:6]), int(v[6:8])) if len(v) >= 8 and v[:2] == '20' else None


def fh_tf_due(od, sup):
    """TF 기준 납기(팀 소재 리드타임 표 2026-10-12): POSCO F/H = 매주 발주 +5주, 수입 FH(V 계열) = 발주 다음다음 달 7일경"""
    if str(sup).startswith('V'):
        y, m = od.year + (od.month + 1) // 12, (od.month + 1) % 12 + 1
        return dt.date(y, m, 7)
    return od + dt.timedelta(days=35)


def fh_due(T):
    """F/H 납기 비교 — POSCO F/H 발주 건별(10/22 사용자: 발주 건바이건, 수입 FH 빼고 POSCO F/H만).
    발주 행번 1건 = 1표본. 실제 입고 = 그 발주가 끝난 날(입고 합계 snap_raw_ent_sum 마지막 입고일 LAST_DT = 실입고일 nvl(REAL_ENT_DT, ENT_DT)) — 발주 종료(PUR_END_YN = Y)만 '완납'.
    입고 원장(snap_raw_ent)은 9/7 이후만 있어 쓰지 않음(입고 합계는 4월부터 전 기간). 판정 대상 = 발주 후 60일 지난 건(최근 발주는 아직 안 끝나 빠른 쪽으로 치우침) —
    그중 안 끝난 건은 95% 일수·기준 안 비율에서 '늦음'으로 셈(평균·표준편차는 완납 건만). TF 기준 = 발주 + 35일, 인도납기 = MES 발주 인도납기일(ORD_DLV_DT 현재 값)"""
    A = {(r['RAW_PUR_NO'], r['RAW_PUR_SEQ']): r for r in _rows(T, 'snap_raw_ask')}
    ok = lambda a: a and a.get('RAW_GRP') in ('F', 'H', 'T', 'Y') and a.get('RAW_SUP_CPY') in ('P1', 'P2') and a.get('WRK_CLS') != 'D' \
        and _ymd(a.get('ORD_DLV_DT')) and _ymd(a.get('RAW_ORD_DT'))
    tb = lambda t: '~0.39' if t < 0.40 else '0.40~0.59' if t < 0.60 else '0.60~0.79' if t < 0.80 else '0.80~1.19' if t < 1.20 else '1.20~'
    wb = lambda w: '~999' if w < 1000 else '1,000~1,219' if w < 1220 else '1,220~1,249' if w < 1250 else '1,250~'
    # 규격(10/22 사용자: SMATA1080 '규격' 칸별로) — 발주 표 소재규격코드, 없으면 입고 표(MO_ENT) 규격. 이름 = 코드표 PRC_ORD_SPEC_CD, 없으면 입고 표 규격약호
    # 묶음 = 규격 이름(CSP1-HA·CSP2-HA 등 — 코드는 달라도 이름이 같으면 한 줄, 10/22 사용자 'CSP1·CSP2 규격 구분'). 이름 = 입고 표 규격약호, 없으면 코드표
    SPN = {r['CD_VAL']: r['CD_NM'] for nm in ('snap_code_detail', 'snap_code_detail1', 'snap_code_detail2') for r in _rows(T, nm) if r.get('MASTER_CD') == 'PRC_ORD_SPEC_CD'}
    SPC = {}
    for r in _rows(T, 'snap_raw_ent_spec'):
        if r.get('RAW_SPEC_CD'):
            SPC[(r['RAW_PUR_NO'], r['RAW_PUR_SEQ'])] = r['RAW_SPEC_CD']
            if r.get('SPEC_NM'):
                SPN[r['RAW_SPEC_CD']] = r['SPEC_NM']
    for r in _rows(T, 'snap_raw_ask_spec'):
        if r.get('RAW_SPEC_CD'):
            SPC[(r['RAW_PUR_NO'], r['RAW_PUR_SEQ'])] = r['RAW_SPEC_CD']
    spec = lambda k: (lambda c: (SPN.get(c) or c) if c else None)(SPC.get(k))
    # 규격 한글(10/22 사용자): MES 코드표 A10G(소재 규격 → 품질 등급 ATTR2·설명) — CQ 일반용·DQ 가공용·DDQ 심가공용·EDDQ 초심가공용·GrB~F 구조용
    QK = {'CQ': '일반용', 'DQ': '가공용', 'DDQ': '심가공용', 'EDDQ': '초심가공용'}
    SPKO, PRI = {}, {}
    for nm in ('snap_code_detail', 'snap_code_detail1', 'snap_code_detail2'):
        for r in _rows(T, nm):
            if r.get('MASTER_CD') != 'A10G' or not r.get('ATTR3'):
                continue
            ds, q, key = str(r.get('CD_DESC') or ''), str(r.get('ATTR2') or ''), str(r['ATTR3'])
            d0 = ds.split(',')[0].split()[0] if ds.strip() else ''
            if ds.startswith('구조용'):
                ko, pr = ds.split(',')[0].strip(), 0                # 구조용37·41·46·58(인장강도 급)
            elif d0 in QK:
                ko, pr = QK[d0], 1                                 # 설명에 적힌 등급(EDDQ 등)이 ATTR2 보다 정확
            elif 'BIS' in ds:
                ko, pr = f'인도 BIS {QK.get(q, q)}', 1
            elif '내변색' in ds:
                ko, pr = '심가공 · 고내열 내변색', 1
            else:
                ko, pr = QK.get(q) or (f'구조용 {q}' if q.startswith('Gr') else ''), 2
            if 'FL' in key and ko and '평탄도' not in ko:
                ko += ' · 평탄도 관리'
            if ko and pr < PRI.get(key, 9):
                SPKO[key], PRI[key] = ko, pr
    SM = {(x['RAW_PUR_NO'], x['RAW_PUR_SEQ']): x for x in _rows(T, 'snap_raw_ent_sum')}
    lasts = [_ymd(x.get('LAST_DT')) for x in SM.values() if _ymd(x.get('LAST_DT'))]
    if not lasts:
        return None
    today = max(lasts)
    cut = today - dt.timedelta(days=60)
    recs = []
    for k, a in A.items():
        if not ok(a):
            continue
        od, due = _ymd(a['RAW_ORD_DT']), _ymd(a['ORD_DLV_DT'])
        if od < dt.date(2026, 1, 1):
            continue
        x = SM.get(k) or {}
        last, first = _ymd(x.get('LAST_DT')), _ymd(x.get('FIRST_RDT') or x.get('FIRST_DT'))   # 첫 입고: 실입고일(FIRST_RDT, 10/22 추가) — 없으면 입고일
        recs.append({'k': k, 'kind': FH_DUE_GRP[a['RAW_GRP']], 'thk': f(a.get('RAW_THK')), 'wdt': f(a.get('RAW_WDT')), 'od': od, 'due': due, 'tf': fh_tf_due(od, a.get('RAW_SUP_CPY')),
                     'w': f(a.get('RAW_PUR_SEQ_ORD_WGT')) / 1000, 'got': f(x.get('ENT_WGT')) / 1000, 'done': a.get('PUR_END_YN') == 'Y' and bool(last), 'last': last, 'first': first, 'spec': spec(k)})
    if not recs:
        return None
    # 코일별 입고(10/22 사용자 '발주 입고일 자체 소요일') — hist_raw_ent_fh_YYMM(4월~) + snap_raw_ent(최근 45일). 실입고일(없으면 입고일), 같은 코일은 한 번
    CL, seen, cov = defaultdict(list), set(), None
    for nm in sorted(k for k in T if k.startswith('hist_raw_ent_fh_')) + ['snap_raw_ent']:
        for e in _rows(T, nm):
            if e.get('RAW_GRP') not in ('F', 'H', 'T', 'Y') or e.get('RAW_SUP_CPY') not in ('P1', 'P2') or e.get('REAL_ENT_YN') in ('N', 'S'):
                continue
            k, d0 = (e['RAW_PUR_NO'], e['RAW_PUR_SEQ']), _ymd(e.get('REAL_ENT_DT') or e.get('ENT_DT'))
            ck = (k, e.get('OG_RAW_NO') or (e.get('ENT_DT'), e.get('RAW_ENT_WGT')))
            if d0 and ck not in seen:
                seen.add(ck)
                CL[k].append((d0, f(e.get('RAW_ENT_WGT')) / 1000))
            if nm != 'snap_raw_ent' and _ymd(e.get('ENT_DT')):
                cov = min(cov or _ymd(e['ENT_DT']), _ymd(e['ENT_DT']))
    INF = 10 ** 6
    def ms(xs):
        if len(xs) < 2:
            return None, None
        m = sum(xs) / len(xs)
        return round(m, 1), round((sum((v - m) ** 2 for v in xs) / (len(xs) - 1)) ** 0.5, 1)
    def st(rs):
        """판정 대상 발주 건 통계 — 완납 일수(가운데·평균±표준편차·90·95%), 첫 입고, 인도납기 일수, TF·인도납기 안에 끝난 건 비율"""
        c = [r for r in rs if r['od'] <= cut]
        if not c:
            return None
        L = sorted(((r['last'] - r['od']).days if r['done'] else INF) for r in c)
        n = len(L)
        q = lambda p: (lambda v: None if v >= INF else v)(L[min(n - 1, max(0, -(-int(p * n * 1000) // 1000) - 1))])
        done = [v for v in L if v < INF]
        am, asd = ms(done)
        fm, fsd = ms([(r['first'] - r['od']).days for r in c if r['first']])
        dl = [(r['due'] - r['od']).days for r in c]
        dm, dsd = ms(dl)
        late = [(r['last'] - r['due']).days for r in c if r['done']]
        rcv = {}
        if cov:                                                  # 입고 기준: 입고량(톤) 가중 — 판정 대상 발주의 코일마다 (발주 → 실입고 일수, 톤), 안 끝난 발주의 남은 양 = 늦음
            xs, nk, dueOk = [], 0, 0.0
            for r in c:
                cs = CL.get(r['k']) or []
                if (r['first'] and r['first'] < cov) or (r['got'] > 0 and abs(sum(w for _, w in cs) - r['got']) > 0.1 * r['got']):
                    continue                                     # 코일 이력이 덮지 못하는 발주(첫 입고가 이력 시작 전·톤이 안 맞음)는 뺌
                nk += 1
                xs += [((d0 - r['od']).days, w) for d0, w in cs]
                dueOk += sum(w for d0, w in cs if d0 <= r['due'])
                if not r['done'] and r['w'] > r['got']:
                    xs.append((INF, r['w'] - r['got']))
            tot = sum(w for _, w in xs)
            if nk >= 5 and tot > 0:
                xs.sort()
                def wq(p):
                    acc = 0
                    for v, w in xs:
                        acc += w
                        if acc >= p * tot - 1e-9:
                            return None if v >= INF else v
                ok_ = [(v, w) for v, w in xs if v < INF]
                tw = sum(w for _, w in ok_)
                m = sum(v * w for v, w in ok_) / tw
                rcv = {'rcvN': nk, 'rcvT': round(tot), 'rcvMean': round(m, 1), 'rcvSd': round((sum(w * (v - m) ** 2 for v, w in ok_) / tw) ** 0.5, 1), 'rcvP90': wq(.9), 'rcvP95': wq(.95),
                       'rcvInTf': round(100 * sum(w for v, w in xs if v <= 35) / tot, 1), 'rcvInDue': round(100 * dueOk / tot, 1)}
        return {**rcv, 'n': n, 'nOpen': n - len(done), 't': round(sum(r['w'] for r in c)), 'tfDays': 35, 'arrDays': q(.5), 'arrMean': am, 'arrSd': asd, 'arrP90': q(.9), 'arrP95': q(.95),
                'firstMean': fm, 'firstSd': fsd, 'dueDays': sorted(dl)[len(dl) // 2], 'dueMean': dm, 'dueSd': dsd,
                'inTf': round(100 * sum(1 for r in c if r['done'] and r['last'] <= r['tf']) / n, 1),
                'inDue': round(100 * sum(1 for r in c if r['done'] and r['last'] <= r['due']) / n, 1),
                'vsDue': round(sum(late) / len(late), 1) if late else None}
    KO = ['F/H(AL용)', 'F/H(AZ·MAC용)', 'F/H(Ti 첨가)', 'F/H(고내식 AL용)']
    byKind = [dict(kind=kd, **s) for kd in KO for s in [st([r for r in recs if r['kind'] == kd])] if s]
    G = defaultdict(list)
    for r in recs:
        G[(r['kind'], tb(r['thk']), wb(r['wdt']))].append(r)
    rows = [dict(kind=kk[0], thk=kk[1], wdt=kk[2], **s) for kk, rs in G.items() for s in [st(rs)] if s and s['n'] >= 10]
    rows.sort(key=lambda r: (KO.index(r['kind']), r['thk'], r['wdt']))
    GS = defaultdict(list)
    for r in recs:
        if r['spec']:
            GS[(r['kind'], r['spec'])].append(r)
    bySpec = sorted((dict(kind=kk, spec=sp, specKo=SPKO.get(sp, ''), **s) for (kk, sp), rs in GS.items() for s in [st(rs)] if s and s['n'] >= 5), key=lambda r: (KO.index(r['kind']), -r['n']))   # 5건 이상 전부(20건 미만은 화면에서 '참고')
    nospec = Counter(r['kind'] for r in recs if r['od'] <= cut and not r['spec'])
    opn = []
    for r in recs:                                             # 아직 안 끝난 발주(코일 1개 이상 남음) 중 두 기준이 1주 넘게 다른 것
        left = r['w'] - r['got']
        if not r['done'] and left >= max(10.0, 0.1 * r['w']) and abs((r['due'] - r['tf']).days) >= 7 and max(r['tf'], r['due']) >= today - dt.timedelta(days=7):
            opn.append({'po': f"{r['k'][0]}-{r['k'][1]}", 'kind': r['kind'], 'thk': r['thk'], 'wdt': r['wdt'], 'od': r['od'].isoformat(), 'tf': r['tf'].isoformat(),
                        'due': r['due'].isoformat(), 'diff': (r['due'] - r['tf']).days, 't': round(left, 1), 'sup': 'P2'})
    opn.sort(key=lambda x: (x['tf'], x['po']))
    ods = [r['od'] for r in recs if r['od'] <= cut]
    return {'basisV': 2, 'from': min(ods).isoformat() if ods else None, 'to': cut.isoformat(), 'asOf': today.isoformat(), 'nPo': len(ods), 'nAll': len(recs),
            'basis': {'P': '발주 + 35일(매주 발주 +5주)'}, 'byKind': byKind, 'rows': rows, 'bySpec': bySpec, 'open': opn[:300],
            'rcvFrom': cov.isoformat() if cov else None,
            'specSmall': sorted([[kk, sp, c] for (kk, sp), rs in GS.items() for c in [sum(1 for r in rs if r['od'] <= cut)] if 0 < c < 5], key=lambda x: (KO.index(x[0]), -x[2])), 'noSpec': dict(nospec)}


def due_track(T, hist, today):
    """발주 인도납기일(ORD_DLV_DT) 변경 이력 — 매일 MES 발주 자료를 지난 값과 비교해 바뀐 행번을 쌓음(사내 PC out_dir/due_hist.json, 2026-10-21 사용자 "변경 이력 매일 쌓아").
    hist = {'start', 'po': {행번: [인도납기, 처음 본 날]}, 'chg': [[바뀐 날, 행번, 이전, 이후, 업체, 소재, 두께, 폭]]} — 반환 (새 hist, 화면 요약)"""
    h = hist if isinstance(hist, dict) and 'po' in hist else {'start': today, 'po': {}, 'chg': []}
    po, chg = h['po'], h['chg']
    for r in _rows(T, 'snap_raw_ask'):
        due = str(r.get('ORD_DLV_DT') or '')
        if not due or r.get('WRK_CLS') == 'D':
            continue
        k = f"{r['RAW_PUR_NO']}-{r['RAW_PUR_SEQ']}"
        if k in po and po[k][0] != due:
            chg.append([today, k, po[k][0], due, r.get('RAW_SUP_CPY'), r.get('RAW_GRP'), f(r.get('RAW_THK')), f(r.get('RAW_WDT'))])
            po[k][0] = due
        elif k not in po:
            po[k] = [due, today]
    cut = (D(today) - dt.timedelta(days=400)).isoformat()
    h['chg'] = [c for c in chg if c[0] >= cut]
    sh = lambda c: (_ymd(c[3]) - _ymd(c[2])).days if _ymd(c[2]) and _ymd(c[3]) else None
    rec = [c for c in h['chg'] if c[0] >= (D(today) - dt.timedelta(days=60)).isoformat()]
    summ = {'start': h['start'], 'nPo': len(po), 'nChg': len(h['chg']),
            'recent': [{'d': c[0], 'po': c[1], 'from': c[2], 'to': c[3], 'shift': sh(c), 'sup': c[4], 'grp': FH_DUE_GRP.get(c[5], c[5]), 'thk': c[6], 'wdt': c[7]} for c in sorted(rec, key=lambda c: c[0], reverse=True)[:300]]}
    return h, summ


def split_order(short, elig, left):
    """부족량을 업체별로: 27년 배정 비중대로(배정 합 0 이면 균등) → 리드타임 > 남은 일수인 업체 몫은 맞추는 업체로 배정 비중대로 넘김. web/procure.js judge 와 같은 규칙"""
    if not elig:
        return []
    ws = sum(float(s.get('share') or 0) for s in elig)
    parts = [{'s': s, 't': short * ((float(s.get('share') or 0) / ws) if ws > 0 else 1 / len(elig)), 'late': s['lt'] > left, 'moved': 0.0} for s in elig]
    ok = [p for p in parts if not p['late']]
    late_t = sum(p['t'] for p in parts if p['late'])
    if late_t > 0 and ok:
        ow = sum(float(p['s'].get('share') or 0) for p in ok)
        for p in ok:
            p['moved'] = late_t * ((float(p['s'].get('share') or 0) / ow) if ow > 0 else 1 / len(ok))
            p['t'] += p['moved']
        for p in parts:
            if p['late']:
                p['from'], p['t'] = p['t'], 0.0
    return parts


def procure_summary(P, plant=None):
    """조달 판단 화면 기본값(여유 일수, 기발주 = MES 미입고 발주 자동, 업체 기준정보 초기값)으로 1순위 발주 시한·대체·기발주 확인 건수"""
    today = D(P['today'])
    lots = dict(P['stock'])
    inbound = sorted((a['date'], f"{a['plant']}:{a['code']}", a['t']) for a in P.get('known') or [])   # 필요일까지 들어오는 기발주는 충당에 씀
    sup = defaultdict(list)
    for s in P['suppliers']:
        sup[(s['plant'], s['code'])].append(s)
    mon = today - dt.timedelta(days=today.weekday())
    near, alt, chk, short4 = [], 0, 0, 0.0
    units = []
    for u in P['units']:                                          # 오늘 이전 날짜 소요는 뺌(재고가 이미 실적 사용을 뺀 값 — 화면 ui/proccalc.js 와 같음)
        if u.get('days'):
            keep = {d: t for d, t in u['days'].items() if d >= P['today']}
            kt = sum(keep.values())
            if kt < 0.5:
                continue
            u = dict(u, t=kt, first=min(keep))
        units.append(u)
    for u in sorted(units, key=lambda x: (x['first'], x['code'])):
        if plant and u['plant'] != plant:
            continue
        if (u['plant'], u['code']) in POSCO_SUPPLIED:
            continue
        need_by = D(u['first']) - dt.timedelta(days=SAFETY[u['plant']])
        left = (need_by - today).days
        while inbound and inbound[0][0] <= need_by.isoformat():
            _, kk, tt = inbound.pop(0)
            lots[kk] = lots.get(kk, 0.0) + tt
        k = f"{u['plant']}:{u['code']}"
        q = min(lots.get(k, 0.0), u['t'])
        lots[k] = lots.get(k, 0.0) - q
        short = u['t'] - q
        if short < 1:
            continue
        cand = sorted(sup.get((u['plant'], u['code']), []), key=lambda s: s['prio'])
        spec = lambda s: not u.get('thk') or not s.get('thk') or (u['thk'][0] >= s['thk'][0] - .005 and u['thk'][1] <= s['thk'][1] + .005)
        parts = split_order(short, [s for s in cand if spec(s)], left)          # 화면(procure.js)과 같은 나눔: 27년 배정 비중 → 늦는 업체 몫은 맞추는 업체로
        ok = [p for p in parts if not p['late'] and p['t'] >= 1]
        wk = (D(u['wk']) - mon).days // 7
        if 1 <= wk < 4:
            short4 += short
            if not ok and cand:
                chk += 1
            elif any(p['late'] and p.get('from', 0) >= 1 for p in parts):
                alt += 1
        for p in ok:
            dl = need_by - dt.timedelta(days=p['s']['lt'])
            if 0 <= (dl - today).days <= 14:
                near.append({'plant': u['plant'], 'mat': P['matCode'].get(u['code'], u['code']), 'first': u['first'], 'deadline': dl.isoformat(), 't': round(p['t']),
                             'sup': (P.get('supNames') or {}).get(p['s']['sup']) or p['s']['name']})
    near.sort(key=lambda x: x['deadline'])
    return {'near': len(near), 'nearTop': near[:6], 'nearAll': near[:40], 'alt': alt, 'check': chk, 'short4w': round(short4)}


# ------------------------------------------------------------------ 계획 정확도(전날 계획 vs 실적)
def coil_daily(coils):
    a = defaultdict(float)
    for c in coils or []:
        if not c.get('dummy'):                                  # 더미 코일 제외(실적 분석·재계획과 같은 기준)
            a[(str(c['day']), c['line'])] += f(c['t'])
    return a


def plan_daily(R):
    a = defaultdict(float)
    for r in (R or {}).get('rows', []):
        a[(r[0], r[1])] += f(r[4])
    return a


def accuracy(hist, R_prev, coils, upto):
    """hist: [[날짜, 라인, 계획t, 실적t]] — R_prev(이번 실행 전 게시 계획)가 그날을 어떻게 잡았는지 vs 실적. 이미 있는 날은 덮지 않음"""
    pd_, ad = plan_daily(R_prev), coil_daily(coils)
    for h in hist:                                              # 실적은 MES 가 나중에 고치거나 늦게 들어오므로 최신 값으로 갱신
        if (h[0], h[1]) in ad:
            h[3] = round(ad[(h[0], h[1])], 1)
    have = {(h[0], h[1]) for h in hist}
    t0 = ((R_prev or {}).get('replan') or {}).get('t0') or ''
    days = sorted({d for (d, _) in ad if d > t0 and d <= upto})
    for d in days:
        for l in CGL:
            if (d, l) not in have and ((d, l) in pd_ or (d, l) in ad):
                hist.append([d, l, round(pd_.get((d, l), 0.0), 1), round(ad.get((d, l), 0.0), 1)])
    hist.sort()
    return hist


def accuracy_summary(hist, n=14):
    out = {}
    for l in CGL:
        h = [x for x in hist if x[1] == l][-n:]
        if not h:
            continue
        p, a = sum(x[2] for x in h), sum(x[3] for x in h)
        mape = sum(abs(x[3] - x[2]) for x in h) / max(1, p)
        out[l] = {'days': len(h), 'plan': round(p), 'actual': round(a), 'bias': round((a / p - 1) * 100, 1) if p else None,
                  'mae': round(mape * 100, 1), 'under': sum(1 for x in h if x[3] < x[2] * 0.95), 'last': h[-5:]}
    return out


def ccl_idle():
    """컬러 계획 휴지 {라인: {날짜}} — 계획 조건 장부 data/plan_conditions.json(kind ccl_idle, use apply). 파일이 없으면(사내 PC 설치 묶음) 빈 값"""
    out = defaultdict(set)
    try:
        C = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'plan_conditions.json'), encoding='utf-8'))
    except (OSError, ValueError):
        return out
    for x in (C if isinstance(C, list) else C.get('items') or C.get('conditions') or []):
        if isinstance(x, dict) and x.get('kind') == 'ccl_idle' and x.get('use') == 'apply' and x.get('from') and x.get('to'):
            d = D(x['from'])
            while d <= D(x['to']):
                out[x['line']].add(d.isoformat())
                d += dt.timedelta(days=1)
    return out


# ------------------------------------------------------------------ 오늘 볼 것(예외)
def exceptions(today, ca, pr_sum, R2, acc, stock_rows, data_last):
    E = []
    add = lambda lvl, area, text, link, who: E.append({'lvl': lvl, 'area': area, 'text': text, 'link': link, 'who': who})
    # 자료
    if data_last and (D(today) - D(data_last)).days > 1:
        add('bad', '자료', f'실적 자료 갱신 중단: {data_last}({(D(today) - D(data_last)).days}일 전) — 사내 PC 자동 실행 확인 필요', 'health.html', '생산기획')
    # 도금: 최근 계획 대비 실적
    for l, x in (acc or {}).items():
        last = x['last'][-3:]
        fresh = data_last and last and (D(data_last) - D(last[-1][0])).days <= 1          # 최근 이틀이 실제 최신 실적일 때만(오래된 이력으로 경고하지 않음)
        if fresh and len(last) >= 2 and all(r[3] < r[2] * 0.9 for r in last[-2:]):
            add('warn', '도금', f"{l} 2일 연속 계획 대비 90% 미만 (최근 {', '.join(f'{r[0][5:]}: {r[3]:,.0f}/{r[2]:,.0f}t' for r in last[-2:])}) — 속도·강종 순서 확인 필요", 'integrated.html', '생산기획')
    if R2:
        t0 = (R2.get('replan') or {}).get('t0') or today
        lim = (D(t0) + dt.timedelta(days=3)).isoformat()
        tight = [r for r in R2['rows'] if t0 < r[0] <= lim and (D(r[5]) - D(r[0])).days <= 1]
        if sum(f(r[4]) for r in tight) >= 300:
            add('warn', '도금', f'향후 3일 내 납기 1일 이내 생산 물량 {sum(f(r[4]) for r in tight):,.0f}t ({len(tight)}건) — 정지·지연 시 즉시 납기 지연', 'status.html', '생산기획')
    # 컬러
    if ca:
        M = {x['line']: x for x in ca['month']['rows']}
        nb = min(12, max(0, len(ca['weekly']) - 1))                          # 비교 기준 주 수(자료가 짧으면 4주 미만 → 주간 비교 생략)
        idle = ccl_idle()
        w1 = [(D(ca['w1']) + dt.timedelta(days=i)).isoformat() for i in range(7)] if ca.get('w1') else []
        for x in ca['lines']:
            if today in idle.get(x['line'], ()) or sum(d_ in idle.get(x['line'], ()) for d_ in w1) >= 3:   # 11/8 사용자: 계획 휴지 라인(2CCL 10/16~11/19)은 실적 저하 경보를 내지 않음
                continue
            d = (x['w1']['tpd'] / x['w0']['tpd'] - 1) * 100 if x['w0']['tpd'] and nb >= 4 else None
            m = M.get(x['line'])
            r = m['actual'] / m['sched'] * 100 if m and m.get('sched') else None
            if (d is not None and d <= -20) or (r is not None and r < 95):
                add('warn', '컬러', f"{x['line']} 지난주 {x['w1']['tpd']:,.0f}t/일" + (f'({nb}주 대비 {d:+.0f}%)' if d is not None else '') + (f', 이번 달 일정 대비 {r:.0f}%' if r is not None else '') + f" · 휴지 {x['w1']['stopH']:.1f}h/가동일", 'color_actual.html', '생산기획')
    # 소재
    if pr_sum:
        soon = [x for x in pr_sum.get('nearTop', []) if (D(x['deadline']) - D(today)).days <= 3]
        for x in soon[:3]:
            add('bad' if x['deadline'] <= today else 'warn', '소재', f"{x['mat']} {int(x['first'][5:7])}/{int(x['first'][8:10])} 소요분 중 {x['sup']} 몫 {x['t']:,}t, {int(x['deadline'][5:7])}/{int(x['deadline'][8:10])}까지 발주", 'procure.html', '구매')
        if pr_sum.get('check'):
            add('warn', '소재', f"2~4주 안 부족 예상 {pr_sum['check']}건(지금 발주하면 늦음) — 발주한 소재가 제때 들어오는지 확인", 'procure.html', '구매')
    # 재고
    for s in stock_rows or []:
        if s.get('target'):
            r = s['current'] / s['target']
            if r > 1.3 or r < 0.7:
                add('warn' if r < 1.6 else 'bad', '재고', f"{s['name']} {s['current']:,.0f}t — 재고 상한 {s['target']:,.0f}t의 {r * 100:.0f}%", 'report.html', '판매·생산기획')
    order = {'bad': 0, 'warn': 1}
    E.sort(key=lambda e: order.get(e['lvl'], 2))
    return E


# ------------------------------------------------------------------ 자료 상태
def stock_daily(T):
    """실제 재고 일별 = 판매생산속보 원천 표(SMKT.OS_GC_COMPR_PROMPT_RPT_7·8·9)의 합계 칸(TOT_WGT) — 속보 재고 현황과 같은 값(10/13 5항목 모두 일치 확인).
    7: 소재(CLS G = F/H, CLS_1 1·2·3 / CLS C = 컬러용, CLS_1 4 자가재 제외) · 8: 도금 제품(CLS 1·2·3 판매재, 4 자가재) · 9: 컬러 제품(CLS 1 건재·3 수요개발·5 수출).
    이번 달 1일부터(월 단위) + 전월 말 하루(출발점). [[날짜, 항목, t]]"""
    R7, R8, R9 = _rows(T, 'stock_rpt7'), _rows(T, 'stock_rpt8'), _rows(T, 'stock_rpt9')
    G8, G9 = {'5': 'g:G국내', '6': 'g:G수출', '7': 'g:G자동차'}, {'1': 'g:C건재', '5': 'g:C수출'}
    if not (R7 or R8 or R9):
        return []
    acc = defaultdict(float)
    for r in R7:
        d, c, c1 = str(r['WRK_DT']), r.get('CLS'), str(r.get('CLS_1'))
        if c == 'G' and c1 in ('1', '2', '3'):
            acc[(d, '도금 소재(F/H)')] += f(r.get('TOT_WGT'))
        elif c == 'C' and c1 != '4':
            acc[(d, '컬러 소재')] += f(r.get('TOT_WGT'))
    for r in R8:
        d, c = str(r['WRK_DT']), str(r.get('CLS'))
        if c in ('1', '2', '3'):
            acc[(d, '도금 제품(판매재)')] += f(r.get('TOT_WGT'))
        elif c == '4':
            acc[(d, '도금 제품(자가재)')] += f(r.get('TOT_WGT'))
        if c in G8:                                                  # 재고 추이 그룹(부서별 행): 5 도금판매 · 6 도금수출 · 7 자동차강판
            acc[(d, G8[c])] += f(r.get('TOT_WGT'))
    for r in R9:
        c = str(r.get('CLS'))
        if c in ('1', '3', '5'):
            acc[(str(r['WRK_DT']), '컬러 제품')] += f(r.get('TOT_WGT'))
        if c in G9:                                                  # 1 컬러건재 · 5 컬러수출(가전·건재) — 3 수요개발은 그룹 없음
            acc[(str(r['WRK_DT']), G9[c])] += f(r.get('TOT_WGT'))
    last = max(d for d, _ in acc)
    m0 = last[:6] + '01'
    prev = max((d for d, _ in acc if d < m0), default=m0)                # 전월 말(출발점, 예: 9/30) — 재고 추이 '공장별 전체'가 전월 말부터
    return [[f'{d[:4]}-{d[4:6]}-{d[6:]}', k, round(v)] for (d, k), v in sorted(acc.items()) if d >= m0 or d == prev]


def ship_day(T, d0):
    """그룹별 하루 출하 실적(2026-10-20 회의: 가동 캘린더 그룹별 생산·출하·재고) — MES 출하(ship) 판매 출고(OUT_RSN_CD 1300), 부서 → 그룹. {d0, asOf, g: {그룹: {날짜: t}}}"""
    out, last = defaultdict(lambda: defaultdict(float)), None
    for r in _rows(T, 'ship'):
        g, d = SHIP_DEPT.get(r.get('DEPT')), str(r.get('OUT_DT') or '')[:10]
        if not g or str(r.get('OUT_RSN_CD')) != '1300' or d < d0:
            continue
        out[g][d] += f(r.get('WGT')) / 1000
        last = max(last or d, d)
    return {'d0': d0, 'asOf': last, 'g': {g: {d: round(v, 1) for d, v in sorted(x.items())} for g, x in out.items()}} if out else None


def mat_recv(T, d0):
    """구매 소재 입고 실적(2026-10-20 회의: 소재 캘린더 월별 계획·발주·입고) — MES 소재 입고(snap_raw_ent), 자사(A1, 도금 → 컬러 자가재) 빼고,
    실입고 N(아직 안 들어옴) 빼고. {'공장|소재그룹|날짜': t}"""
    out = defaultdict(float)
    for r in _rows(T, 'snap_raw_ent'):
        d = str(r.get('REAL_ENT_DT') or r.get('ENT_DT') or '')
        if len(d) != 8 or d < d0.replace('-', '') or str(r.get('RAW_SUP_CPY') or '') == 'A1' or r.get('REAL_ENT_YN') == 'N':
            continue
        out[f"{r.get('PLT_CLS')}|{r.get('RAW_GRP')}|{d[:4]}-{d[4:6]}-{d[6:]}"] += f(r.get('RAW_ENT_WGT')) / 1000
    return {k: round(v, 1) for k, v in sorted(out.items())}


ACT_PLANT = {'F': 'G', 'H': 'G', 'N': 'G', 'T': 'G'}       # 소재 그룹 → 공장(입고 원장 PLT_CLS 실측: F·H·N·T = 도금, 나머지 = 컬러)


def mat_act(T, d0):
    """소재 캘린더 지난 날 실적(2026-10-21 사용자: ~어제까지 MES 에 발주·입고가 다 나오는데 왜 비어 있나) — 날짜·공장·소재그룹·업체(발주번호 앞 2자리)별 t.
    발주 = snap_raw_ask 발주일(RAW_ORD_DT)·발주량, 입고 = snap_raw_ent 실입고일·입고량. 자사(A1, 도금 → 컬러 자가재) 제외. {'ord'|'inb': {'공장|그룹|업체|날짜': t}}"""
    out = {'ord': defaultdict(float), 'inb': defaultdict(float)}
    dd = d0.replace('-', '')
    ymd = lambda d: f'{d[:4]}-{d[4:6]}-{d[6:]}'
    for r in _rows(T, 'snap_raw_ask'):
        d, sup = str(r.get('RAW_ORD_DT') or ''), str(r.get('RAW_SUP_CPY') or '')
        if len(d) != 8 or d < dd or sup == 'A1':
            continue
        grp = str(r.get('RAW_GRP') or '')
        pl = ACT_PLANT.get(grp) or 'C'
        out['ord'][f"{pl}|{grp}|{sup}|{ymd(d)}"] += f(r.get('RAW_PUR_SEQ_ORD_WGT')) / 1000
    for r in _rows(T, 'snap_raw_ent'):
        d, sup = str(r.get('REAL_ENT_DT') or r.get('ENT_DT') or ''), str(r.get('RAW_SUP_CPY') or '')
        if len(d) != 8 or d < dd or sup == 'A1' or r.get('REAL_ENT_YN') == 'N':
            continue
        out['inb'][f"{r.get('PLT_CLS')}|{r.get('RAW_GRP')}|{sup}|{ymd(d)}"] += f(r.get('RAW_ENT_WGT')) / 1000
    return {k: {kk: round(v, 1) for kk, v in sorted(x.items()) if v >= 0.05} for k, x in out.items()}


DEPT_GRP = {'도금판매그룹': '도금국내', '도금수출그룹': '도금수출', '자동차강판판매그룹': '자동차강판',
            '컬러수출그룹': '컬러수출', '컬러건재판매그룹': '컬러건재', '수요개발그룹': '수요개발'}


def mat_group(T, d0):
    """소재 입고·발주를 판매그룹으로(2026-10-20 사용자: 소재 캘린더 그룹 = 판매그룹, 컬러는 더 나눠서) — 소재 발주(snap_raw_ask) 계약·행번 →
    판매 부서 + 주문 용도·사양(snap_raw_ask_dept, 없으면 hist_cc_con_dept·hist_cg_con_dept 부서만).
    도금: 도금수출·도금국내·자동차강판, 컬러 부서 계약이면 자가재. 컬러: color_grouper 와 같은 6개 —
    건재판매 → 컬러건재(소재 발주엔 색이 없어 계획재·주문재 구분 안 함), 수요개발, 컬러수출 → 용도 CC* 건재수출 / 수출 계약(con_export) 가전수출 / 가전내수.
    {'recv': {'공장|그룹|날짜': t}, 'po': {'발주번호-행번': 그룹}}"""
    det, nm, code_nm = {}, {}, {}
    clr = {}                                                      # 계약 하나에 행이 여러 개(소재·도장) — 소재 발주는 색상 빈 소재 행에 걸림 → 같은 계약 도장 행의 색·두께·폭
    for r in _rows(T, 'snap_raw_ask_dept'):
        det[(r['CON_NO'], str(r.get('CON_SEQ')))] = r
        if r.get('CLR_SER_NO_TOP'):
            clr.setdefault(r['CON_NO'], r)
        if r.get('DEPART_NM'):
            nm[r['CON_NO']] = r['DEPART_NM']; code_nm[str(r.get('DEPART_CD'))] = r['DEPART_NM']
    for n in ('hist_cc_con_dept_a', 'hist_cc_con_dept_b'):
        for r in _rows(T, n):
            if r.get('DEPART_NM'):
                nm.setdefault(r['CON_NO'], r['DEPART_NM']); code_nm.setdefault(str(r.get('DEPART_CD')), r['DEPART_NM'])
    for r in _rows(T, 'hist_cg_con_dept'):
        if code_nm.get(str(r.get('DEPART_CD'))):
            nm.setdefault(r['CON_NO'], code_nm[str(r.get('DEPART_CD'))])
    dom = con_dom_map(T)

    def grp(plant, con, seq):
        dept = nm.get(con) or ''
        g = DEPT_GRP.get(dept)
        if not g:
            return '기타(계약 부서 없음)'
        if plant == 'G':
            return '자가재' if g in ('컬러수출', '컬러건재', '수요개발') else g
        d = det.get((con, str(seq)))
        if d and not d.get('CLR_SER_NO_TOP') and clr.get(con):
            d = dict(d, CLR_SER_NO_TOP=clr[con]['CLR_SER_NO_TOP'], ORD_CTV_THK=clr[con].get('ORD_CTV_THK') or d.get('ORD_CTV_THK'),
                     ORD_CTV_WDT=clr[con].get('ORD_CTV_WDT') or d.get('ORD_CTV_WDT'), ORD_USG_CD=d.get('ORD_USG_CD') or clr[con].get('ORD_USG_CD'))
        if g == '컬러건재':                                       # 소재 발주엔 색이 거의 없어(10/20: 669건 중 21건) 계획재·주문재를 못 나눔 → 한 줄
            return '컬러건재'
        if g == '컬러수출':
            if d and str(d.get('ORD_USG_CD') or '').startswith('CC'):
                return '건재수출'
            if not d:
                return '컬러수출(세부 대기)'
            return '가전수출' if con_export(con, d.get('DOM_CLS') or dom.get(str(con))) else '가전내수'
        return g if g in ('수요개발',) else g
    ask = {(r['RAW_PUR_NO'], str(r['RAW_PUR_SEQ'])): r for r in _rows(T, 'snap_raw_ask')}
    po = {f"{k[0]}-{k[1]}": grp('G' if str(r.get('RAW_GRP')) in ('F', 'H', 'T', 'N', 'Y') else 'C', r.get('CON_NO'), r.get('CON_SEQ')) for k, r in ask.items()}
    recv = defaultdict(float)
    for r in _rows(T, 'snap_raw_ent'):
        d = str(r.get('REAL_ENT_DT') or r.get('ENT_DT') or '')
        if len(d) != 8 or d < d0.replace('-', '') or str(r.get('RAW_SUP_CPY') or '') == 'A1' or r.get('REAL_ENT_YN') == 'N':
            continue
        if r.get('PLT_CLS') == 'G' and str(r.get('RAW_GRP')) == 'N':     # 도금용 SUS — 소재 그룹별 보기(matRecv 화면)와 같게 뺌(계획 대상 아님)
            continue
        a = ask.get((r.get('RAW_PUR_NO'), str(r.get('RAW_PUR_SEQ'))))
        g = grp(r.get('PLT_CLS'), a.get('CON_NO'), a.get('CON_SEQ')) if a else '기타(발주 없음)'
        recv[f"{r.get('PLT_CLS')}|{g}|{d[:4]}-{d[4:6]}-{d[6:]}"] += f(r.get('RAW_ENT_WGT')) / 1000
    return {'recv': {k: round(v, 1) for k, v in sorted(recv.items())}, 'po': po}


def stock_roll(T, R2, pb, gmp=None):
    """재고 추이를 매일 다시 굴림(2026-10-14 사용자: 가동 계획처럼 재고 추이도 매일 롤링):
    출발 = 어제 말 실제 재고(판매생산속보 원천 표, 그룹별) → 이후 날마다 + 생산(도금 = 오늘 아침 재계획, 컬러 = 확정 통합 계획) − 판매(확정 통합 계획의 하루 출고)
    → 주말(일요일)·12/31 값. 지난 주말은 실제 값"""
    rb = (pb or {}).get('stockRollBase') or {}
    out, weeks = rb.get('outDay'), rb.get('weeks')
    if not out or not weeks:
        return None
    act = defaultdict(dict)
    for d, k, t in stock_daily(T):
        if k.startswith('g:'):
            act[k[2:]][d] = t
    if not act:
        return None
    last = min(max(v) for v in act.values())
    d0 = D(rb.get('d0') or '2026-10-01')
    prod = defaultdict(float)
    for r in (R2 or {}).get('rows', []):
        if r[0] > last and PLAN_GROUP.get(r[3]):
            prod[(r[0], PLAN_GROUP[r[3]])] += f(r[4])
    cprod, IW = None, None                                       # 11/7 점검: 컬러 생산 = 지금 통합 계획(방금 만든 work/integrated_web.json) — 기준 파일은 11/2 판이라 컬러건재 11/5~30 이 1,601t 많았음
    try:
        _w = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'work', 'integrated_web.json')
        if os.path.exists(_w):
            cprod = defaultdict(float)
            IW = json.load(open(_w, encoding='utf-8'))
            for x in IW.get('color') or []:
                for g_, t_ in (x.get('g') or {}).items():
                    if COLOR_GROUP.get(g_):
                        cprod[(x['d'], COLOR_GROUP[g_])] += f(t_)
    except Exception:
        cprod = None
    if IW:                                                       # 11/10 총점검: 출고(자가재 = 컬러 투입)도 지금 통합 계획에서 — 기준 파일(11/2 판)을 써서 자가재 월말 예상이 수주 관제와 591t 달랐음
        _o = (((IW.get('variants') or {}).get(IW.get('rec')) or (IW.get('variants') or {}).get('V1') or {}).get('outDay'))
        if _o and set(_o) >= set(out):
            out = _o
    if cprod:
        _m = (D(last) + dt.timedelta(days=1)).isoformat()[:7]
        _af = ((gmp or {}).get('_after') or {}).get(_m) or {}     # 이번 달 남은 컬러 생산 = 컬러 롤링(홈 그룹 표·수주 관제와 같은 값) — 날짜 모양은 통합 계획, 크기만 맞춤
        _sum = defaultdict(float)
        for (d, g), t in cprod.items():
            if d > last and d[:7] == _m:
                _sum[g] += t
        for (d, g), t in cprod.items():
            if d > last:
                k_ = _af[g] / _sum[g] if d[:7] == _m and _af.get(g) is not None and _sum.get(g, 0) > 0 else 1.0
                prod[(d, g)] += t * k_
    else:
        for k, t in (pb.get('groupPlanDaily') or {}).items():
            d, g = k.split('|', 1)
            if d > last and g.startswith('C'):
                prod[(d, g)] += f(t)
    # 이번 달 남은 출고 = 속보 월차 − 실적(그룹별) — 계획 출고를 날마다 그대로 빼면 출하가 밀리거나 앞선 만큼이 틀림(10/21: 자동차는 일정의 122% 출하했는데 월말 −1.3천t 로 나옴).
    # 날짜별 모양(MES 월중 출하 분포)은 그대로 두고 크기만 맞춤. 다음 달부터는 계획 출고 그대로
    SR = salesrpt.summary(T['snap_salesrpt']) if T.get('snap_salesrpt') else {}
    shp = {x['name']: x for x in SR.get('ship', [])}
    nm_last = (D(last) + dt.timedelta(days=1)).isoformat()[:7]
    prof = ship_profile(T)
    res, days, outA = {}, {}, {}
    for g, o in out.items():
        if last not in act.get(g, {}):
            continue
        sr_g = shp.get(SHIP_NAME.get(g))
        m0p = (D(last[:8] + '01') - dt.timedelta(days=1)).isoformat()
        if sr_g and g.startswith('G') and m0p in act.get(g, {}):         # 11/7 점검: 이달 출고 = 재고 변화(월초 실재고 + 그 사이 생산 실적 − 오늘 실재고). 속보 실적은 도금수출이 선적일 기준(11/1~4 95t vs 재고 감소 3,017t)이라 두 번 빼던 것
            pa = sum(f(r[4]) for r in (R2 or {}).get('rows', []) if last[:8] + '01' <= r[0] <= last and PLAN_GROUP.get(r[3]) == g)
            sr_g = dict(sr_g, actual=max(0.0, act[g][m0p] + pa - act[g][last]))
        o2 = plan_out(g, [f(v) for v in o], d0, last, sr_g, prof.get(g))
        outA[g] = [round(v, 1) for v in o2]
        s, ser = act[g][last], {}
        for i, ot in enumerate(o2):
            d = (d0 + dt.timedelta(days=i)).isoformat()
            if d <= last:
                ser[d] = act[g].get(d)
                continue
            s += prod[(d, g)] - ot
            ser[d] = round(s)
        res[g] = [ser.get(w) for w in weeks]
        days[g] = [ser.get((d0 + dt.timedelta(days=i)).isoformat()) for i in range(len(o))]   # 가동 캘린더 제품 재고 줄(일별, 지난 날 = 실제)
    sa = {d: t for d, k, t in stock_daily(T) if k == '도금 제품(자가재)'}   # 11/8 사용자: 자가재도 출발 = 판생 속보 실제(11/4 7,226t) — 통합 계획 값(9월말 기초 8,040t 에서 굴린 8.9천t)이 아니라
    ps = defaultdict(float)
    for rows_ in (((IW or {}).get('variants') or {}).get('V1') or {}).get('self', {}).values():   # 계획 자가재 일별 재고(AZ·MAC·AL 합) — 실제와의 차이만큼 옮겨 이후 흐름(도금 생산 − 컬러 투입)은 계획 그대로
        y_, pm = d0.year, 0
        for r in rows_:
            mm = int(str(r[0])[:2])
            y_, pm = (y_ + 1 if mm < pm else y_), mm
            ps[f'{y_}-{r[0]}'] += f(r[3])
    if last in sa and last in ps and days:
        off, n_ = sa[last] - ps[last], max(len(v) for v in days.values())
        ser = {(d0 + dt.timedelta(days=i)).isoformat(): None for i in range(n_)}
        for d in ser:
            ser[d] = sa.get(d) if d <= last else (round(ps[d] + off) if d in ps else None)
        res['G자가재'], days['G자가재'] = [ser.get(w) for w in weeks], list(ser.values())
    # 11/10 총점검: 이번 달 남은 생산·출고·월말 예상을 한 곳에서 — 수주 관제 재고 표가 같은 값을 읽음(예전엔 따로 계산해 컬러수출 679t·자가재 591t 달랐음)
    import calendar as _cal
    nx = D(last) + dt.timedelta(days=1)
    mend = dt.date(nx.year, nx.month, _cal.monthrange(nx.year, nx.month)[1]).isoformat()
    mon = {}
    for g, ser_ in days.items():
        i1 = (D(mend) - d0).days
        if not (0 <= i1 < len(ser_)) or ser_[i1] is None or last not in act.get(g, {}) and g != 'G자가재':
            continue
        b_ = sa.get(last) if g == 'G자가재' else act[g][last]
        if b_ is None:
            continue
        pr_ = sum(t for (d, gg), t in prod.items() if gg == g and last < d <= mend)
        mon[g] = {'begin': round(b_), 'prod': round(pr_), 'out': round(b_ + pr_ - ser_[i1]), 'end': ser_[i1]}
    return {'asOf': last, 'weeks': weeks, 'v': res, 'd0': d0.isoformat(), 'days': days, 'out': outA, 'month': {'ym': mend[:7], 'to': mend, 'g': mon}}


SPREAD = ('G국내', 'G자동차', 'C건재', 'C수출', 'C수요')     # 국내·컬러 출고는 날마다 나감 — 판매계획 납기(월말)에 한꺼번에 몰아 두면 월말 하루 수천 t 로 보임(10/21 사용자 지적)


SHIP_DEPT = {'도금판매그룹': 'G국내', '도금수출그룹': 'G수출', '자동차강판판매그룹': 'G자동차', '컬러수출그룹': 'C수출', '컬러건재판매그룹': 'C건재'}


def ship_profile(T):
    """MES 판매 출고(1300) 월중 분포 — 그룹별 {월말 기준 칸: 비중}. 칸 = 날짜(1 ~ 말일−7), 말일 = 31, 말일−1 = 30 …(달마다 말일 정렬).
    완결된 달만(이번 달 제외). tools/integrated_web.ship_profile 과 같은 정의"""
    t = T.get('ship')
    if not t or not t.get('rows'):
        return {}
    I = t['columns'].index
    last = max(str(r[I('OUT_DT')]) for r in t['rows'])[:7]
    prof = defaultdict(lambda: defaultdict(float))
    for r in t['rows']:
        g, d = SHIP_DEPT.get(r[I('DEPT')]), str(r[I('OUT_DT')])
        if not g or str(r[I('OUT_RSN_CD')]) != '1300' or d[:7] >= last:
            continue
        nd = calendar.monthrange(int(d[:4]), int(d[5:7]))[1]
        k = int(d[8:10]) if int(d[8:10]) <= nd - 6 else 31 - (nd - int(d[8:10]))
        prof[g][k] += f(r[I('WGT')])
    return {g: {k: v / sum(c.values()) for k, v in c.items()} for g, c in prof.items() if sum(c.values()) > 0}


def plan_out(g, o, d0, last, sr, prof=None):
    """그룹 g 의 날짜별 계획 출고(o, d0 부터) 다듬기 — 재고 추이·가동 캘린더 출하 줄이 같은 값을 씀.
    · 이번 달 남은 날: 합 = 속보 월차 − 실적(그룹별). 국내·컬러는 남은 날에 고르게, 도금수출은 선적창 모양(계획 출고 비례) 유지
    · 다음 달부터: 국내·컬러는 그 달 합을 날마다 고르게, 도금수출은 계획 출고 그대로"""
    n = len(o)
    ds = [(d0 + dt.timedelta(days=i)).isoformat() for i in range(n)]
    o = list(o)
    months = sorted({d[:7] for d in ds})
    for m in months:
        idx = [i for i in range(n) if ds[i][:7] == m and ds[i] > last]
        if not idx:
            continue
        tot = sum(o[i] for i in idx)
        if m == last[:7] and sr and sr.get('month'):
            want = max(0.0, sr['month'] - sr['actual'])
        else:
            want = tot
        if g in SPREAD or tot <= 0:
            # 국내·컬러: 남은 날에 MES 월중 출하 패턴(최근 완결 달, 말일 정렬) 비중으로 나눔 — 11/5 사용자 '출하패턴 반영해'(10/21 고르게 펴기에서 바꿈). 패턴 없으면 고르게
            y_, m_ = int(m[:4]), int(m[5:7])
            nd = calendar.monthrange(y_, m_)[1]
            kk = lambda day: day if day <= nd - 6 else 31 - (nd - day)
            w = [(prof or {}).get(kk(int(ds[i][8:])), 0.0) for i in idx]
            sw = sum(w)
            for i, wi in zip(idx, w):
                o[i] = want * wi / sw if sw > 0 else want / len(idx)
        else:
            k = want / tot
            for i in idx:
                o[i] *= k
    return o



def status(T, coils, auto, pages, run_at):
    def last_of(name, key):
        rs = T.get(name)
        if not rs:
            return None
        i = rs['columns'].index(key) if key in rs['columns'] else None
        v = [str(r[i])[:10] for r in rs['rows'] if i is not None and r[i]]
        return max(v) if v else None
    SR = salesrpt.summary(T['snap_salesrpt']) if T.get('snap_salesrpt') else None
    feeds = [
        {'name': '도금 생산 실적(코일)', 'last': max((str(c['day']) for c in coils), default=None), 'n': len(coils or [])},
        {'name': '컬러 생산 실적', 'last': last_of('color_prod', 'PRD_DT'), 'n': len((T.get('color_prod') or {}).get('rows', []))},
        {'name': '판매생산속보(진도·재고)', 'last': (SR or {}).get('asOf', '')[:10] or None},
        {'name': '출하', 'last': last_of('ship', 'OUT_DT')},
        {'name': '소재재고List(컬러)', 'last': last_of('snap_mat_stock_cc', '입고일')},
        {'name': '실제 재고(속보 원천 표)', 'last': (lambda v: f'{v[:4]}-{v[4:6]}-{v[6:8]}' if v else None)(max((str(r.get('WRK_DT')) for r in _rows(T, 'stock_rpt9')), default=None))},
        {'name': '재고현황(월말)', 'last': (lambda m: f'{m[:4]}-{m[4:]}' if m else None)(max((str(r[0]) for r in (T.get('snap_stock') or {}).get('rows', [])), default=None))},
    ]
    return {'app': 'cgl-status', 'runAt': run_at, 'ok': True, 'auto': {k: auto.get(k) for k in ('actualTo', 'replanned', 'optimal', 'notes', 'newCoils')} if auto else None,
            'feeds': feeds, 'pages': pages}


# ------------------------------------------------------------------ 전체
def f3_month_plan(master):
    """그룹 월 계획 = TF 월 생산량(11/9 회의 F3: P = 판매 + 목표 − 기초, F9: 기초 = MES 재고현황 전달 말, F1: 한 달 동안 고정).
    master = 3개월 계획(work/integ_prep_3m.json masters.V1). 도금 판매재는 편성용으로 달 중간 출하 진도만큼 다시 맞춘 값(prod, mes_gap)이 들어 있어
    그 전 값(prodF3 — 예전 파일은 prod + rebase)을 씀 → 같은 달이면 매일 같은 값. 포털 그룹 표·관제판·통합 계획 plan 행·계획 점검 G4 가 이 함수 하나를 씀.
    반환 {그룹: [{month, prod, note}]} — note = 0 인 사유(재고가 목표보다 많음)"""
    out = {}
    for g, rows in ((master or {}).get('plan') or {}).items():
        L = out[g] = []
        for x in rows:
            p = x.get('prodF3')
            if p is None:
                p = (x.get('prod') or 0) + (x.get('rebase') or 0)
            s, tg = x.get('sales') or 0, x.get('target') or 0
            b = (x.get('end') or 0) - p + s                      # 기초 = 기말 − 생산 + 판매(LP 행, 다시 맞추기 전 생산)
            note = None
            pure = max(0.0, s + tg - b)                           # 11/10 사용자(추천안 승인): 월 계획 = F3 공식값 그대로. 3개월 계획이 다음 달 정기수리·능력 부족에 대비해 미리 만드는 몫(선생산)은 월 계획에 넣지 않고 사유로만
            if p - pure > 0.5:
                note = f"월 계획 {pure:,.0f}t(판매 {s:,.0f} + 목표 {tg:,.0f} − 기초 {b:,.0f}) · 계획 생산은 다음 달 정기수리·능력 부족 대비 선생산 {p - pure:,.0f}t 포함 {p:,.0f}t"
                p = pure
            if p < 0.5 and s > 0:
                note = (f"계획 0 — 판매 {s:,.0f} + 목표 {tg:,.0f} − 기초 {b:,.0f}(전달 말 MES 재고) = {s + tg - b:,.0f}t"
                        + (' · 계획재 과재고(목표의 2배 넘음, 깔지 여부 B1 보류)' if g == 'C건재' else ' · 재고가 목표보다 많음'))
            L.append({'month': x.get('month'), 'prod': p, 'note': note})
    return out


def month_plan(T, gpd, SR, R2=None, cur=None, gmp=None):
    """달별 그룹 월 계획(11/3 사용자 '왜 기준이 다르냐' — 모든 달을 이번 달과 같은 기준으로):
    생산 = 확정 계획 일별 합(이번 달 관제와 같은 값), 출하 = 판매생산속보 월계획 — 지난 달은 그 달 마지막 속보(salesrpt_hist), 이번 달은 오늘 속보,
    속보가 아직 없는 다음 달은 TF 판매계획(월 물량 LP 판매)로 채우고 출처를 적음"""
    from . import salesrpt as S_
    out = defaultdict(lambda: defaultdict(dict))
    for k, v in gpd.items():
        m, g = k[:7], k.split('|')[-1]
        out[m][g]['prod'] = round(out[m][g].get('prod', 0) + v)
    if R2 and R2.get('rows') and cur:                          # 도금 이번 달·다음 달 = 최신 재계획(관제 이번 달과 같은 값), 지난 달 = 그 달 확정 계획
        rp = defaultdict(float)
        for r in R2['rows']:
            g = PLAN_GROUP.get(r[3])
            if g and r[0][:7] >= cur:
                rp[(r[0][:7], g)] += f(r[4])
        for m in {m for m, _ in rp}:
            for g in [g for g in out[m] if g.startswith('G')]:
                out[m][g]['prod'] = 0
        for (m, g), t in rp.items():
            out[m][g]['prod'] = round(t)
    for m, x in ((k, v) for k, v in (gmp or {}).items() if not k.startswith('_')):   # 11/10 점검(11/9 회의 F3: 그룹별 월 계획 = TF 월 생산량 P = 판매 + 목표 − 기초): 이번 달부터 이 값 — 관제판·그룹 표·칩이 33,985/39,096/41,790 세 값이던 것 하나로
        if cur and m < cur:
            continue
        for g, t in x.items():
            out[m][g]['prod'] = round(t)
            out[m][g]['prodSrc'] = 'TF 월 생산량'
            nt = ((gmp.get('_note') or {}).get(m) or {}).get(g)
            if nt:
                out[m][g]['prodNote'] = nt
    snaps = {}
    h = T.get('salesrpt_hist')
    if h and h.get('rows'):
        c = h['columns']
        by = defaultdict(list)
        for r in h['rows']:
            by[str(r[0])].append(r[1:])
        for a in sorted(by):                                   # 달마다 마지막 속보
            snaps[a[:7]] = (a, {'columns': c[1:], 'rows': by[a]})
    if SR:
        snaps[str(SR.get('asOf', ''))[:7]] = (SR.get('asOf'), None)
    for m, (a, tb) in snaps.items():
        sr = SR if tb is None else S_.summary(tb)
        for x in (sr or {}).get('ship', []):
            g = SHIP_GROUP.get(x['name'])
            if g:
                out[m][g]['ship'] = round(x['month'])
                out[m][g]['shipSrc'] = f"판생속보 {str(a)[5:10].replace('-', '/')}"
    return {m: dict(v) for m, v in sorted(out.items())}


def sr_prod(T, SR):
    """달별 판생속보 생산 월차계획 합 {달: {'G': 도금 계, 'C': 컬러 계}} — 지난 달은 그 달 마지막 속보(salesrpt_hist), 이번 달은 오늘 속보.
    11/18 결정전달 6: 관제판 4분기 전망 분모 = 02 현황과 같은 판생 계획(TF 그룹 합 아님), 지난 달 컬러 분모도 이 값"""
    from . import salesrpt as S_
    snaps = {}
    h = T.get('salesrpt_hist')
    if h and h.get('rows'):
        c = h['columns']
        by = defaultdict(list)
        for r in h['rows']:
            by[str(r[0])].append(r[1:])
        for a in sorted(by):
            snaps[a[:7]] = S_.summary({'columns': c[1:], 'rows': by[a]})
    if SR:
        snaps[str(SR.get('asOf', ''))[:7]] = SR
    out = {}
    for m, sr in snaps.items():
        for x in (sr or {}).get('prod', []):
            if x['line'] in ('도금 계', '컬러 계') and x.get('month'):
                out.setdefault(m, {})[{'도금 계': 'G', '컬러 계': 'C'}[x['line']]] = round(x['month'])
    return dict(sorted(out.items()))


def groups(T, coils, SR, gpd, g_last, R2=None, gmp=None):
    """마케팅 그룹별 이번 달 생산(월 계획·실적)과 출하(판매생산속보 월차·일정누계·실적).
    날짜까지의 계획 누계는 넣지 않음 — 계획 모델은 마감일만 지키면 부서를 어느 날 만들지 임의라 그룹별 일자 비교는 의미가 없음.
    대신 after = 실적 다음 날부터 이달 말까지 남은 계획(도금 = 최신 재계획 R2, 없으면 확정 계획 / 컬러 = 편성) → 월말 예상 = 실적 + after
    생산 실적: 도금 = MES 코일(더미 제외) 판매그룹, 컬러 = MES 컬러 생산 DEPT. 계획: 도금 = 확정 V1 일별, 컬러 = 통합 계획 편성"""
    cp = T.get('color_prod')
    c_last = max((r[cp['columns'].index('PRD_DT')] for r in cp['rows']), default=None) if cp and cp['rows'] else None
    act = defaultdict(float)
    for c in coils or []:
        if not c.get('dummy') and g_last and str(c['day'])[:7] == g_last[:7] and str(c['day']) <= g_last:
            g = COIL_GROUP.get(c.get('dept'))
            if g:
                act[g] += f(c['t'])
    if cp and c_last:
        I = cp['columns'].index
        if 'DEPT' in cp['columns']:
            for r in cp['rows']:
                g = CPROD_GROUP.get(r[I('DEPT')])
                if g and r[I('PRD_DT')][:7] == c_last[:7] and r[I('PRD_DT')] <= c_last:
                    act[g] += f(r[I('PDT_WGT')]) / 1000
    ship = {SHIP_GROUP[x['name']]: dict(x) for x in (SR or {}).get('ship', []) if x['name'] in SHIP_GROUP}
    try:                                                       # 11/10 점검(11/9 회의 F8: 출하 실적 = MES 영업매출 1300): 속보 출하 누계 대신 MES 판매 출고(속보와 같은 기간 = 속보일 전날까지)
        rep = (D(SR['asOf']) - dt.timedelta(days=1)).isoformat() if SR and SR.get('asOf') else None
    except (TypeError, ValueError):
        rep = None
    if rep and T.get('ship'):
        sm = defaultdict(float)
        for r in _rows(T, 'ship'):
            g, d = SHIP_DEPT.get(r.get('DEPT')), str(r.get('OUT_DT') or '')[:10]
            if g and str(r.get('OUT_RSN_CD')) == '1300' and d[:7] == rep[:7] and d <= rep:
                sm[g] += f(r.get('WGT')) / 1000
        for g, x in ship.items():   # 11/17 사용자 'MES 랑 같은 숫자'(02 현황 = 판생속보 3.출하현황): 모든 화면 출하 실적 = 판생속보 누계, MES 영업매출 1300 은 mes 로 참고
            x['srActual'], x['mes'] = x['actual'], sm.get(g, 0.0)
    ship_due(T, rep, ship)
    out = []
    for key, name, pl in GROUPS:
        last = g_last if pl == 'G' else c_last
        if not last:
            continue
        m = last[:7]
        mon = sum(v for k, v in gpd.items() if k.endswith('|' + key) and k[:7] == m)
        if pl == 'G' and R2 and R2.get('rows'):                # 11/3 사용자 '181%가 맞냐': 월 계획도 남은 계획과 같은 최신 재계획에서(10월 확정안 월 계획 + 오늘 재계획 남은 몫이 섞였었음)
            # 11/9: 월 계획을 재계획에서 뽑으면 재계획 = 실적 + 남은 계획이라 월말 예상이 늘 100% → 월 계획 = 확정 계획(기준 계획), 남은 몫만 재계획
            mon = sum(v for k, v in gpd.items() if k.endswith('|' + key) and k[:7] == m) or sum(f(r[4]) for r in R2['rows'] if r[0][:7] == m and PLAN_GROUP.get(r[3]) == key)
            after = sum(f(r[4]) for r in R2['rows'] if last < r[0] and r[0][:7] == m and PLAN_GROUP.get(r[3]) == key)
            src = '재계획'
        else:
            after = sum(v for k, v in gpd.items() if k.endswith('|' + key) and k[:7] == m and k[:10] > last)
            src = '기준 계획' if pl == 'G' else '편성'
        if gmp and (gmp.get(m) or {}).get(key) is not None:    # 11/10 점검(F3): 월 계획 = TF 월 생산량(그룹 표 '필요 생산'과 같은 값)
            mon, src = gmp[m][key], src + ' · 월 계획 TF'
            if pl == 'C' and ((gmp.get('_after') or {}).get(m) or {}).get(key) is not None:
                after, src = gmp['_after'][m][key], '롤링 · 월 계획'      # 컬러: 월 계획·남은 양 = 컬러 롤링(가동 현황과 같은 값)
        sh = ship.get(key)
        if not mon and not act[key] and not sh:
            continue
        nt = (((gmp or {}).get('_note') or {}).get(m) or {}).get(key)
        out.append({'key': key, 'name': name, 'pl': pl, 'prod': {'asOf': last, 'month': round(mon), 'actual': round(act[key]), 'after': round(after), 'afterSrc': src, **({'note': nt} if nt else {})},
                    'ship': {'asOf': (SR or {}).get('asOf'), 'month': round(sh['month']), 'sched': round(sh['sched']), 'actual': round(sh['actual']), 'srActual': round(sh.get('srActual', sh['actual'])), **({'mes': round(sh['mes'])} if sh.get('mes') is not None else {}),
                             **({'due': sh['due'], 'dueTo': rep, 'dueBy': sh.get('dueBy')} if sh.get('due') is not None else {}), **({'dueExp': sh['dueExp'], 'exp': round(sh['exp'])} if sh.get('dueExp') is not None else {})} if sh else None})
    return out


def lines_now(T, coils, SR, R2, g_last):
    """라인 타일: 판매생산속보 월차·일정누계·실적누계(공식) + 이번 달 일 생산(MES) + 도금 현재 강종·다음 전환(최신 계획)"""
    prod = {x['line']: x for x in (SR or {}).get('prod', []) if x['line'] in ('1CGL', '2CGL') + tuple(CCL)}
    day, fam = defaultdict(float), defaultdict(lambda: defaultdict(float))
    for c in coils or []:
        if not c.get('dummy'):
            day[(str(c['day']), c['line'])] += f(c['t'])
            if str(c['day']) == g_last:
                fam[c['line']][c.get('fam')] += f(c['t'])
    cp = T.get('color_prod')
    c_last = None
    if cp and cp['rows']:
        I = cp['columns'].index
        c_last = max(r[I('PRD_DT')] for r in cp['rows'])
        for r in cp['rows']:
            day[(r[I('PRD_DT')], r[I('LINE')])] += f(r[I('PDT_WGT')]) / 1000
    nxt = {}
    for c in sorted((R2 or {}).get('cal', []), key=lambda c: c['date']):
        ev = str(c.get('event') or '')
        if g_last and c['date'] > g_last and c['line'] not in nxt and ('M/C' in ev or 'S/D' in ev or '정기' in ev):
            nxt[c['line']] = [c['date'], ev.split(' · ')[0]]
    if c_last:                                                 # 11/10 점검: 컬러 '다음 일정'이 비거나(3CCL 11/10 Test) 청소를 건너뜀 → 휴지 계획 전 종류(청소·Test·샘플 포함), 이어지는 같은 휴지는 기간으로
        KNC = {'plan': '계획휴지', 'sd': 'S/D', 'repair': '수리', 'clean': '청소', 'test': '시험', 'sample': '샘플'}
        its = sorted((it for it in (load_base('color_downtime.json') or {}).get('items', []) if it.get('kind') in KNC and str(it['date']) > c_last), key=lambda it: it['date'])
        for l in CCL:
            L_ = [it for it in its if it['line'] == l]
            if not L_:
                continue
            a0, e0 = L_[0], L_[0]['date']
            same = {it['date'] for it in L_ if it['kind'] == a0['kind']}      # 같은 날 다른 휴지(11/17 샘플+수리)가 있어도 기간이 끊기지 않게
            while (D(e0) + dt.timedelta(days=1)).isoformat() in same:
                e0 = (D(e0) + dt.timedelta(days=1)).isoformat()
            mn = round(f(a0.get('min')))
            nxt[l] = [a0['date'], f"{KNC[a0['kind']]} " + (f"{int(e0[5:7])}/{int(e0[8:])}까지" if e0 != a0['date'] else '종일' if mn >= 1380 else f'{mn}분')]
    try:                                                      # 11/11 사용자 '도금 부하 t/hr 은 26년 전체 기준으로 통일': 도금 라인 t/h = 2026.1~ 코일 실적(tools/cg_rate_learn, 엔진 속도와 같은 기간) — 최근 며칠 값은 tphRecent
        _rt = json.load(open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'cg_rate_table.json'), encoding='utf-8'))
        TPH26 = {k: round(v * 60, 1) for k, v in (_rt.get('avg') or {}).items()}
    except Exception:
        TPH26 = {}
    out = []
    for l in ('1CGL', '2CGL') + tuple(CCL):
        last = g_last if l.endswith('CGL') else c_last
        if not last:
            continue
        ds = [(D(last) - dt.timedelta(days=i)).isoformat() for i in range(D(last).day - 1, -1, -1)]   # 이번 달 1일 ~ 마지막 날(월차와 같은 기간, 2026-10-14 사용자: 무조건 월 단위로 시작)
        x = prod.get(l) or {}
        fm = fam.get(l)
        out.append({'line': l, 'pl': 'G' if l.endswith('CGL') else 'C', 'asOf': last, 'month': x.get('month'), 'sched': x.get('sched'), 'actual': x.get('actual'), 'src': x.get('src'),
                    'tph': (TPH26.get(l) or x.get('tph')) if l.endswith('CGL') else x.get('tph'), 'tphRecent': x.get('tph'), 'days': [[d, round(day[(d, l)])] for d in ds],
                    'fam': max(fm, key=fm.get) if fm else None, 'next': nxt.get(l)})
    return out


WO_LINE_G = {'A': '1CGL', 'B': '2CGL'}
WO_LINE_C = {'X': '1CCL', 'Y': '2CCL', 'Z': '3CCL', 'W': '4CCL'}


def work_orders(T, coils, R2, g_last, today=None):
    """MES 작업지시 vs 최신 계획.
    도금(SSCH.PF_CG_WORK_FIN): 미완료 지시 코일의 강종 = 생산번호 셋째 글자(지난 코일 기록에서 글자→강종을 매일 다시 뽑음),
      톤 = 최근 코일 평균 무게로 추정. 계획의 향후 3일 강종에 없는 강종이 대기 중이면 '불일치'.
    컬러(SSCH.PF_CC_WORK_ORD): 라인별 앞으로 7일 작업 예정 톤(지시 예정 중량, kg)과 확정 비율"""
    out = {}
    wg = _rows(T, 'snap_wo_cg')
    if wg and coils:
        key = defaultdict(Counter)
        wt = defaultdict(list)
        for c in coils:
            p_ = str(c.get('prd') or '')
            if len(p_) >= 3 and c.get('alloy'):
                key[p_[2]][c['alloy']] += 1
            if not c.get('dummy') and c.get('alloy'):
                wt[(c['line'], c['alloy'])].append(f(c['t']))
        k2a = {k: v.most_common(1)[0][0] for k, v in key.items()}
        fam_of = lambda a: 'AL' if a in ('AL', 'AL-STS', 'AL-LG') else a
        cal = {(c['date'], c['line']): c.get('fam') for c in (R2 or {}).get('cal', [])}
        lines = []
        for code, l in WO_LINE_G.items():
            pend = [w for w in wg if w['LINE_CLS'] == code and w['FIN_YN'] != 'Y']
            q = Counter()
            for w in pend:
                q[k2a.get(str(w['PRD_NO'] or '')[2:3], '?')] += 1
            tons = {a: round(n * (sum(wt[(l, a)][-200:]) / len(wt[(l, a)][-200:]) if wt[(l, a)] else 0)) for a, n in q.items()}
            nxt = [(D(g_last) + dt.timedelta(days=i)).isoformat() for i in (1, 2, 3)] if g_last else []
            plan = [[d, cal.get((d, l))] for d in nxt]
            pf = {x[1] for x in plan if x[1]}
            bad = sorted({fam_of(a) for a in q if a != '?' and fam_of(a) not in pf}) if pf else []
            ds = sorted({w['WRK_DRT_DT'] for w in pend})
            lines.append({'line': l, 'coils': len(pend), 'byAlloy': [[a, n, tons.get(a, 0)] for a, n in q.most_common()],
                          'issued': [ds[0], ds[-1]] if ds else None, 'plan': plan, 'mismatch': bad})
        out['plating'] = {'asOf': max((w['WRK_DRT_DT'] for w in wg), default=None), 'lines': lines, 'keyMap': k2a}
    wc = _rows(T, 'snap_wo_cc')
    if wc:
        base = max(str(w['WRK_DRT_DT']) for w in wc)
        d0 = D(f'{base[:4]}-{base[4:6]}-{base[6:]}')
        days = [(d0 + dt.timedelta(days=i)).strftime('%Y%m%d') for i in range(7)]
        lines = []
        for code, l in WO_LINE_C.items():
            rows = [w for w in wc if w['WRK_DRT_LINE'] == code]
            by = [round(sum(f(w['WRK_DRT_SCHE_WGT']) for w in rows if str(w['WRK_SCHE_DT']) == d) / 1000) for d in days]
            conf = sum(f(w['WRK_DRT_SCHE_WGT']) for w in rows if w['WRK_DRT_CONF'] == 'Y'); tot = sum(f(w['WRK_DRT_SCHE_WGT']) for w in rows)
            last = max((str(w['WRK_SCHE_DT']) for w in rows if w['WRK_SCHE_DT']), default=None)
            lines.append({'line': l, 'days': by, 'confRate': round(conf / tot, 2) if tot else None, 'until': f'{last[:4]}-{last[4:6]}-{last[6:]}' if last else None})
        out['color'] = {'days': [f'{d[:4]}-{d[4:6]}-{d[6:]}' for d in days], 'lines': lines, 'downConflicts': wo_down_conflicts(T, wc, today or base[:4] + '-' + base[4:6] + '-' + base[6:])}
    return out or None


def wo_down_conflicts(T, wc, today, min_t=50):
    """오늘 이후 컬러 휴지계획(수리·S/D·계획휴지, 하루 종일 — 반나절 정지는 남은 시간에 생산 가능)과 겹치는 날에 예정된 작업지시(라인·휴지 구분별).
    이미 생산이 시작된 지시(컬러 실적에 같은 주문 번호)는 남은 양의 예정일이 옛 값일 수 있어 뺌 — 실제 생산일과 예정일은 65%가 ±1일(2026-10-12 확인)"""
    started = {(r['CON_NO'], r['CON_SEQ']) for r in _rows(T, 'color_prod') or []}
    KN = {'plan': '계획휴지', 'sd': 'S/D', 'repair': '수리'}
    down_all = {(it['line'], it['date']): KN[it['kind']] for it in (load_base('color_downtime.json') or {}).get('items', [])
                if it['kind'] in KN and f(it['min']) >= 1440}
    down = {k: v for k, v in down_all.items() if k[1] >= today}
    tons = defaultdict(lambda: defaultdict(float))
    for w in wc:
        d, l = str(w.get('WRK_SCHE_DT') or ''), WO_LINE_C.get(w['WRK_DRT_LINE'])
        if len(d) == 8 and (w.get('CON_NO'), w.get('CON_SEQ')) not in started:
            iso = f'{d[:4]}-{d[4:6]}-{d[6:]}'
            if (l, iso) in down:
                tons[(l, down[(l, iso)])][iso] += f(w.get('WRK_DRT_SCHE_WGT')) / 1000
    ok = (load_base('confirmations.json') or {}).get('downConflict', [])
    conf = lambda l, k, ds: next((c for c in ok if c['line'] == l and c['kind'] == k and c['from'] <= ds[0] and ds[-1] <= c['to']), None)   # 현장 확인 끝난 휴지(같은 기간 안)
    out = []
    for (l, k), v in sorted(tons.items()):
        if sum(v.values()) >= min_t:
            c = conf(l, k, sorted(v))
            d0_, d1_ = sorted(v)[0], sorted(v)[-1]                # 11/10 점검: 휴지 기간 전체(작업지시 날짜만 적어 '수리 11/9~15' 로 읽혔음 — 실제 11/9~17)
            while (l, (D(d0_) - dt.timedelta(days=1)).isoformat()) in down_all and down_all[(l, (D(d0_) - dt.timedelta(days=1)).isoformat())] == k:
                d0_ = (D(d0_) - dt.timedelta(days=1)).isoformat()
            while (l, (D(d1_) + dt.timedelta(days=1)).isoformat()) in down_all and down_all[(l, (D(d1_) + dt.timedelta(days=1)).isoformat())] == k:
                d1_ = (D(d1_) + dt.timedelta(days=1)).isoformat()
            out.append({'line': l, 'kind': k, 'dates': sorted(v), 'span': [d0_, d1_], 't': round(sum(v.values())), 'confirmed': {'at': c['at'], 'note': c['note']} if c else None})
    return out



def week_events(today, R2, pr_all, ps, days=14):
    """홈 '2주 일정': 오늘부터 14일 — 도금 M/C·정기수리·추가정지(최신 계획), 컬러 S/D·수리·계획휴지(휴지계획),
    소재 발주 마감(소재 발주 기본값), 계획재 소재 발주 마감(계획재 캘린더). [{d, kind, text, pl}]"""
    t0 = D(today)
    t1 = (t0 + dt.timedelta(days=days - 1)).isoformat()
    ev = []
    for c in (R2 or {}).get('cal', []) or []:
        e = str(c.get('event') or '')
        if today <= c['date'] <= t1 and (e or c.get('blackout')):
            ev.append({'d': c['date'], 'kind': 'plating', 'pl': 'G', 'text': f"{c['line']} {'정기수리' if c.get('blackout') else e}"})
    dn = load_base('color_downtime.json') or {}
    KN = {'plan': '계획휴지', 'sd': 'S/D', 'repair': '수리'}
    ok = (load_base('confirmations.json') or {}).get('downConflict', [])
    for it in dn.get('items', []):
        if today <= it['date'] <= t1 and it['kind'] in KN:
            cf = any(c['line'] == it['line'] and c['kind'] == KN[it['kind']] and c['from'] <= it['date'] <= c['to'] for c in ok)   # 현장 확인 끝난 휴지
            ev.append({'d': it['date'], 'kind': 'color', 'pl': 'C', 'text': f"{it['line']} {KN[it['kind']]} {round(it['min'] / 60, 1):g}시간" + (' · 확인됨' if cf else '')})
    for x in (pr_all or {}).get('nearAll', []):
        if today <= x['deadline'] <= t1:
            ev.append({'d': x['deadline'], 'kind': 'order', 'pl': x['plant'], 'text': f"{x['mat']} {x['t']:,}t 발주"})
    for o in (ps or {}).get('orders', []):
        if today <= o['o1'] <= t1 and o['t'] - o.get('ordered', 0) >= 1:
            ev.append({'d': o['o1'], 'kind': 'plan', 'pl': 'C', 'text': f"계획재 {o['kind']} {round(o['t'] - o.get('ordered', 0)):,}t 발주"})
    seen, out = set(), []
    for e in sorted(ev, key=lambda z: (z['d'], z['kind'])):
        k = (e['d'], e['text'])
        if k not in seen:
            seen.add(k); out.append(e)
    return {'from': today, 'days': days, 'events': out}

# ------------------------------------------------------------------ 지난 날 실적 상세(계획 화면 '가동 상세' — 앞날 계획 카드와 같은 양식, 11/12 사용자)
ACT_COLS = ['grp', 'name', 'spec', 'cus', 'dst', 't', 'n', 'kind', 'sup', 'in0', 'in1', 'due', 'ship', 'con']   # 11/23 con(계약-행번) 끝에 붙임 — 판생 11월 진행 지난 날 작업 목록·담당자 찾기


def _kst_ms(v):
    """MES 일시(epoch ms) → 한국 날짜. 이상값(2100년 넘는 값 등)은 None"""
    try:
        v = float(v)
    except (TypeError, ValueError):
        return None
    if not (1.5e12 < v < 4.1e12):
        return None
    return (dt.datetime(1970, 1, 1) + dt.timedelta(milliseconds=v + 9 * 3600e3)).date().isoformat()


def act_detail(T, coils, months=2):
    """라인 × 날짜 × 계약 실적(이번 달 + 지난달): 톤 · 품명/강종 · 판매그룹 · 고객·목적지 · 소재(자가재 = 도금 생산일 / 구매 = 업체·입고일) · 납기·출항.
    도금 = MES 코일(더미 제외, plating_actual 과 같은 톤) → 생산번호 → snap_cg_ord_data(계약·소재 코일),
    컬러 = color_prod(color_actual 과 같은 톤) → 계약, 소재 코일 번호가 도금 제품 번호면 자가재(그 코일의 도금 생산일).
    구매 소재 = 계약의 소재 발주번호(snap_ord_raw_link, 앞 2자리 = 업체) → 입고 원장(snap_raw_ent) 실입고일 중 생산일 이전 마지막.
    고객 = snap_cg/cc_cus_names, 목적지 = 주문 DST/ARV_DST → snap_dst_names(없으면 선적 선명의 도착항), 납기 = 주문 UPD_DLV, 출항 = snap_c?_ship_arr"""
    G = [c for c in (coils or []) if not c.get('dummy') and f(c.get('t')) > 0]
    P = _rows(T, 'color_prod')
    lasts = [str(c['day']) for c in G] + [str(r['PRD_DT'])[:10] for r in P]
    if not lasts:
        return None
    last = max(lasts)
    y, m = int(last[:4]), int(last[5:7])
    for _ in range(months - 1):
        y, m = (y - 1, 12) if m == 1 else (y, m - 1)
    d0 = f'{y}-{m:02d}-01'
    od = {str(r['PRD_NO']): r for r in _rows(T, 'snap_cg_ord_data')}
    # 11/19: snap_cg_ord_data 는 최근 창(10/5~)이라 이번 달+지난달 첫 며칠 코일이 계약 없이 빠짐('고객 연결 95%' 5회 연속 실패) → 월별 코일·계약 표로 보충
    for n in ('snap_cg_con_09', 'snap_cg_con_10', 'snap_cg_con_recent', 'snap_cg_prod_recent'):
        for r in _rows(T, n):
            if r.get('CON_NO') and str(r.get('PRD_NO')) not in od:
                od[str(r['PRD_NO'])] = r
    ordr = {}
    for n in ('snap_cc_open_ord', 'snap_cc_open_ord__p2', 'snap_cc_open_ord__p3', 'snap_cc_open_ord__p4', 'snap_cg_due_hist', 'snap_cg_ord_full', 'snap_cc_ord_full'):
        for r in _rows(T, n):                                    # 뒤 표가 앞 표를 덮음(주문 전체 > 미결 > 납기 이력)
            ordr[(r['CON_NO'], r['CON_SEQ'])] = r
    cus = {}
    for n in ('snap_cc_cus_names', 'snap_cc_cus_names__p2', 'snap_cg_cus_names'):
        for r in _rows(T, n):
            cus[r['CON_NO']] = str(r.get('LAST_CUS_NM') or r.get('CUS_NM') or '').strip()
    dstn = {str(r['CD_VAL']): str(r['CD_NM']).strip() for r in _rows(T, 'snap_dst_names')}
    ship = {}
    for n in ('snap_cg_ship_arr', 'snap_cc_ship_arr'):
        for r in _rows(T, n):
            ship[(r['CON_NO'], r['CON_SEQ'])] = r
    link = defaultdict(list)
    for n in ('snap_ord_raw_link', 'snap_ord_raw_link__p2'):
        for r in _rows(T, n):
            if r.get('RAW_PUR_NO'):
                link[(r['CON_NO'], r['CON_SEQ'])].append((str(r['RAW_PUR_NO']), str(r.get('RAW_PUR_SEQ') or '')))
    ent = defaultdict(list)
    for r in _rows(T, 'snap_raw_ent'):
        d = _ymd(r.get('REAL_ENT_DT') or r.get('ENT_DT'))
        if d:
            ent[str(r['RAW_PUR_NO'])].append(d.isoformat())
    sn = sup_names(T)
    gday = {str(c['id']): str(c['day']) for c in coils or []}   # 도금 제품 코일 → 생산일(컬러 자가재 소재)
    for n in ('snap_cg_prod_recent', 'snap_cg_con_recent', 'snap_cg_con_10', 'snap_cg_con_09', 'snap_cg_con_08', 'snap_cg_con_07'):   # 9월 이전 도금 코일(MES 원자료 창 밖)
        for r in _rows(T, n):
            d = _ymd(r.get('PRD_ACCNT_DT') or r.get('PRD_DT'))
            if d:
                gday.setdefault(str(r['PDT_NO']), d.isoformat())

    def head(k):
        o = ordr.get(k) or {}
        s = ship.get(k) or {}
        dc = str(o.get('DST_CD') or o.get('ARV_DST_CD') or '')
        dst = dstn.get(dc) or ''
        if not dst and s.get('SHP_NM'):                          # 선명 'SPIRIT OF TOKYO_ANTWERP 1순_CFR_10' → ANTWERP
            p = str(s['SHP_NM']).split('_')
            dst = p[1].split(' ')[0] if len(p) > 1 else ''
        return cus.get(k[0], ''), dst, _kst_ms(o.get('UPD_DLV') or o.get('ORD_DLV_DAT')), _kst_ms(s.get('DEPT_PORT_DAT'))

    def buy(k, d):
        """구매 소재: 업체 이름 · 생산일 이전 마지막 실입고일(입고 원장 범위 밖이면 None)"""
        L = [p for p in link.get(k, []) if not p[0].startswith('A1')]
        if not L:
            return None, None
        best = None
        for p, _ in L:
            ds = [x for x in ent.get(p, []) if x <= d]
            if ds and (best is None or max(ds) > best[1]):
                best = (p, max(ds))
        p = best[0] if best else L[0][0]
        return sn.get(p[:2]) or p[:2], best[1] if best else None

    acc = {}
    def put(d, l, k, base, t, ins):
        gk = (d, l) + k + (base['kind'],)
        z = acc.get(gk)
        if not z:
            cu, dst, due, sh = head(k)
            z = acc[gk] = dict(base, cus=cu, dst=dst, due=due, ship=sh, t=0.0, n=0, ins=[])
        z['t'] += t; z['n'] += 1
        if ins:
            z['ins'].append(ins)
    for c in G:
        d = str(c['day'])
        if d < d0:
            continue
        o = od.get(str(c.get('prd'))) or {}
        k = (o.get('CON_NO') or '', o.get('CON_SEQ') or '')
        sup, ed = buy(k, d) if k[0] else (None, None)
        nm = f"{c.get('pname') or ''} {c.get('alloy') or c.get('fam') or ''}".strip()
        spec = f"{f(c.get('thick')):g}×{f(c.get('width')):g}" if c.get('thick') else ''
        put(d, c['line'], k, {'grp': str(c.get('cls') or c.get('dept') or ''), 'name': nm, 'spec': spec, 'kind': '구매' if sup else '', 'sup': sup or '', 'con': f'{k[0]}-{k[1]}' if k[0] else ''},
            f(c['t']), ed)
    grp = color_grouper(T) if P else None
    for r in P:
        d = str(r['PRD_DT'])[:10]
        if d < d0:
            continue
        k = (r['CON_NO'] or '', r['CON_SEQ'] or '')
        rn = str(r.get('RAW_NO') or '')
        gd = gday.get(rn)
        if gd or re.match(r'^[AB]A\d', rn):                    # 소재 코일 = 도금 제품 번호(AA… 1CGL · BA… 2CGL) → 자가재
            kind, sup, ed = '자가재', '', gd
        else:
            sup, ed = buy(k, d) if k[0] else (None, None)
            kind = '구매' if sup else ''
        spec = f"{f(r.get('REAL_MSR_THK')):g}×{f(r.get('PDT_WDT')):g}" if r.get('REAL_MSR_THK') else ''
        put(d, r['LINE'], k, {'grp': grp(r), 'name': product_name(r['PDT_NM']), 'spec': spec, 'kind': kind, 'sup': sup or '', 'con': f'{k[0]}-{k[1]}' if k[0] else ''},
            f(r['PDT_WGT']) / 1000, ed)
    days = defaultdict(lambda: defaultdict(list))
    for (d, l, *_), z in acc.items():
        z['t'] = round(z['t'], 2)
        z['in0'], z['in1'] = (min(z['ins']), max(z['ins'])) if z['ins'] else (None, None)
        days[d][l].append([z[c] for c in ACT_COLS])
    for d in days:
        for l in days[d]:
            days[d][l].sort(key=lambda x: -x[5])
    nk = sum(1 for z in acc.values() if z['cus'])
    return {'built': dt.datetime.now(dt.timezone(dt.timedelta(hours=9))).replace(tzinfo=None).isoformat(timespec='minutes'), 'from': d0, 'asOf': last,
            'entFrom': min((x for v in ent.values() for x in v), default=None), 'cols': ACT_COLS, 'days': {d: dict(v) for d, v in sorted(days.items())},
            'cover': {'rows': len(acc), 'cus': nk, 'kind': sum(1 for z in acc.values() if z['kind'])}}


def kst_hm(iso):
    """ISO 시각(UTC 또는 +09:00) → 한국 시각 'HH:MM'"""
    try:
        x = dt.datetime.fromisoformat(str(iso).replace('Z', '+00:00'))
        if x.tzinfo is None:
            return x.strftime('%H:%M')
        return (x.astimezone(dt.timezone(dt.timedelta(hours=9)))).strftime('%H:%M')
    except Exception:
        return None


def running_today(T, today, at=None):
    """오늘(07시 시작, 아직 마감 전) 진행분 — 라인별 생산 톤과 마지막 코일 종료 시각(11/5 사용자 '오늘 진행분 화면에 보여줘').
    도금 = snap_cg_prod_recent(생산계상일 = 오늘, 더미 = 주문번호 D 제외), 컬러 = color_prod(생산일 = 오늘). 진도율 계산에는 넣지 않음(참고)"""
    out, last = {}, None
    t8 = today.replace('-', '')
    for r in _rows(T, 'snap_cg_prod_recent'):
        if str(r.get('PRD_ACCNT_DT') or r.get('PRD_DT') or '') != t8 or 'D' in str(r.get('CON_NO') or ''):
            continue
        l = {'A': '1CGL', 'B': '2CGL'}.get(str(r.get('LINE_CLS') or '')[:1])
        if l:
            out[l] = out.get(l, 0.0) + f(r.get('PDT_NET_WGT')) / 1000
    for r in _rows(T, 'color_prod'):
        if str(r.get('PRD_DT')) != today:
            continue
        out[r['LINE']] = out.get(r['LINE'], 0.0) + f(r.get('PDT_WGT')) / 1000
        e = r.get('WRK_END_TM')
        if e and (last is None or e > last):
            last = e
    upto = dt.datetime.utcfromtimestamp(int(last) / 1000 + 9 * 3600).strftime('%H:%M') if last else None
    return {'d': today, 'lines': {k: round(v, 1) for k, v in out.items()}, 'ccUpto': upto, 'at': kst_hm(at) if at else None}


def build_all(T, coils, R_prev, R2, auto=None, hist=None, today=None, run_at=None, stops=None, duehist=None, gmp=None):
    run_at = run_at or dt.datetime.now(dt.timezone.utc).isoformat(timespec='minutes')
    T_all = T
    cut_d = None
    try:                                                       # 11/7 점검: 자료 받은 시각이 속한 생산일(07시~)은 아직 진행 중 → 컬러 실적에서 뺌(11/5 07:24 받은 4.8t 를 하루치로 보던 것)
        ra = dt.datetime.fromisoformat(str(run_at).replace('Z', '+00:00'))
        ra = ra.astimezone(dt.timezone(dt.timedelta(hours=9))) if ra.tzinfo else ra
        cut_d = (ra - dt.timedelta(hours=7)).date().isoformat()
        cp_ = T.get('color_prod')
        if cp_ and cp_.get('rows') and 'PRD_DT' in cp_['columns']:
            i_ = cp_['columns'].index('PRD_DT')
            T = dict(T, color_prod=dict(cp_, rows=[r for r in cp_['rows'] if str(r[i_])[:10] < cut_d]))
    except Exception:
        pass
    today = today or cut_d or U.prod_today()                   # 11/8 날짜 통일: 기준일 = 자료 받은 시각의 생산일(계산하는 날 시계가 아님) — 화면 UI.today 와 같음
    ca = color_actual(T)
    ga = plating_actual(T, coils, stops)
    try:                                                       # 계획 화면 지난 날 가동 상세(계약별 실적) — 실패해도 다른 화면 게시에 영향 없음
        act_d = act_detail(T, coils)
    except Exception as e:
        print(f'실적 상세 계산 건너뜀: {e}')
        act_d = None
    pr = procure(T, coils, today)
    due_h = None
    if pr:                                                     # POSCO F/H 인도납기 대비 입고(사양별) · 인도납기 변경 이력(매일 쌓음) — 소재 발주 화면 탭
        try:
            pr['fhDue'] = fh_due(T)
            due_h, pr['dueTrack'] = due_track(T, duehist, today)
        except Exception as e:
            pr['fhDueErr'] = str(e)[:200]
    pb = load_base('portal_base.json') or {}
    data_last = max((str(c['day']) for c in coils), default=None) if coils else (ca or {}).get('asOf')
    hist = accuracy(list(hist or pb.get('accHist', [])), R_prev, coils, data_last or today)
    acc = accuracy_summary(hist)
    if ga is not None and isinstance(ga, dict):                 # 도금 가동 현황 '계획 대비 실적' = 날마다 그날 아침 계획 vs 실적(최근 3주, 사용자 10/21)
        cut = (D(data_last or today) - dt.timedelta(days=21)).isoformat()
        ga['accHist'] = [h for h in hist if h[0] >= cut]
    SR = sr_summary(T, coils)
    pr_all = procure_summary(pr) if pr else None
    portal = dict(pb.get('static', {}))
    portal.update({'built': dt.datetime.now(dt.timezone(dt.timedelta(hours=9))).replace(tzinfo=None).isoformat(timespec='minutes'), 'asOf': data_last, 'today': today,
                   'procure': pr_all, 'procureBy': {'G': procure_summary(pr, 'G'), 'C': procure_summary(pr, 'C')} if pr else None,
                   'acc': acc, 'exceptions': exceptions(today, ca, pr_all, R2, acc, (SR or {}).get('stock'), data_last),
                   'colorNow': {'month': ca['month'], 'w1': ca['w1'], 'tpd': [round(x['w1']['tpd']) for x in ca['lines']], 'tpd0': [round(x['w0']['tpd']) for x in ca['lines']]} if ca else None})
    if R2:                                                     # 최신 계획 기준 빠듯함·계획 대비 실적
        t0 = (R2.get('replan') or {}).get('t0') or data_last or today
        tight = [r for r in R2['rows'] if r[0] > t0 and (D(r[5]) - D(r[0])).days <= 2]
        pl = portal.setdefault('plating', {})
        pl.update({'tightN': len(tight), 'tightT': round(sum(f(r[4]) for r in tight)), 'slack': {k: round(v) for k, v in (R2.get('slack') or {}).items()}})
        rp = R2.get('replan') or {}
        from .leadtime import self_slack as _ssl   # 11/10 사용자: 자가재는 컬러 생산 1일 전까지면 늦은 게 아님(계획 점검 G1·통합 계획과 같은 기준)
        _sk0 = _ssl(R2)
        _sk = lambda r: _sk0 if r[3] == '자가재' else 0
        try:                                                     # 11/15 교차 검사 X8: 계획 점검 G1 과 같은 계산(AL-STS 지연 기준 = 칸 끝)을 그대로 씀
            import importlib, sys as _s
            _s.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'tools'))
            due_late = importlib.import_module('plan_gate').g1_late(R2)['lateTD']
        except Exception:
            due_late = sum(f(r[4]) * ((D(r[0]) - D(r[5])).days - _sk(r)) for r in R2['rows'] if r[0] > t0 and (D(r[0]) - D(r[5])).days > _sk(r))   # 원래 납기 기준(재계획 지연 값엔 자가재 반순 가중분이 섞임)
        pl['now'] = {'t0': rp.get('t0'), 'short': round(f((R2.get('milp') or {}).get('short'))), 'late': round(due_late),
                     'shortBy': (rp.get('shortBy') or []), 'lockNotes': rp.get('lockNotes') or [], 'proposal': rp.get('proposal')}
        if R2.get('orderDemand'):                              # 주문 기준 재계획(tools/order_demand): 결품·지연을 주문 / 판매계획 보충으로 나눔(10/30 재검토: 보충 미편성이 납기 위험처럼 보였음)
            B = {b['id']: b for b in R2.get('buckets') or []}
            BK = {(b['cls'], b['alloy'], b['due']): b for b in B.values()}
            sb = [(B.get(i) or {}, f(v)) for i, v in ((R2.get('milp') or {}).get('shortBy') or [])]
            lt = [r for r in R2['rows'] if r[0] > t0 and r[0] > r[5] and (BK.get((r[3], r[2], r[5])) or {}).get('maxLate')]
            pl['now'].update(orderShort=round(sum(v for b, v in sb if not b.get('shortK'))), fillShort=round(sum(v for b, v in sb if b.get('shortK'))),
                             orderLateT=round(sum(f(r[4]) for r in lt)))
            lab = lambda b, v: f"{b.get('cls')} {b.get('alloy')} {int(str(b.get('due'))[5:7])}/{int(str(b.get('due'))[8:10])} {round(v):,}t"
            pl['now'].update(shortOrder=[lab(b, v) for b, v in sb if not b.get('shortK') and round(v)],    # 11/10 점검: 관제 칩이 판매계획 보충 미편성까지 '결품'으로 → 주문 결품 / 보충 미편성 나눔
                             shortFill=[lab(b, v) for b, v in sb if b.get('shortK') and round(v)])
    base_plan = pb.get('basePlanDaily') or {}                  # 확정 계획(V1) 일별 — 계획 대비 실적 누계
    if base_plan and coils:
        ad = coil_daily(coils)
        q0 = pb.get('q0', '2026-10-01')
        act = sum(v for (d, l), v in ad.items() if q0 <= d <= data_last)
        pln = sum(v for k, v in base_plan.items() if q0 <= k.split('|')[0] <= data_last)
        portal['roll'] = {'asOf': data_last, 'actual': round(act), 'plan': round(pln)}
    try:
        portal['running'] = running_today(T_all, today, (auto or {}).get('runAt'))
    except Exception as e:
        portal['running'] = None; print('running_today 실패', e)
    portal['lines'] = lines_now(T, coils, SR, R2, data_last if coils else None)
    portal["wo"] = work_orders(T, coils, R2, data_last if coils else None, today)
    for x in ((portal['wo'] or {}).get('plating') or {}).get('lines', []):
        if x['mismatch']:
            portal['exceptions'].insert(0, {'lvl': 'warn', 'area': '도금', 'text': f"{x['line']} 현장 작업지시에 {'·'.join(x['mismatch'])} 대기 — 계획의 향후 3일 강종({'·'.join(sorted({p[1] for p in x['plan'] if p[1]}))})과 다름. 강종 순서·M/C 날짜 확인", 'link': 'status.html', 'who': '생산기획'})
    for x in [x for x in ((portal['wo'] or {}).get('color') or {}).get('downConflicts', []) if not x.get('confirmed')]:
        md = lambda s: f'{int(s[5:7])}/{int(s[8:])}'
        rng = md(x['dates'][0]) + (f"~{md(x['dates'][-1])}" if len(x['dates']) > 1 else '')
        sp = x.get('span') or [x['dates'][0], x['dates'][-1]]
        prd = md(sp[0]) + (f"~{md(sp[1])}" if sp[1] != sp[0] else '')
        portal['exceptions'].insert(0, {'lvl': 'warn', 'area': '컬러', 'text': f"{x['line']} {x['kind']}({prd}) 기간 중 {rng}에 현장 작업지시 {x['t']:,}t 예정 — {x['kind']} 일정 또는 작업 예정일 확인", 'link': 'color_status.html', 'who': '생산기획'})
    if R2 and R2.get('rows'):                                # 월별 도금 계획 = 최신 계획(지난 날은 실적 + 앞으로는 재계획), 라인별
        ms_ = portal.get('months') or sorted({r[0][:7] for r in R2['rows']})
        portal['planMonth'] = {'src': '최신 재계획 ' + str((R2.get('replan') or {}).get('t0') or ''), 'months': ms_,
                               'g1': [round(sum(f(r[4]) for r in R2['rows'] if r[1] == '1CGL' and r[0][:7] == m)) for m in ms_],
                               'g2': [round(sum(f(r[4]) for r in R2['rows'] if r[1] == '2CGL' and r[0][:7] == m)) for m in ms_]}
    portal['sr'] = {'asOf': SR['asOf'], 'ship': SR['ship'], 'stock': [{k: x[k] for k in ('name', 'target', 'current', 'grp', 'grpNa') if k in x} for x in SR['stock']]} if SR else None   # grp = 그룹별 소재 재고(속보 발주 부서 줄)
    portal['stockTrend'] = stock_daily(T)
    portal['stockRoll'] = stock_roll(T, R2, load_base('portal_base.json'), gmp)
    q0_ = (load_base('portal_base.json') or {}).get('q0', '2026-10-01')
    portal['shipDay'] = ship_day(T, q0_)
    portal['matRecv'] = mat_recv(T, q0_)
    portal['matGrp'] = mat_group(T, q0_)
    portal['matAct'] = mat_act(T, q0_)
    if pb.get('groupPlanDaily'):
        gmp = gmp or pb.get('groupMonthPlan')                  # 그룹 월 계획(TF 월 생산량) — pages_build 가 통합 계획에서 넘김, 없으면 기준 파일 값
        portal['groups'] = groups(T, coils, SR, pb['groupPlanDaily'], data_last if coils else None, R2, gmp)
        # 11/10 총점검: 도금 그룹 실적은 한 곳(MES 코일 × 판매그룹)에서만 — 수주 관제가 통합 계획의 지난 날을 실적으로 써서 재계획 기준일 뒤 하루는 계획값이 섞였음(도금국내 1,432 vs 718t)
        gd = defaultdict(lambda: defaultdict(float))
        for c in coils or []:
            g = COIL_GROUP.get(c.get('dept'))
            if g and not c.get('dummy') and data_last and str(c['day'])[:7] == data_last[:7] and str(c['day']) <= data_last:
                gd[g][str(c['day'])] += f(c['t'])
        portal['groupDaily'] = {'asOf': data_last, 'src': 'MES 도금 코일(더미 제외) × 판매그룹', 'g': {g: {d: round(v, 1) for d, v in sorted(x.items())} for g, x in gd.items()}}
        portal['monthPlan'] = month_plan(T, pb['groupPlanDaily'], SR, R2, (data_last or today)[:7] if coils else today[:7], gmp)
        portal['srProd'] = sr_prod(T, SR)
        portal['colorPlanFrom'] = pb.get('colorPlanFrom')
    try:
        from . import planstock as PS
        ps = PS.build(T, today)
        if ps:
            ps['built'] = dt.datetime.now(dt.timezone(dt.timedelta(hours=9))).replace(tzinfo=None).isoformat(timespec='minutes')
            nf = ps['flags'].get('short', 0) + ps['flags'].get('low', 0)
            if nf:
                portal['exceptions'].append({'lvl': 'warn', 'area': '컬러', 'text': f"계획재 {nf}개 사양 월말 결품·안전재고 미만 예상 — 전체 재고는 {round(ps['tot']['stock']):,}t로 목표 {round(ps['tot']['target']):,}t보다 많음(사양이 치우침)" if ps['tot']['stock'] > ps['tot']['target'] else f"계획재 {nf}개 사양 월말 결품·안전재고 미만 예상 (재고 {round(ps['tot']['stock']):,}t, 목표 {round(ps['tot']['target']):,}t)", 'link': 'planstock.html', 'who': '컬러건재'})
            portal['planstock'] = {'stock': round(ps['tot']['stock']), 'target': round(ps['tot']['target']), 'end': round(ps['tot']['end'][0]) if ps['tot']['end'] else None, 'flags': ps['flags']}
    except Exception as e:                                     # 계획재 화면 실패는 다른 화면에 영향 없음
        ps = None
        print('계획재 분석 실패:', e)
    try:
        from . import color_cond as CC
        cc = CC.build(T)
    except Exception as e:
        cc = None
        print('컬러 조건 분석 실패:', e)
    me = (D(today).replace(day=28) + dt.timedelta(days=4)).replace(day=1) - dt.timedelta(days=1)   # 11/10 점검: 월간 전망 11/25~30 주요 일정이 비던 것(14일만) → 이번 달 말까지(최소 14일)
    portal['week'] = week_events(today, R2, pr_all, ps, max(14, (me - D(today)).days + 1))
    pages = {'color_actual': ca['asOf'] if ca else None, 'plating_actual': ga['asOf'] if ga else None, 'procure': today if pr else None, 'portal': data_last}
    st = status(T, coils, auto or {}, pages, run_at)
    return {'color_actual': ca, 'plating_actual': ga, 'procure': pr, 'portal': portal, 'status': st, 'accHist': hist, 'planstock': ps, 'color_cond': cc, 'act_detail': act_d, 'dueHist': due_h}


def publish(cfg, sb, dry, T, coils, R_prev, R2, auto, log, encrypt, stops=None):
    """auto.run 5-5단계: 계산 → 암호화 게시(status.json 은 평문). 실패해도 계획 게시에는 영향 없음"""
    hp = os.path.join(cfg['out_dir'], 'acc_hist.json')
    hist = json.load(open(hp, encoding='utf-8')) if os.path.exists(hp) else None
    dp = os.path.join(cfg['out_dir'], 'due_hist.json')            # 발주 인도납기 변경 이력(매일 쌓음)
    try:
        dh = json.load(open(dp, encoding='utf-8')) if os.path.exists(dp) else None
    except Exception:
        dh = None
    O = build_all(T, coils, R_prev, R2, auto, hist, run_at=auto.get('runAt'), stops=stops, duehist=dh)
    json.dump(O['accHist'], open(hp, 'w', encoding='utf-8'), ensure_ascii=False)
    if O.get('dueHist'):
        json.dump(O['dueHist'], open(dp, 'w', encoding='utf-8'), ensure_ascii=False)
    pw = cfg.get('analysis_password') or cfg['password']
    pre = 'test.' if cfg['published_path'].startswith('test') else ''
    done = []
    for name, label in (('color_actual', '컬러 실적'), ('plating_actual', '도금 실적'), ('procure', '소재 조달 판단'), ('portal', '포털 요약'), ('planstock', '계획재 분석'), ('color_cond', '컬러 조건 분석'), ('act_detail', '실적 상세')):
        if not O[name]:
            continue
        body = json.dumps(encrypt(O[name], pw, label))
        path = f'{pre}{name}.enc.json'
        if dry:
            open(os.path.join(cfg['out_dir'], path), 'w', encoding='utf-8').write(body)
        else:
            sb.upload(cfg['published_bucket'], path, body, cache='60')
        done.append(path)
    try:                                                         # 웹 '컬러 계획 계산'용 MES 자료(계산에 쓰는 표·열만, 개인정보 제외)
        from . import colorcalc as CC, store as ST
        nz = lambda v: None if isinstance(v, float) and v != v else v
        cm = CC.mes_payload(T, ST.COLS, [[nz(c.get(k)) for k in ST.COLS] for c in coils or []], auto.get('runAt'))
        body = json.dumps(encrypt(cm, pw, '컬러 계획 계산 자료'))
        path = f'{pre}color_calc_mes.enc.json'
        if dry:
            open(os.path.join(cfg['out_dir'], path), 'w', encoding='utf-8').write(body)
        else:
            sb.upload(cfg['published_bucket'], path, body, cache='60')
        done.append(path)
    except Exception as e:                                       # 계산 자료 실패는 다른 화면 게시에 영향 없음
        log(f'컬러 계획 계산 자료 게시 건너뜀: {e}')
    if auto.get('remoteOnly') and sb and not dry:                 # 2시간 원격 조회엔 실적 표가 없음 → 빈 원천 날짜는 직전 게시값 유지(아침 실행이 멈췄는지 가려지지 않게)
        try:
            prev = {f['name']: f for f in (json.loads(sb.download(cfg['published_bucket'], pre + 'status.json')) or {}).get('feeds', [])}
            O['status']['feeds'] = [f if f.get('last') else dict(prev.get(f['name'], f)) for f in O['status']['feeds']]
        except Exception as e:
            log(f'직전 자료 상태 읽기 실패(그대로 게시): {e}')
    stj = json.dumps(O['status'], ensure_ascii=False)
    if dry:
        open(os.path.join(cfg['out_dir'], pre + 'status.json'), 'w', encoding='utf-8').write(stj)
    else:
        sb.upload(cfg['published_bucket'], pre + 'status.json', stj, cache='60')
    log(f"화면 자료 게시: {', '.join(done)}, {pre}status.json · 오늘 볼 것 {len(O['portal'].get('exceptions', []))}건")
    return O
