"""계획 규칙의 수치(포털 '계획 규칙' 화면에서 고침, 2026-10-22 사용자: 규칙 목록 + 수치 수정 → 적용 누르면 다시 계산).
원본 = cglplan/tf_rules.json(설치 묶음에 같이 들어감).
  days     : 그룹별 TF 목표 일수(월말 재고 = 목표 일수 × 다음 달 하루 판매) — tools/master_plan
  stockMax : 공장 월말 최대 재고('27 판생그룹 목표) — master_plan 상한, 화면 목표
  plating  : 도금 계획 손실·주문재 시작(분 단위, 라인별) — 계획 엔진 P 를 덮어씀(apply_plating)
  replan   : 재계산 기준(지연 1톤·일 대 M/C 1회 무게, 지시 나간 앞 며칠 강종 동결)
  target   : 그룹별 계획 일수(월말 계획 목표 = 계획 일수 × 다음 달 하루 판매, 상한 days 보다 크면 상한) — 11/9 화면에서 고침
화면에서 저장한 값은 Supabase 표 cgl_tf_rules 에 암호화돼 쌓이고(추가만), '적용'을 누른 줄은 apply = true.
tools/rules_apply.py 가 1시간마다 새 적용 요청을 찾아 이 파일로 가져오고 다시 계산·게시."""
import json
import os

PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tf_rules.json')
TABLE = 'cgl_tf_rules'
DAY_KEYS = ('G수출', 'G국내', 'G자가재', 'AL-STS', '임가공', '기타', '건재수출', '가전수출', '가전내수', '주문재', '수요개발')
MAX_KEYS = ('도금 소재(F/H)', '도금 제품(판매재)', '컬러 소재', '컬러 제품')
LINES = ('1CGL', '2CGL')
PLAT_LINE = {'switchDummy': (60, 2000), 'nonfamDummy': (0, 300), 'equipDown': (0, 300), 'restartFamchg': (0, 3000), 'restartSame': (0, 3000)}   # 분 — 범위 밖은 거부
PLAT_ONE = {'releaseDays': (1, 90)}
REPLAN = {'tradeoff': (1, 100000), 'freezeDays': (0, 7)}
REPLAN_DEF = {'tradeoff': 100, 'freezeDays': 2}         # 사내 PC 매일 재계획(cglplan/auto.py)과 같은 값 — 10/22 ③안
ENGINE_KEYS = ('rateBase', 'rateDept', 'releaseDaysCls', 'releaseDaysAlloy', 'releaseDaysGrade')   # 기준 계획 P 를 엔진 기본값으로 바꾸는 항목(apply_plating)
GRADE_KEYS = ('도금수출 AL', '도금수출 AZ', '도금수출 MAC', '도금국내 AL', '도금국내 AZ', '도금국내 MAC',
              '자동차 STS 임가공', '임가공 MAC', '자동차 STS 직판', '자동차 AL', '자동차 MAC')   # 11/23 사용자: 강종별 상한 일수(없으면 그룹 일수 days)
TARGET_KEYS = ('G국내', '주문재', '수요개발', '건재수출', '가전수출')   # 계획 일수(11/5 운영 개선)를 따로 두는 그룹 — 나머지 그룹은 계획 일수 = 상한(days)


def _num(v, lo, hi, what):
    v = float(v)
    if not lo <= v <= hi:
        raise ValueError(f'{what} {v} — {lo}~{hi}')
    return int(v) if v == int(v) else round(v, 3)


def validate(o):
    """화면에서 온 값 검사 — 모르는 항목·범위 밖 값이 있으면 ValueError. 정리된 dict 반환(plating·replan 은 있을 때만)"""
    if not isinstance(o, dict):
        raise ValueError('형식 오류')
    d, m = o.get('days') or {}, o.get('stockMax') or {}
    if set(d) != set(DAY_KEYS) or set(m) != set(MAX_KEYS):
        raise ValueError('항목이 맞지 않음')
    out = {'days': {k: _num(d[k], 0, 120, f'{k} 목표 일수') for k in DAY_KEYS},
           'stockMax': {k: int(_num(m[k], 1, 100000, f'{k} 월말 최대')) for k in MAX_KEYS}}
    p = o.get('plating')
    if p:
        if not set(p) <= set(PLAT_LINE) | set(PLAT_ONE):
            raise ValueError('도금 항목이 맞지 않음')
        out['plating'] = {}
        for k, v in p.items():
            if k in PLAT_LINE:
                if not isinstance(v, dict) or set(v) != set(LINES):
                    raise ValueError(f'{k} 라인이 맞지 않음')
                out['plating'][k] = {ln: _num(v[ln], *PLAT_LINE[k], f'{k} {ln}') for ln in LINES}
            else:
                out['plating'][k] = _num(v, *PLAT_ONE[k], k)
    t = o.get('target')                                   # 11/9 사용자: 계획 일수도 화면에서 고침(없으면 파일 값·TARGET_DEF)
    if t:
        if not set(t) <= set(TARGET_KEYS):
            raise ValueError('계획 일수 항목이 맞지 않음')
        out['target'] = {k: _num(v, 0, 120, f'{k} 계획 일수') for k, v in t.items()}
    gd = o.get('grade')                                   # 11/23: 강종별 상한 일수(판생 기준값·계획 규칙 두 화면이 같은 값)
    if gd:
        if not set(gd) <= set(GRADE_KEYS):
            raise ValueError('강종별 일수 항목이 맞지 않음')
        out['grade'] = {k: _num(v, 0, 120, f'{k} 상한 일수') for k, v in gd.items()}
    r = o.get('replan')
    if r:
        if not set(r) <= set(REPLAN):
            raise ValueError('재계산 항목이 맞지 않음')
        out['replan'] = {k: _num(v, *REPLAN[k], k) for k, v in r.items()}
    return out


def load():
    o = json.load(open(PATH, encoding='utf-8'))
    return dict(validate(o), src=o.get('src') or {})


def apply_plating(P):
    """계획 엔진 P(dict)에 도금 수치를 덮어쓴 사본 — 안 적힌 항목은 그대로.
    속도(rateBase·rateDept)와 부서·강종별 생산 상한(releaseDaysCls·Alloy)은 기준 계획에 저장된 옛 값 대신 지금 엔진 기본값(defaults.json)으로(11/9 — 손실값과 같이 맞춘 속도)"""
    from . import util as U
    D = U.default_params()
    P = dict(P, **{k: D[k] for k in ENGINE_KEYS if k in D})
    for k, v in (R.get('plating') or {}).items():
        P[k] = dict(v) if isinstance(v, dict) else v
    rg = release_grade()
    if rg:
        P['releaseDaysGrade'] = rg
    return P


def release_grade(G=None):
    """강종별 상한 일수(grade) → 일별 배치 상한(부서|강종 → 일수). 11/24 사용자 '세분한 값으로 통일해야지':
    월말 목표 재고(tools/master_plan.tf_days)와 같은 값을 주문을 날짜에 깔 때의 '납기 며칠 전부터 생산 가능'에도 씀.
    엔진 묶음은 부서 · 강종까지만 나뉘어 임가공을 따로 못 가림 → 자동차 AL-STS = 직판 값(임가공 3일은 월말 목표에만), AL-LG = AL, 자가재는 제한 없음 그대로"""
    G = G if G is not None else (R.get('grade') or {})
    out = {}
    for cls, key in (('도금수출', '도금수출'), ('도금국내', '도금국내')):
        for a, src in (('AL', 'AL'), ('AL-LG', 'AL'), ('AZ', 'AZ'), ('MAC', 'MAC')):
            v = G.get(f'{key} {src}')
            if v is not None:
                out[f'{cls}|{a}'] = v
    for cls in ('자동차수출', '자동차내수'):
        for a, k in (('AL', '자동차 AL'), ('AL-LG', '자동차 AL'), ('AZ', '자동차 AL'), ('MAC', '자동차 MAC'), ('AL-STS', '자동차 STS 직판')):
            if G.get(k) is not None:
                out[f'{cls}|{a}'] = G[k]
    return out


def replan_opts():
    return dict(REPLAN_DEF, **(R.get('replan') or {}))


R = load()
DAYS, STOCK_MAX, SRC = R['days'], R['stockMax'], R['src']
GRADE = R.get('grade') or {}                                  # 11/23: 강종별 상한 일수 — 도금국내·도금수출·자동차는 이 값을 판매계획 강종 구성으로 가중(tools/master_plan.tf_days)

# 11/5 사용자 '목표재고일수 운영 개선 — 비교하지 말고 바로 적용': DAYS(TF 목표 일수) = 넘지 않는 상한(점검용),
# 계획에 쓰는 월말 목표 = 운영 유형별 아래 일수 × 다음 달 하루 판매. 값 = 실측 '생산 완료 → 첫 출하' 중앙값(8/1~9/15 생산 코일, MES 출고 11/4까지)
#   A형(주문 생산): 도금국내 7 · 컬러건재 주문재 8 · 수요개발 8(실측 표본 작음 → 주문재 준용) · 컬러 건재수출·가전수출 10
#   A형+캠페인: 도금수출 = 실측 16일이 상한 15일보다 길어 상한 유지(AZ·MAC M/C 주기 사이클 재고 — 일별 엔진이 M/C 로 따로 짬)
#   B형(반복 사양): 가전내수 30(11/9 회의 — 오전 45일 취소) · 자동차 AL-STS 30·임가공 15·그 외 45 그대로 / C형: 자가재 15·계획재(사양별 목표) 그대로
# 상한보다 크면 상한. 분기마다 실측을 다시 재 줄어든 만큼만 내림
# 11/9 사용자: 계획 일수 원본 = tf_rules.json 'target'(계획 규칙 화면에서 고침 → cgl_tf_rules → rules_apply). TARGET_DEF 는 파일에 없을 때(예전 설치 묶음)만
TARGET_DEF = {'G국내': 15, '주문재': 15, '수요개발': 15, '건재수출': 15, '가전수출': 15}   # 11/9 회의: 목표 = 상한 15일
TARGET = {k: min(v, DAYS.get(k, v)) for k, v in dict(TARGET_DEF, **(R.get('target') or {})).items()}
PLAN_DAYS = dict(DAYS, **TARGET)                               # 계획 목표 일수(상한 대신 이것을 씀)
