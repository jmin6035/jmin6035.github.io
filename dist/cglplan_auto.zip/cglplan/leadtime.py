"""리드타임 기준 한 곳(11/10 사용자 '리드타임 우리가 수정 가능하게, 바꾸면 전 페이지 다시'):
cglplan/leadtime_rules.json = 계획·발주 계산이 쓰는 리드타임 원본. 포털 '리드타임 기준' 화면에서 고치면(tools/leadtime_pub.py pull) 이 파일이 바뀌고 다음 갱신에서 전 화면 재계산.
  selfLead·selfLeadMin  자가재 도금 생산 = 컬러 생산일 −selfLead(8)일 ~ −selfLeadMin(1)일 사이(11/10 사용자: '−8일 고정이 아니라 −1~−8일 사이')        safety  입고 → 투입 여유(컬러 C · 도금 G)
  newOrderLT 새 발주로 맞출 수 있는 최소 일수(발주 → 입고)   types   소재 유형별 발주 → 입고 일수
예전엔 값이 파일마다 따로 박혀 있었음(도금 투입 여유가 pages 1일 · mat_order_spec·integrated_web 5일로 서로 달랐음)."""
import json
import os

PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'leadtime_rules.json')


def load():
    return json.load(open(PATH, encoding='utf-8'))


R = load()
SELF_LEAD = int(R['selfLead'])                               # 가장 이른 날(컬러 생산일 − N일)
SELF_LEAD_MIN = int(R.get('selfLeadMin', 1))                 # 마감(컬러 생산일 − N일까지 도금 생산이 끝나면 됨)
SAFETY = {k: int(v) for k, v in R['safety'].items()}
NEW_ORDER_LT = int(R['newOrderLT'])
TYPES = {k: (int(v['lt']), v.get('how') or '') for k, v in R['types'].items()}


def self_slack(plan):
    """계획 행의 자가재 납기가 '가장 이른 날(컬러일 − selfLead)'이면 늦음 판정 여유 = selfLead − selfLeadMin,
    새 수요(tools/order_demand V2: 자가재 납기 = 컬러일 − selfLeadMin, MES 자가재 주문 = 그 주문 마감)면 0."""
    return 0 if ((plan or {}).get('orderDemand') or {}).get('selfDue') == 'use-1' else SELF_LEAD - SELF_LEAD_MIN
